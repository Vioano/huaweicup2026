"""Bounded 1/2/4 spawn-worker probe; no evaluator integration or daemon."""
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
import csv
import gc
import hashlib
import json
import multiprocessing
import os
import platform
import resource
import statistics
import time

from experiment import ROOT, OUT, POOL, DATA, setup, metadata, save
from variants import make_engine


def initialize(mode, case):
    global GRAPH, ENGINE, KWARGS
    GRAPH = json.loads((DATA / f'case_{case}.json').read_text())
    ENGINE, _cache = make_engine(mode)
    _, _, KWARGS = setup()
    gc.collect()


def work(item):
    index, plan = item
    begin = time.perf_counter()
    result = ENGINE.evaluate_scene_a(GRAPH, plan, **KWARGS)
    evaluation_seconds = time.perf_counter() - begin
    digest = hashlib.sha256(json.dumps(result, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    usage = resource.getrusage(resource.RUSAGE_SELF)
    return dict(index=index, digest=digest, makespan=result['makespan'],
        evaluation_seconds=evaluation_seconds, pid=os.getpid(),
        peak_rss_bytes=usage.ru_maxrss if platform.system() == 'Darwin' else usage.ru_maxrss * 1024,
        process_cpu_seconds=usage.ru_utime + usage.ru_stime)


def bounded_batch(executor, plans, workers):
    iterator = iter(enumerate(plans))
    pending = {}
    records = []
    def replenish():
        while len(pending) < 2 * workers:
            item = next(iterator, None)
            if item is None:
                return
            pending[executor.submit(work, item)] = item[0]
    replenish()
    while pending:
        done, _ = wait(pending, return_when=FIRST_COMPLETED)
        for future in done:
            del pending[future]
            records.append(future.result())
        replenish()
    return sorted(records, key=lambda row: row['index'])


def run(case, plans, output, modes=('e1', 'state', 'lean'), worker_counts=(1, 2, 4), repeats=3):
    reference = None
    experiments = []
    for workers in worker_counts:
        for mode in modes:
            begin = time.perf_counter()
            all_rows = []
            times = []
            with ProcessPoolExecutor(max_workers=workers, mp_context=multiprocessing.get_context('spawn'),
                initializer=initialize, initargs=(mode, case)) as executor:
                for repeat in range(repeats):
                    started = time.perf_counter()
                    rows = bounded_batch(executor, plans, workers)
                    times.append(time.perf_counter() - started)
                    digests = [row['digest'] for row in rows]
                    if reference is None:
                        reference = digests
                    assert digests == reference, (mode, workers, repeat)
                    all_rows.append(rows)
            total = time.perf_counter() - begin
            peaks = {}
            for rows in all_rows:
                for row in rows:
                    peaks[row['pid']] = max(peaks.get(row['pid'], 0), row['peak_rss_bytes'])
            experiment = dict(mode=mode, workers=workers, batch_seconds=times,
                total_with_shutdown_seconds=total, worker_peak_rss_bytes=peaks,
                worker_peak_rss_sum_bytes=sum(peaks.values()),
                parent_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                rows=all_rows)
            experiments.append(experiment)
            print(json.dumps({key: value for key, value in experiment.items() if key != 'rows'}), flush=True)
    save(output, dict(metadata=metadata(), resource_harness_sha256=hashlib.sha256(open(__file__, 'rb').read()).hexdigest(),
        variants_sha256=hashlib.sha256((OUT / 'variants.py').read_bytes()).hexdigest(),
        scope='spawn workers; resident graph; full evaluator + full-result hash; <=2*workers queued; compact IPC only',
        memory_note='sum of per-worker high-water RSS; NOT simultaneous physical peak, excludes parent; shared pages can double-count',
        case=case, count=len(plans), repetitions=repeats, equal_digests=True, experiments=experiments))


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['pool', 'large'])
    args = parser.parse_args()
    if args.mode == 'pool':
        rows = list(csv.DictReader((POOL / 'candidates.csv').open()))
        plans = [json.loads((POOL / row['plan_path']).read_text()) for row in rows]
        run('001', plans, 'parallel.json')
    else:
        plans = json.loads((OUT / 'reschedule-plans.json').read_text())[:4]
        run('003', plans, 'memory-large.json', modes=('e1', 'state', 'lean'), worker_counts=(1,), repeats=2)
