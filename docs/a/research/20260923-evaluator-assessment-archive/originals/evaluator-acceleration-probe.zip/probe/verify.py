"""Finite mechanism checks, not a full-domain equivalence proof."""
import contextlib
import copy
import hashlib
import io
import json
import random
import unittest

from experiment import setup, OUT, assert_full, metadata, save
from prototype import build, Step3Cache, install
from variants import make_engine, compact_local
from partition_cache import PartitionCache


def outcome(function, graph, plan, kwargs):
    with contextlib.redirect_stderr(io.StringIO()), contextlib.redirect_stdout(io.StringIO()):
        try:
            return dict(status='ok', value=function(graph, plan, **kwargs))
        except Exception as error:
            return dict(status='error', type=type(error).__name__, message=str(error))


def main():
    oracle, _, kwargs = setup()
    engines = {name: make_engine(name)[0] for name in ('state', 'lean', 'compact_cache')}
    partition, _ = make_engine('lean')
    partition_cache = PartitionCache(partition)
    engines['partition'] = partition
    guard_count = 0
    rows = []
    # Reuses the independent captain review's 900000..900059 generator family,
    # independently re-executes against current frozen E0 and these new probes.
    for seed in range(60):
        rng = random.Random(900000 + seed)
        n = rng.randrange(2, 10)
        ids = rng.sample(range(10, 90), n)
        graph = dict(ops=[], tensors=[], edges=[])
        for j, op_id in enumerate(ids):
            graph['ops'].append(dict(id=op_id, op='RELU', pipe=rng.choice(['PIPE_M', 'PIPE_V']), cycles=rng.choice([0, 1, 3, 17, 100])))
            tid = 100 + j
            graph['tensors'].append(dict(id=tid, pos='UB', size=rng.choice([0, 1, 16, 60, 128])))
            graph['edges'].append(dict(source=tid, target=op_id))
            if j and rng.random() < .8:
                graph['edges'].append(dict(source=ids[rng.randrange(j)], target=tid))
            if j + 1 < n and rng.random() < .5:
                graph['edges'].append(dict(source=tid, target=ids[rng.randrange(j + 1, n)]))
        graph['tensors'].append(dict(id=9999, pos='UB', size=0))
        schedule = [[] for _ in range(1 + seed % 5)]
        mapping = {}
        for j, op_id in enumerate(ids):
            mapping[str(op_id)] = j
            schedule[rng.randrange(len(schedule))].append(j)
        if seed % 3 == 0:
            schedule.append([])
        plan = dict(node_to_subgraph=mapping, core_schedules=schedule)
        variants = [('original', plan)]
        bad = copy.deepcopy(plan)
        del bad['node_to_subgraph'][str(ids[0])]
        variants.append(('missing_mapping', bad))
        if n >= 3:
            bad = copy.deepcopy(plan)
            bad['node_to_subgraph'][str(ids[-1])] = 0
            bad['core_schedules'] = [[x for x in q if x != n - 1] for q in schedule]
            variants.append(('merge', bad))
        for label, item in variants:
            expected = outcome(oracle.evaluate_scene_a, graph, item, kwargs)
            before = copy.deepcopy((graph, item))
            for mode, engine in engines.items():
                actual = outcome(engine.evaluate_scene_a, graph, item, kwargs)
                assert_full(expected, actual, (seed, label, mode))
            assert (graph, item) == before
            rows.append(dict(seed=900000 + seed, variant=label, status=expected['status']))
        if outcome(oracle.evaluate_scene_a, graph, plan, kwargs)['status'] == 'ok':
            alternate = copy.deepcopy(plan)
            alternate['core_schedules'].reverse()
            # Includes exact repeat, actual schedule change, and parameter invalidation.
            for changed_plan, changed_kwargs in (
                (plan, kwargs), (alternate, kwargs),
                (plan, dict(kwargs, bandwidth=kwargs['bandwidth'] / 2)),
                (plan, dict(kwargs, same_core_wait=kwargs['same_core_wait'] + 2))):
                assert_full(outcome(oracle.evaluate_scene_a, graph, changed_plan, changed_kwargs),
                    outcome(partition.evaluate_scene_a, graph, changed_plan, changed_kwargs),
                    ('partition_guard', seed))
                guard_count += 1
            if seed == 0:
                tiny, _ = make_engine('lean')
                tiny_cache = PartitionCache(tiny, limit=1)
                assert_full(outcome(oracle.evaluate_scene_a, graph, plan, kwargs),
                    outcome(tiny.evaluate_scene_a, graph, plan, kwargs), 'over_budget_bypass')
                assert tiny_cache.payload == 0

    # Run the member's CLI/full/schema-guard suite with the private runtime patched.
    from src.eval_exact import problem1
    install(problem1)
    compact_local(problem1)
    suite = unittest.defaultTestLoader.discover(str(OUT.parents[2] / 'tests/eval_exact'), pattern='test_*.py')
    buffer = io.StringIO()
    result = unittest.TextTestRunner(stream=buffer, verbosity=2).run(suite)
    (OUT / 'existing-tests.log').write_text(buffer.getvalue())
    assert result.wasSuccessful(), buffer.getvalue()
    save('verification.json', dict(metadata=metadata(),
        verification_sha256=hashlib.sha256(open(__file__, 'rb').read()).hexdigest(),
        variants_sha256=hashlib.sha256((OUT / 'variants.py').read_bytes()).hexdigest(),
        micro_inputs=len(rows), engines=list(engines), comparison_count=len(rows) * len(engines),
        partition_guard_stats=partition_cache.stats(),
        partition_guard_comparisons=guard_count,
        existing_tests=result.testsRun, failures=0, rows=rows))
    print(json.dumps(dict(micro_inputs=len(rows), engines=len(engines), existing_tests=result.testsRun, failures=0)), flush=True)


if __name__ == '__main__':
    main()
