"""Measure partition-cache worker memory with bounded spawn scheduling."""
import hashlib
import json
import resources
from variants import make_engine as normal_engine
from partition_cache import PartitionCache
from experiment import OUT


def engine(mode):
    if mode != 'partition':
        return normal_engine(mode)
    module, _ = normal_engine('lean')
    return module, PartitionCache(module)


resources.make_engine = engine


if __name__ == '__main__':
    plans = json.loads((OUT / 'reschedule-plans.json').read_text())
    resources.run('003', plans, 'parallel-partition.json', modes=('partition',),
        worker_counts=(1, 2, 4), repeats=2)
    path = OUT / 'parallel-partition.json'
    result = json.loads(path.read_text())
    result['extension_sha256'] = hashlib.sha256(open(__file__, 'rb').read()).hexdigest()
    result['partition_cache_sha256'] = hashlib.sha256((OUT / 'partition_cache.py').read_bytes()).hexdigest()
    path.write_text(json.dumps(result, indent=2) + '\n')
