"""Paired workload resource probe: reclaim cyclic evaluation closures per job."""
import gc
import hashlib
import json
import resource_partition  # installs the research-only partition engine factory
import resources
from experiment import OUT

original_work = resources.work


def reclaiming_work(item):
    result = original_work(item)
    result['gc_collected'] = gc.collect()
    return result


resources.work = reclaiming_work


if __name__ == '__main__':
    plans = json.loads((OUT / 'reschedule-plans.json').read_text())
    resources.run('003', plans, 'resources-gc.json', modes=('partition', 'lean'),
        worker_counts=(1,), repeats=2)
    path = OUT / 'resources-gc.json'
    result = json.loads(path.read_text())
    result['extension_sha256'] = hashlib.sha256(open(__file__, 'rb').read()).hexdigest()
    result['partition_cache_sha256'] = hashlib.sha256((OUT / 'partition_cache.py').read_bytes()).hexdigest()
    result['scope'] += '; gc.collect after each full-result hash, GC time INCLUDED in batch time'
    path.write_text(json.dumps(result, indent=2) + '\n')
