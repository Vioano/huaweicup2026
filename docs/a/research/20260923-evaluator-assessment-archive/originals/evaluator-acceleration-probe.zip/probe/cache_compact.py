"""Compare small local-result cache with zero-cache lean on fixed-partition moves."""
import gc
import hashlib
import json
import time
from experiment import setup, assert_full, OUT, DATA, metadata, save
from variants import make_engine


def main():
    oracle, _, kwargs = setup()
    graph = json.loads((DATA / 'case_003.json').read_text())
    plans = json.loads((OUT / 'reschedule-plans.json').read_text())
    # Original cache probe independently re-ran E0 for ALL these same 12 plans.
    expected_makespans = json.loads((OUT / 'cache.json').read_text())['makespans']
    repetitions = []
    for repeat in range(3):
        lean, _ = make_engine('lean')
        cached, cache = make_engine('compact_cache')
        times = {'lean': [], 'compact_cache': []}
        for index, plan in enumerate(plans):
            results = {}
            engines = [('lean', lean), ('compact_cache', cached)]
            if repeat % 2:
                engines.reverse()
            for name, engine in engines:
                gc.collect()
                begin = time.perf_counter()
                results[name] = engine.evaluate_scene_a(graph, plan, **kwargs)
                times[name].append(time.perf_counter() - begin)
            assert_full(results['lean'], results['compact_cache'], (repeat, index))
            assert results['lean']['makespan'] == expected_makespans[index]
            if repeat == 0:
                assert_full(oracle.evaluate_scene_a(graph, plan, **kwargs), results['lean'], ('e0', index))
            del results
        record = dict(repeat=repeat, seconds=times, cache=cache.stats())
        repetitions.append(record)
        print(json.dumps(record), flush=True)
    save('cache-compact.json', dict(metadata=metadata(),
        variants_sha256=hashlib.sha256((OUT / 'variants.py').read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(open(__file__, 'rb').read()).hexdigest(),
        scope='P1 same partition 12 distinct plans; each repetition starts cold; full returned official objects',
        full_equal=True, repetitions=repetitions))


if __name__ == '__main__':
    main()
