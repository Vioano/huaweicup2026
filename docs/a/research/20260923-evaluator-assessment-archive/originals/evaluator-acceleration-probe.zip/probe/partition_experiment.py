import gc
import hashlib
import json
import math
import statistics
import time
from experiment import setup, OUT, DATA, assert_full, metadata, save
from variants import make_engine
from partition_cache import PartitionCache


def main():
    oracle, _, kwargs = setup()
    graph = json.loads((DATA / 'case_003.json').read_text())
    plans = json.loads((OUT / 'reschedule-plans.json').read_text())
    repetitions = []
    for repeat in range(3):
        engine, _ = make_engine('lean')
        cache = PartitionCache(engine)
        rows = []
        for index, plan in enumerate(plans):
            timings = {}
            results = {}
            functions = [('e0', oracle.evaluate_scene_a), ('partition', engine.evaluate_scene_a)]
            if (repeat + index) % 2:
                functions.reverse()
            for name, function in functions:
                gc.collect()
                begin = time.perf_counter()
                results[name] = function(graph, plan, **kwargs)
                timings[name] = time.perf_counter() - begin
            assert_full(results['e0'], results['partition'], (repeat, index))
            rows.append(dict(index=index, seconds=timings, makespan=results['e0']['makespan']))
            del results
        record = dict(repeat=repeat, rows=rows, cache=cache.stats(),
            total_speedup=sum(row['seconds']['e0'] for row in rows) / sum(row['seconds']['partition'] for row in rows))
        repetitions.append(record)
        print(json.dumps(record), flush=True)
    save('partition.json', dict(metadata=metadata(),
        partition_cache_sha256=hashlib.sha256((OUT / 'partition_cache.py').read_bytes()).hexdigest(),
        variants_sha256=hashlib.sha256((OUT / 'variants.py').read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(open(__file__, 'rb').read()).hexdigest(),
        scope='P1 12 distinct fixed-partition reschedules, 3 cold-cache batches, paired E0 full results',
        full_equal=True, repetitions=repetitions))


if __name__ == '__main__':
    main()
