"""Disposable P1 mechanism probe, NOT a production evaluator.

Only private byte-verified runtimes are changed. Every replacement is guarded.
No official event, DDR floating expression, FIFO order or output field is removed.
"""
from collections import OrderedDict, deque
import importlib.util
import inspect
from pathlib import Path
import pickle
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))


def replace_once(source, old, new):
    assert source.count(old) == 1, (old, source.count(old))
    return source.replace(old, new, 1)


def install(module, full=True):
    runtime = module._runtime
    source = inspect.getsource(runtime.evaluate_scene_a)
    source = replace_once(source,
        "    task_start, task_end = {}, {}",
        "    task_start, task_end = {}, {}\n"
        "    task_rank = {tid: i for i, tid in enumerate(tasks)}\n"
        "    task_ops_left = {}\n    tasks_left = len(tasks)")
    source = replace_once(source,
        "        task_status[task_id] = 'active'",
        "        task_status[task_id] = 'active'\n"
        "        task_ops_left[task_id] = len(task['seq'])")
    source = replace_once(source, "    def retire(now):",
        "    def retire(now):\n        nonlocal tasks_left")
    source = replace_once(source, "                op_status[item] = 'done'",
        "                op_status[item] = 'done'\n"
        "                task_ops_left[task_id] -= 1")
    source = replace_once(source,
        "        for task_id, status in list(task_status.items()):\n"
        "            if status != 'active':\n                continue\n"
        "            task_items = [key(task_id, op_id) for op_id in tasks[task_id]['seq']]\n"
        "            if all(op_status[item] == 'done' for item in task_items):",
        "        for task_id in sorted((tid for tid in core_active_task.values()\n"
        "                               if tid is not None), key=task_rank.__getitem__):\n"
        "            if task_ops_left[task_id] == 0:")
    source = replace_once(source, "                task_status[task_id] = 'done'",
        "                task_status[task_id] = 'done'\n                tasks_left -= 1")
    source = replace_once(source,
        "        if all(status == 'done' for status in task_status.values()):",
        "        if tasks_left == 0:")
    source = replace_once(source,
        "        subgraph_entries = []\n        for task_id in core_orders.get(core_id, []):\n"
        "            subgraph_ops = [entry for entry in op_entries\n"
        "                            if entry['task_id'] == task_id]",
        "        subgraph_entries = []\n        ops_by_task = {}\n"
        "        for entry in op_entries:\n"
        "            ops_by_task.setdefault(entry['task_id'], []).append(entry)\n"
        "        for task_id in core_orders.get(core_id, []):\n"
        "            subgraph_ops = ops_by_task.get(task_id, [])")
    exec(compile(source, '<probe-global>', 'exec'), runtime.__dict__)
    if not full:
        return

    step3_globals = runtime.prepare_step3_execution.__globals__
    step3 = inspect.getsource(step3_globals['step3_simulation'])
    step3 = replace_once(step3, "    def retire_step():",
        "    remaining_ops = len(seq)\n\n    def retire_step():\n        nonlocal remaining_ops")
    step3 = replace_once(step3, "                    op_status[op_id] = 'done'",
        "                    op_status[op_id] = 'done'\n                    remaining_ops -= 1")
    step3 = replace_once(step3,
        "        if all(status == 'done' for status in op_status.values()):",
        "        if remaining_ops == 0:")
    step3 = replace_once(step3, "    free_credits = {pos: [] for pos in capacity}",
        "    free_credits = {pos: deque() for pos in capacity}")
    step3 = replace_once(step3, "                credits.pop(0)", "                credits.popleft()")
    step3_globals['deque'] = deque
    exec(compile(step3, '<probe-step3>', 'exec'), step3_globals)
    step1_globals = runtime.step1_schedule.__globals__
    step1_globals['precompute_depth'] = topological_depth


def topological_depth(pred_map, succ_map, vertices):
    """Same integer depth on the validated DAG; no floating/event change."""
    remaining = {v: len(pred_map[v]) for v in vertices}
    depth = {v: 0 for v in vertices}
    ready = deque(v for v in vertices if remaining[v] == 0)
    while ready:
        source = ready.popleft()
        next_depth = depth[source] + 1
        for target in succ_map[source]:
            depth[target] = max(depth[target], next_depth)
            remaining[target] -= 1
            if remaining[target] == 0:
                ready.append(target)
    return depth


def build(mode='state'):
    name = 'src.eval_exact._probe_' + mode
    spec = importlib.util.spec_from_file_location(name, ROOT / 'src/eval_exact/problem1.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if mode != 'e1':
        install(module, full=mode != 'global')
    return module


class Step3Cache:
    """Bounded serialized LOCAL simulation cache; never reuse global timings.

    Full ordered ext_graph bytes + parameters are compared, no graph-isomorphism
    assumption. Cache only successful Step3 outputs, re-run graph view building.
    Immutable bytes avoid shared mutable per-candidate state. Payload cap excludes
    Python mapping/key/object overhead, which must be measured separately.
    """
    def __init__(self, module, limit=16 * 1024 * 1024):
        self.limit = limit
        self.payload = self.hits = self.misses = self.evictions = 0
        self.entries = OrderedDict()
        globals_ = module._runtime.prepare_step3_execution.__globals__
        self.original = globals_['step3_simulation']
        globals_['step3_simulation'] = self

    def __call__(self, ext_graph, capacity, bandwidth, max_iter=100000):
        key = pickle.dumps((ext_graph, capacity, bandwidth, max_iter), protocol=5)
        if key in self.entries:
            self.hits += 1
            value = self.entries.pop(key)
            self.entries[key] = value
            return pickle.loads(value)
        self.misses += 1
        result = self.original(ext_graph, capacity, bandwidth, max_iter)
        value = pickle.dumps(result, protocol=5)
        size = len(key) + len(value)
        if size <= self.limit:
            while self.payload + size > self.limit:
                old_key, old_value = self.entries.popitem(last=False)
                self.payload -= len(old_key) + len(old_value)
                self.evictions += 1
            self.entries[key] = value
            self.payload += size
        return result

    def stats(self):
        return {k: getattr(self, k) for k in ('limit', 'payload', 'hits', 'misses', 'evictions')}
