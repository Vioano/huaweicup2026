# Tail4 continuation preparation

Fixed order: saved 097 plan gets independent E0 only; then 076, 003, 084 each use the frozen 15d solver and independent E0. The first failure, unknown E2 count, fallback, or resource breach stops the batch. No retry or earlier successful cell is scheduled. The saved 097 solver wall time is historical and is not a new solver measurement.

`run_tail4.py` uses the existing holdout `preflight`, `inspect_solver`, and `cell` functions, plus `evaluate_feedback.monitored`. It checks source, input, old 097 originals, and gate pins before creating a fresh output. Its gate template is deliberately `pending`; root must provide a new admitted, unexpired gate with this manifest and runner hash after resource scheduling. The local paths in the manifest identify the existing frozen checkouts and interpreter and must be rechecked on the execution host.

Limits: at most 3 new solver calls, 12 E2 API attempts, and 4 total E0 including a one-call possible fallback reserve; one worker, 180 seconds per child, 720 seconds total including preflight, 2 GiB monitored subtree RSS, VM pressure level 1, swap growth at most 256 MiB, disk free at least 10 GiB. The required successful path has zero fallback. Resource checks surround each stage. `summary.json` keeps in-flight and uncertain counts for stopped runs.

Preparation validation only: Python compilation and pending-gate refusal. No solver, E0, E2, prepare or construction was run.
