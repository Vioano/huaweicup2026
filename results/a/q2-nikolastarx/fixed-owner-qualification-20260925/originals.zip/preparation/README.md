# Fixed-owner guarded, three-cell qualification: prepared, not admitted

Cold coordinates in this exact order: 006 K5, 089 K5, 097 K5. The frozen solver is `fcc7fa2410edb5e2cd3868b1b7f2d7bce82b58a9`, module `src.q2_nikolastarx.adaptive_fixed_owner_guarded`. This is a three-cell qualification, not an all-case result. The accepted old mechanism results in the pinned expectations file are checked **only after** each new solver and independent E0; they are never passed to the solver to select a plan.

Limits: at most 3 cold solvers, 12 E2 API/native, 3 total E0 including one possible internal fallback reserve, no retry, one worker, 180 seconds per solver/E0 child, 300 seconds from preflight start, 2 GiB observer-inclusive child RSS, VM pressure 1, swap growth at most 256 MiB, free disk at least 10 GiB. The first failed/unknown/fallback cell stops dispatch. A missing ledger keeps unknown count and one possible fallback reserved; it is never interpreted as zero. The fixed evaluator API can internally fall back, so **zero fallback is a success condition, not a pre-run guarantee**.

The package pins the true Git HEAD and every tracked source file in the solver subtree/official code, actual Python source set, E2 manifest plus 51 export files and native binary, three graphs/config, official source manifest, 100-case singlecore baseline, source-dependency and monitor SHA, interpreter invocation symlink and real executable hash. An actual venv child does import-only preflight with no graph read. The reused holdout `cell()` keeps complete canonical oracle-plan originals, selected native record versus independent E0 exact Makespan/DDR/traffic match, wall times and process receipts. Adapter restricts 097 zero-E2 to the exact saved unsupported structure signature under the new `fixed_owner_*` fields. One `summary.json` and one `cell.json` per attempted cell preserve failures and in-flight/unknown accounting.

After a coordinator creates a **new admitted** `gate.json` with pending template fields and future `expires_at_utc`, run from any cwd:

```sh
/Users/nikolastar/.codex/worktrees/p2-gap500-s59ee-20260925/huaweicup2026/.venv/bin/python -B /Users/nikolastar/.codex/worktrees/q2-continuation-s7d28/huaweicup2026/output/fixed-owner-qualification-preparation-20260925/run.py run \
  --repo /Users/nikolastar/.codex/worktrees/q2-continuation-s7d28/huaweicup2026 \
  --raw-root /Users/nikolastar/.codex/worktrees/q2-feedback-s8ee/huaweicup2026/data/raw/a/official \
  --e2-root /Users/nikolastar/.codex/worktrees/q2-feedback-s8ee/huaweicup2026/output/q2-e2-paircheck-603b-s8ee \
  --python /Users/nikolastar/.codex/worktrees/p2-gap500-s59ee-20260925/huaweicup2026/.venv/bin/python \
  --manifest /Users/nikolastar/.codex/worktrees/q2-continuation-s7d28/huaweicup2026/output/fixed-owner-qualification-preparation-20260925/manifest.json \
  --gate /Users/nikolastar/.codex/worktrees/q2-continuation-s7d28/huaweicup2026/output/fixed-owner-qualification-preparation-20260925/gate.json \
  --output /Users/nikolastar/.codex/worktrees/q2-continuation-s7d28/huaweicup2026/output/fixed-owner-qualification-run-20260925
```

The output directory must not already exist. `gate-template.json` is pending and expired intentionally. Offline validation only: `.../.venv/bin/python -B output/fixed-owner-qualification-preparation-20260925/offline-test.py`; `run.py preflight` with the same repo/raw/e2/python/manifest flags checks fixed bytes and imports, no evaluation.
