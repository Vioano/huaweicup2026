"""Pure gate/route replay, no graph construction or evaluator call."""
import copy,hashlib,importlib.util,json,subprocess,sys,tempfile,time
from datetime import datetime,timedelta,timezone
from pathlib import Path
H=Path(__file__).absolute().parent;R=H.parents[1]
spec=importlib.util.spec_from_file_location('q',H/'run.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
m=q.read(H/'manifest.json')
with tempfile.TemporaryDirectory() as t:
 t=Path(t);g=t/'gate.json';out=Path(m['output_dir']);pins={'status':'admitted','scope':q.SCOPE,'manifest_sha256':q.sha(H/'manifest.json'),'runner_sha256':q.sha(H/'run.py'),'holdout_runner_sha256':m['holdout_runner_sha256'],'monitor_sha256':m['monitor_sha256'],'e2_manifest_sha256':m['e2_manifest_sha256'],'output_dir':str(out),'expires_at_utc':(datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat()}
 def check(v,yes):
  g.write_text(json.dumps(v));ok=True
  try:q.gate_check(g,m,out)
  except ValueError:ok=False
  assert ok==yes
 check(pins,True)
 class A: pass
 a=A();a.output=t/'already';a.output.mkdir();a.gate=g
 try:q.run(a,m,None,None,None,None,None,time.perf_counter());raise AssertionError('existing output dispatched')
 except ValueError as e:assert 'fresh output' in str(e)
 a.output=t/'fresh';g.write_text(json.dumps({**pins,'status':'pending'}))
 try:q.run(a,m,None,None,None,None,None,time.perf_counter());raise AssertionError('bad gate dispatched')
 except ValueError as e:assert 'gate' in str(e)
 for k,v in [('status','pending'),('scope','wrong'),('manifest_sha256','wrong'),('runner_sha256','wrong'),('holdout_runner_sha256','wrong'),('monitor_sha256','wrong'),('e2_manifest_sha256','wrong'),('output_dir',str(out/'wrong')),('expires_at_utc','2000-01-01T00:00:00Z')]:check({**pins,k:v},False)
 # Load the actual saved 097 no-E2 original, change only the new wrapper's field names.
 original=q.read(R/'output/bidirectional-holdout12-runtimefix-run-20260925/results/097-k5/online/solver.json');detail=copy.deepcopy(original['detail']);detail['fixed_owner_detail']=detail.pop('reverse_detail');detail['fixed_owner_error']=detail.pop('reverse_error');detail['skip_reason']='fixed_owner_construction_unavailable';base=detail['incumbent_detail']
 assert q.fixed_zero(detail,base)
 for k,v in [('fixed_owner_error',"RuntimeError('unknown')"),('skip_reason','fixed_owner_score_unavailable'),('fixed_owner_detail',{}),('oracle_requests',1)]:
  bad=copy.deepcopy(detail);bad[k]=v;assert not q.fixed_zero(bad,base)
 badbase=copy.deepcopy(base);badbase['construction_errors'][0]['kind']='unexpected';assert not q.fixed_zero(detail,badbase)
 # A foreign cwd child only imports the adapter; it does not read a graph.
 code='import importlib.util,sys; p=sys.argv[1]; s=importlib.util.spec_from_file_location("foreign_cwd",p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);print("import-only-ok")'
 p=subprocess.run([m['python_invocation'],'-B','-c',code,str(H/'run.py')],cwd=t,capture_output=True,text=True,timeout=15)
 assert p.returncode==0 and p.stdout.strip()=='import-only-ok',p.stderr
 print(json.dumps({'status':'passed','negative_gate_cases':9,'wrong_output_and_gate_zero_dispatch':True,'097_positive_route':True,'097_rejected_variants':5,'foreign_cwd_import':True,'solver_calls':0,'E0_calls':0}))
