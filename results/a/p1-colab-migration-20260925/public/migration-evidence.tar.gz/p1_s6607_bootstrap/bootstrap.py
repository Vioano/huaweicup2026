
import pathlib,subprocess,json,time,sys,os,hashlib,tarfile,shutil
W=pathlib.Path('/content/p1_s6607_bootstrap');R=pathlib.Path('/content/p1_s6607_repo'); started=time.time(); steps=[]
def save(state,**extra):
 (W/'status.json').write_text(json.dumps(dict(status=state,started_at=started,updated_at=time.time(),steps=steps,**extra),indent=2))
def cmd(argv,timeout=300):
 steps.append({'argv':argv,'start':time.time()});save('running')
 r=subprocess.run(argv,cwd=R if R.exists() else W,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
 steps[-1].update(exit_code=r.returncode,end=time.time(),output=r.stdout[-12000:]);save('running')
 if r.returncode:raise RuntimeError('bootstrap command failed: '+str(argv[:3]))
try:
 R.mkdir(exist_ok=False)
 cmd(['git','init','.'])
 cmd(['git','remote','add','origin','https://github.com/huaweibei123/huaweicup2026.git'])
 cmd(['git','config','remote.origin.promisor','true'])
 cmd(['git','config','remote.origin.partialclonefilter','blob:none'])
 for commit in ['fb7cc7ec6463bb7841f3cdd424a187176c49818d','3a1b82b71ca1ff6689eb8e72f17d26c48b52073c','85b99a74101e3a7981b60566ad7937bcc8dc5426']:
  cmd(['git','fetch','--filter=blob:none','--depth=1','origin',commit])
 cmd(['git','sparse-checkout','init','--no-cone'])
 cmd(['git','sparse-checkout','set','--no-cone','/src/q1/','/src/eval_exact/','/src/q1_benchmarks/','/src/review/','/docs/a/source-manifest.json','/pyproject.toml','/uv.lock','/AI chats/P1多Pipe链构造证明/附件/r1-p1_s6607/p1_phase_cut.py'])
 cmd(['git','checkout','--detach','fb7cc7ec6463bb7841f3cdd424a187176c49818d'])
 archive=pathlib.Path('/content/p1_s6607_official-inputs.tar')
 with tarfile.open(archive) as tf:tf.extractall(R,filter='data')
 m=json.loads((R/'docs/a/source-manifest.json').read_text())
 for row in m['files']:
  if row['path'].startswith('code/') or row['path']=='data/config.txt':
   assert hashlib.sha256((R/'data/raw/a/official'/row['path']).read_bytes()).hexdigest()==row['sha256']
 assert hashlib.sha256((R/m['case_archive']['path']).read_bytes()).hexdigest()==m['case_archive']['sha256']
 if shutil.which('uv') is None:cmd([sys.executable,'-m','pip','install','uv','--quiet','--disable-pip-version-check'])
 uv=shutil.which('uv')
 if uv is None: raise RuntimeError('uv unavailable after install')
 cmd([uv,'sync','--locked','--python','3.12.13'],timeout=400)
 cmd([str(R/'.venv/bin/python'),'-B','-c','import sys,platform;print(sys.version);print(platform.platform())'])
 save('complete',wall_seconds=time.time()-started,official_files_verified=True,solver_calls=0,evaluator_calls=0)
except Exception as e:
 save('failed',error=repr(e),wall_seconds=time.time()-started,solver_calls=0,evaluator_calls=0)
 raise
