
import pathlib,subprocess,json,time,hashlib,os
W=pathlib.Path('/content/p1_s6607_migration');R=pathlib.Path('/content/p1_s6607_repo');began=time.time();steps=[]
def save(status,**extra):
 (W/'status.json').write_text(json.dumps(dict(status=status,started_at=began,updated_at=time.time(),steps=steps,**extra),indent=2))
def call(argv,timeout):
 steps.append(dict(argv=argv,started_at=time.time()));save('running')
 with (W/f'step{len(steps)}.stdout.txt').open('x') as out,(W/f'step{len(steps)}.stderr.txt').open('x') as err:
  p=subprocess.Popen(argv,cwd=R,stdout=out,stderr=err,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'.:data/raw/a/official/code','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
  steps[-1]['pid']=p.pid;save('running');rc=p.wait(timeout=timeout)
 steps[-1].update(returncode=rc,finished_at=time.time());save('running')
 if rc:raise RuntimeError('failed step '+str(len(steps)))
try:
 for sha in ['8335b5c55b0c12bd34b206e315582d1198439069','bd6dc85a0b69f30d08714cbb46200f90632bb2d7']:
  call(['git','fetch','--filter=blob:none','--depth=1','origin',sha],120)
 call(['git','sparse-checkout','add','/results/a/p1-memory-cache-counterexample-20260925/'],120)
 call(['git','checkout','--detach','bd6dc85a0b69f30d08714cbb46200f90632bb2d7'],120)
 py=str(R/'.venv/bin/python')
 assert hashlib.sha256((R/'src/q1_benchmarks/s6607_colab_fresh.py').read_bytes()).hexdigest()=='589cf9a544b3edfe31b3b515d5bdf9ec876badda52f3a26310af8640d5baa4e9'
 call([py,'-B','src/q1_benchmarks/s6607_colab_fresh.py','--output-root','results/a/p1-colab-migration-20260925/20260925T0100Z-s6607','--cases','001,051','--cores','5'],2450)
 call([py,'-B','src/review/p1_memory_key_contract.py','--fixture-dir','results/a/p1-memory-cache-counterexample-20260925','--output','results/a/p1-memory-key-colab-20260925','--execute'],30)
 save('complete',wall_seconds=time.time()-began)
except Exception as e:
 save('failed',error=repr(e),wall_seconds=time.time()-began)
 raise
