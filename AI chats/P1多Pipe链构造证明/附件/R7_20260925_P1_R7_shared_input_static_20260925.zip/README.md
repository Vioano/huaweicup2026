# P1 R7 shared-input static consultation packet

This is a compact static evidence packet for a Pro question about case 044 shared-input structure. It contains only case 044, fixed v4 K5 artifacts, the historical published K3 full-core probe artifacts, selected official top-level code/config, and the saved analysis/source files. The complete official-cases ZIP, other graphs, credentials, and desktop process listings are excluded.

The analysis files in `analysis/` are current worktree files and were untracked at HEAD `6caeddd18d7bedf6e70dd17afb86413075be2a2d`; they must not be described as contents of that commit. Fixed v4 objects are byte-read from `9c5f87548cc7588465a638e032993969b5cac891`. The K3 probe is a prior, distinct experiment. This packet is static question material only: it contains no new construction, compilation, response, or evaluation and does not represent a unified solver or new score. Compressed result/trace files retain their original `.gz` bytes.
