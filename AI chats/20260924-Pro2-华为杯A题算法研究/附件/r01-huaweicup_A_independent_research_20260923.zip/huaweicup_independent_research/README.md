# Huawei Cup A — independent structural research package

日期：2026-09-23。

## 内容

- `RESEARCH_MEMO_20260923.md`：中文完整研究备忘；证据层级、三条结构路线、证明、伪代码、复杂度、证伪实验、预算、CUDA/Metal/CPU 设计与一手参考文献。
- `structural_probes.py`：标准库数学微验证；含分层整数最小割参考实现、商图/拓扑块等价穷举、固定权重 DAG 端口消元、连续 processor-sharing 对照、矩形输入并集枚举。
- `probe_results.json`：本会话实际运行结果和环境；**不是 E0、E1、E2 或正式 case 成绩**。
- `fixtures/`：符合题面二部边形状的双链商图成环构造，**尚未通过官方入口运行**。

## 复跑

```bash
python structural_probes.py --out my_probe_results.json
```

不需要安装额外包。环境中已用 Python 3.13.5 / Linux x86_64 运行；其他版本请自行复核，不预先宣称兼容性测试通过。运行可能重写 fixtures 中同名文件，建议在本包独立工作目录中执行。

## 严格边界

这里不是官方求解器，没有调用冻结官方源码。原附件 ZIP 和 FORM 证据 ZIP 的原字节获取失败；GitHub 读取返回 404。全文研究备忘准确记录了实际读到和未读到的材料。官方冻结哈希仅引用用户给出的值，未在本会话独立重算。

`layered_cut` 优化的是明确的 monotone-label / tensor-frontier 代理，不是 Makespan。要求唯一内部生产者、至少一个消费者、依赖边覆盖所有生产—消费关系、非负 alpha 和张量大小；生产版还须严格输入校验。

递归 Dinic 是小实例研究参考，不能拿来承诺大图 5–10 分钟。正式实现应改为迭代、缓存友好的整数网络，并处理索引、容量溢出、锚点冲突、超时和 CPU 回退。当前代码并未提供官方 plan 的端到端生成入口。

PS 测试采用连续 Fraction 精确算术，不证明官方整数时刻与同刻 retirement 零差分。max-plus 测试仅固定权重 DAG，不含未表示的动态内存、DDR、Cache 事件。

## 冻结官方验证建议

在拥有已核对源码的本地环境中，使用独立输出目录，沿用官方的 graph、plan、config 和三个输出选项。不要修改官方代码或固定 config，也不要把超时、崩溃当作“官方判非法”。全部实验保留新运行目录、源哈希、配置哈希和完整 stdout/stderr。

本包没有伪造任何官方 trace、结果字段或 GPU 基准。以 `probe_results.json` 的 provenance 和 scope 字段为准。
