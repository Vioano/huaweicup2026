#!/usr/bin/env python3
"""Bounded mathematical probes, NOT the Huawei official evaluator.
Standard library only; no CUDA/Metal or official-code performance claims.
Run: python structural_probes.py --out results.json
"""
from __future__ import annotations
import argparse, hashlib, itertools, json, math, platform, random, sys, time
from collections import deque
from fractions import Fraction
from pathlib import Path

class Dinic:
    """Integer capacities; deterministic traversal; small research reference implementation."""
    def __init__(self, n: int):
        self.g: list[list[list[int]]] = [[] for _ in range(n)]
    def add(self, u: int, v: int, c: int) -> None:
        if c < 0: raise ValueError('negative capacity')
        a, b = [v, len(self.g[v]), c], [u, len(self.g[u]), 0]
        self.g[u].append(a); self.g[v].append(b)
    def flow(self, s: int, t: int) -> tuple[int, set[int]]:
        ans = 0
        while True:
            level = [-1]*len(self.g); level[s] = 0; q = deque([s])
            while q:
                u=q.popleft()
                for v, _, c in self.g[u]:
                    if c and level[v]<0: level[v]=level[u]+1; q.append(v)
            if level[t]<0:
                return ans, {i for i,x in enumerate(level) if x>=0}
            it=[0]*len(self.g)
            def send(u: int, f: int) -> int:
                if u==t: return f
                while it[u]<len(self.g[u]):
                    e=self.g[u][it[u]]; v,rev,c=e
                    if c and level[v]==level[u]+1:
                        got=send(v,min(f,c))
                        if got:
                            e[2]-=got; self.g[v][rev][2]+=got; return got
                    it[u]+=1
                return 0
            while True:
                got=send(s, 10**100)
                if not got: break
                ans+=got

def layered_cut(n: int, h: int, edges: list[tuple[int,int]],
                tensors: list[tuple[int,tuple[int,...],int]],
                unary: list[list[int]], alpha: list[int],
                bounds: dict[int,tuple[int,int]] | None = None) -> tuple[int,list[int]]:
    """Exact surrogate: sum unary[v][label-1] + sum_j alpha[j]*live_bytes(I_j).
    All tensors must have ONE internal producer, >=1 internal consumer, nonnegative size.
    Edges must include every tensor producer->consumer dependency. Labels 1..h.
    This is NOT makespan, not memory-peak feasibility, and not official plan compilation.
    Recursive Dinic is a small-probe implementation; use iterative production max-flow.
    """
    if h<2 or len(alpha)!=h-1 or len(unary)!=n: raise ValueError('bad dimensions')
    if any(a<0 for a in alpha): raise ValueError('alpha must be nonnegative')
    if any(len(row)!=h for row in unary): raise ValueError('bad unary dimensions')
    edge_set=set(edges)
    if any(s<0 or not cs or any((p,c) not in edge_set for c in cs) for p,cs,s in tensors):
        raise ValueError('tensor hypothesis failed')
    w=h-1; count=(n+len(tensors))*w; source=count; sink=count+1
    net=Dinic(count+2); constant=sum(row[-1] for row in unary)
    finite=sum(abs(row[j]-row[j+1]) for row in unary for j in range(w))
    finite+=sum(s*sum(alpha) for _,_,s in tensors)
    inf=finite+1
    x=lambda v,j: v*w+j
    z=lambda t,j: (n+t)*w+j
    for v in range(n):
        for j in range(w):
            c=unary[v][j]-unary[v][j+1]
            if c>=0: net.add(x(v,j),sink,c)
            else: net.add(source,x(v,j),-c); constant+=c
            if j+1<w: net.add(x(v,j),x(v,j+1),inf)
    for u,v in edges:
        for j in range(w): net.add(x(v,j),x(u,j),inf)
    for ti,(p,cs,s) in enumerate(tensors):
        for j in range(w):
            net.add(x(p,j),z(ti,j),s*alpha[j])
            for c in cs: net.add(z(ti,j),x(c,j),inf)
    for v,(lo,hi) in (bounds or {}).items():
        if not (1<=lo<=hi<=h): raise ValueError('invalid label bounds')
        for j in range(w):
            if j+1<lo: net.add(x(v,j),sink,inf)
            if j+1>=hi: net.add(source,x(v,j),inf)
    cut,side=net.flow(source,sink)
    labels=[next((j+1 for j in range(w) if x(v,j) in side),h) for v in range(n)]
    if any(labels[u]>labels[v] for u,v in edges): raise ValueError('infeasible implications')
    if any(not lo<=labels[v]<=hi for v,(lo,hi) in (bounds or {}).items()):
        raise ValueError('infeasible anchor bounds')
    return cut+constant,labels

def objective(labels, tensors, unary, alpha):
    return sum(unary[v][l-1] for v,l in enumerate(labels)) + sum(
        a*s for j,a in enumerate(alpha,1) for p,cs,s in tensors
        if labels[p]<=j and any(labels[c]>j for c in cs))

def random_graph(rng,n):
    ts=[]; edges=[]
    for p in range(n-1):
        cs=tuple(c for c in range(p+1,n) if rng.random()<0.32)
        if cs:
            ts.append((p,cs,rng.randint(1,11))); edges.extend((p,c) for c in cs)
    return edges,ts

def closure_tests(rng):
    trials=120; feasible_labelings=0; nested_sweeps=0
    for rep in range(trials):
        n=rng.randint(3,7); h=rng.choice([2,3]); edges,ts=random_graph(rng,n)
        unary=[[rng.randint(-8,8) for _ in range(h)] for _ in range(n)]
        alpha=[rng.randint(1,4) for _ in range(h-1)]
        bounds={0:(1,1),n-1:(h,h)}
        got,labels=layered_cut(n,h,edges,ts,unary,alpha,bounds)
        best=None
        for ls in itertools.product(range(1,h+1),repeat=n):
            if ls[0]!=1 or ls[-1]!=h or any(ls[u]>ls[v] for u,v in edges): continue
            feasible_labelings+=1; value=objective(ls,ts,unary,alpha)
            best=value if best is None else min(best,value)
        assert got==best==objective(labels,ts,unary,alpha),(rep,got,best,labels)
        # Source-reachable minimum cuts for monotone source/sink capacities.
        a=[rng.randint(-7,7) for _ in range(n)]; work=[rng.randint(1,8) for _ in range(n)]
        previous=set()
        for lam in range(-8,9):
            _,ls=layered_cut(n,2,edges,ts,[[a[v]-lam*work[v],0] for v in range(n)],[1],{0:(1,1),n-1:(2,2)})
            current={v for v in range(n) if ls[v]==1}
            assert previous<=current,(rep,lam,previous,current)
            previous=current
        nested_sweeps+=1
    # Deliberately unanchored internal-only frontier objective: trivial collapse.
    edges=[(0,1),(1,2)];ts=[(0,(1,),5),(1,(2,),5)]
    collapse={str(lam):layered_cut(3,2,edges,ts,[[-lam,0]]*3,[1])[1] for lam in [-1,1]}
    return dict(random_instances=trials,brute_feasible_labelings=feasible_labelings,
                mincut_mismatches=0,monotone_sweeps=nested_sweeps,
                unanchored_collapse_labels=collapse)

def all_partitions(n):
    a=[0]*n
    def rec(i,mx):
        if i==n: yield tuple(a); return
        for v in range(mx+2):
            a[i]=v; yield from rec(i+1,max(mx,v))
    yield from rec(1,0)

def topo(n,edges):
    adj=[[] for _ in range(n)];deg=[0]*n
    for u,v in set(edges): adj[u].append(v);deg[v]+=1
    q=deque(i for i,d in enumerate(deg) if d==0);out=[]
    while q:
        u=q.popleft();out.append(u)
        for v in adj[u]:
            deg[v]-=1
            if deg[v]==0:q.append(v)
    return out if len(out)==n else None

def quotient_test():
    n=5;pairs=list(itertools.combinations(range(n),2)); parts=list(all_partitions(n))
    checks=0;acyclic=0
    for bits in range(1<<len(pairs)):
        edges=[p for j,p in enumerate(pairs) if bits>>j&1]
        validtopos=[perm for perm in itertools.permutations(range(n))
                   if all(perm.index(u)<perm.index(v) for u,v in edges)]
        for p in parts:
            checks+=1;k=max(p)+1
            qe={(p[u],p[v]) for u,v in edges if p[u]!=p[v]}
            good=topo(k,qe) is not None
            exists=False
            for perm in validtopos:
                seq=[p[v] for v in perm]
                runs=1+sum(seq[i]!=seq[i-1] for i in range(1,n))
                if runs==k:exists=True;break
            assert good==exists
            acyclic+=int(good)
    # Individually order-convex blocks are not sufficient.
    edges=[(0,1),(2,3)];p=[0,1,1,0]
    assert topo(2,{(p[u],p[v]) for u,v in edges}) is None
    return dict(n=5,forward_DAGs=1<<len(pairs),set_partitions=len(parts),
                DAG_partition_pairs=checks,acyclic_quotients=acyclic,mismatches=0,
                convex_counterexample=dict(edges=edges,labels=p))

def longest(n,edges,release):
    order=topo(n,[(u,v) for u,v,_ in edges]);assert order is not None
    adj=[[] for _ in range(n)]
    for u,v,w in edges:adj[u].append((v,w))
    x=list(release)
    for u in order:
        for v,w in adj[u]:x[v]=max(x[v],x[u]+w)
    return x

def eliminate(n,edges,keep):
    # Edge-weight version, all exterior forcing supplied at retained vertices.
    a={(u,v):w for u,v,w in edges}
    for v in range(n):
        if v in keep:continue
        incoming=[(u,w) for (u,z),w in a.items() if z==v]
        outgoing=[(z,w) for (u,z),w in a.items() if u==v]
        for u,w1 in incoming:
            for z,w2 in outgoing:a[u,z]=max(a.get((u,z),-math.inf),w1+w2)
        a={e:w for e,w in a.items() if v not in e}
    return [(u,v,w) for (u,v),w in a.items()]

def maxplus_tests(rng):
    count=0; total_removed=0
    for rep in range(100):
        n=rng.randint(5,22)
        edges=[(u,v,rng.randint(1,23)) for u in range(n) for v in range(u+1,n) if rng.random()<0.16]
        sources={v for v in range(n) if not any(z==v for _,z,_ in edges)}
        keep=sources|{n-1}|{v for v in range(n) if rng.random()<0.2}
        reduced=eliminate(n,edges,keep);total_removed+=n-len(keep)
        for _ in range(10):
            release=[rng.randint(0,30) if v in keep else -math.inf for v in range(n)]
            a=longest(n,edges,release);b=longest(n,reduced,release)
            assert all(a[v]==b[v] for v in keep)
            count+=1
    return dict(random_DAGs=100,release_vectors=count,removed_vertices_total=total_removed,mismatches=0,
                scope='fixed weighted DAG only; no official scheduler, DDR, cache or dynamic allocation')

def ps_reference(jobs):
    future=sorted((Fraction(a),Fraction(w),i) for i,(a,w) in enumerate(jobs))
    rem={};done={};now=Fraction(0)
    while future or rem:
        if not rem:now=future[0][0]
        while future and future[0][0]==now:
            _,w,i=future.pop(0);rem[i]=w
        target=now+len(rem)*min(rem.values())
        if future:target=min(target,future[0][0])
        delta=(target-now)/len(rem)
        rem={i:w-delta for i,w in rem.items()};now=target
        for i in list(rem):
            if rem[i]==0:done[i]=now;del rem[i]
    return done

def ps_virtual(jobs):
    future=sorted((Fraction(a),Fraction(w),i) for i,(a,w) in enumerate(jobs))
    tags={};done={};now=Fraction(0);virtual=Fraction(0)
    while future or tags:
        if not tags:now=future[0][0]
        while future and future[0][0]==now:
            _,w,i=future.pop(0);tags[i]=virtual+w
        target=now+len(tags)*(min(tags.values())-virtual)
        if future:target=min(target,future[0][0])
        virtual+=(target-now)/len(tags);now=target
        for i in list(tags):
            if tags[i]==virtual:done[i]=now;del tags[i]
    return done

def ps_tests(rng):
    for _ in range(200):
        jobs=[(rng.randint(0,35),rng.randint(1,15)) for _ in range(rng.randint(1,15))]
        assert ps_reference(jobs)==ps_virtual(jobs)
    return dict(instances=200,mismatches=0,arithmetic='fractions.Fraction',
                scope='continuous equal processor sharing; NOT official integer retirement semantics')

def rectangle_tests():
    # Every balanced two-core partition of a 4x4 independent Cartesian product.
    jobs=list(itertools.product(range(4),repeat=2));best=10**9;worst=0;count=0
    for idx in itertools.combinations(range(16),8):
        chosen=set(idx);sets=[[jobs[i] for i in range(16) if (i in chosen)==flag] for flag in [True,False]]
        costs=[]
        for s in sets:
            r=len({i for i,j in s});c=len({j for i,j in s});m=len(s)
            assert r*c>=m and (r+c)**2>=4*m
            costs.append(r+c)
        val=sum(costs);best=min(best,val);worst=max(worst,val);count+=1
    stripe=12;checkerboard=16
    assert best==stripe and worst==checkerboard
    return dict(grid=[4,4],cores=2,jobs_per_core=8,balanced_assignments=count,
                input_union_cost_best=best,input_union_cost_worst=worst,
                stripe_input_union_cost=stripe,checkerboard_input_union_cost=checkerboard,
                units='number of distinct unit-sized inputs summed over cores; NOT DDR measured traffic or makespan')

def write_domain_fixture(outdir: Path):
    # Two chains: A->B and C->D, each with original DDR input/COPY_IN and final COPY_OUT.
    ts=[];ops=[];edges=[]
    for base in [0,100]:
        ts += [dict(id=base+i,pos=('DDR' if i in [1,5] else 'UB'),size=16) for i in range(1,6)]
        ops += [dict(id=base+10,op='COPY_IN',pipe='PIPE_MTE2',cycles=1),
                dict(id=base+11,op='ADD',pipe='PIPE_V',cycles=4),
                dict(id=base+12,op='ADD',pipe='PIPE_V',cycles=4),
                dict(id=base+13,op='COPY_OUT',pipe='PIPE_MTE3',cycles=1)]
        chain=[base+1,base+10,base+2,base+11,base+3,base+12,base+4,base+13,base+5]
        edges += [dict(source=a,target=b) for a,b in zip(chain,chain[1:])]
    graph=dict(tensors=ts,ops=ops,edges=edges)
    plan=dict(node_to_subgraph={'11':0,'12':1,'111':1,'112':0},core_schedules=[[0],[1]])
    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/'bipartite_quotient_cycle_graph.json').write_text(json.dumps(graph,indent=2)+'\n')
    (outdir/'bipartite_quotient_cycle_plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    return dict(status='constructed; NOT run through official validation',ops=8,tensors=10,
                original_graph='bipartite DAG',quotient_edges=[[0,1],[1,0]])

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,default=Path('results.json'));args=ap.parse_args()
    t0=time.perf_counter();rng=random.Random(20260923)
    res={'provenance':'own mathematical verification, not E0/E1/E2 or contest benchmark',
         'seed':20260923,'environment':{'python':sys.version,'platform':platform.platform(),'machine':platform.machine(),
         'dependencies':'Python standard library only','gpu_used':False},
         'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    for key,fn in [('layered_min_cut',lambda:closure_tests(rng)),('quotient_equivalence',quotient_test),
                   ('maxplus_elimination',lambda:maxplus_tests(rng)),('processor_sharing',lambda:ps_tests(rng)),
                   ('rectangle_input_union',rectangle_tests)]:
        t=time.perf_counter();res[key]=fn();res[key]['wall_seconds']=time.perf_counter()-t
    res['domain_fixture']=write_domain_fixture(args.out.parent/'fixtures')
    res['total_wall_seconds']=time.perf_counter()-t0
    args.out.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(res,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
