# 读取审计与研究任务包

本包不是solver，也不是新的全流程官方benchmark。工作词汇遵循用户给定CRG v1。

- REPORT.md：9部分研究报告，包含全部/goal候选卡。
- GOALS.md / GOALS.json：七项候选任务，均为PROPOSED，未启动。
- READ_MANIFEST.json：七分支固定HEAD、实际读取路径和缺口。
- audit_results.json：真实完成的字节核对、差异计数、纯整数模型测试；E0调用为0。
- *_EXACT_GITHUB_PLAN.json：4份通过SHA256和Git blob SHA1核对的计划字节。
- *_PREFIX_ONLY.*：两份归档E0输出的压缩前缀和局部解压文本，不是完整结果，无完整gzip CRC证明。
- *_UNVALIDATED.json / PROPOSED_COUNTERFACTUAL.json：一个待验证单插入邻居，未执行官方合法性或性能评估。

复核本包：

```sh
python verify_audit.py
```

它只检查4个plan字节身份、L0差异、明确不完整的gzip前缀、9600个纯排序比较，不运行官方代码。
原始G仍须由授权仓库checkout提取官方ZIP后核验；本包不冒充已持有原始G或完整E0轨迹。

计划字节核对使用授权GitHub返回的Git blob SHA，重建文本后同时验证SHA256。原始single_task记录的487605尚未在本轮通过singlecore CLI复算；7.64655是以该记录值为分子基准的条件性算术比。

正式配置与研究诊断配置必须区分。正式结果只用冻结原配置；本包的配置相图均为后续提案。
