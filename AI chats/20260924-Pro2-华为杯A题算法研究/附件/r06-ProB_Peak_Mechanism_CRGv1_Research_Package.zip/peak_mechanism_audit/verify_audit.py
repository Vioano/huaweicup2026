"""Recheck this bounded read audit. This script runs NO official evaluator.

Inputs are frozen GitHub plans (byte identities checked) and explicitly partial
base64 prefixes of two archived E0 outputs. No complete gzip or full-result
validation is claimed. The affine-sort tests are synthetic integer fixtures.
"""
from __future__ import annotations
import base64, hashlib, json, random, zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PLANS = {
 'case008_resource_word_EXACT_GITHUB_PLAN.json': ('1935d89ad16a59a52ad62b2e00b4b43f30e783ade40fe481fc6063d905da64ce','9a1fd3849389fb0155d82d02a91d87c1bf967410'),
 'case008_component_EXACT_GITHUB_PLAN.json': ('c9e86dae0d8290112a9a8ec8a2fe1052f6edd18f0a1765706c7f0351cf70fdf9','0644ab8189f4cffc94d577c9cd76e47a9f46347b'),
 'case008_affine_eighth_EXACT_GITHUB_PLAN.json': ('40ec77159696d284091f6926aab72b711ec682769434a32e14b54229b4ec7357','100e7b3e71af4247f24fceab8a4a6f347a771d35'),
 'case008_single_task4_EXACT_GITHUB_PLAN.json': ('2d285913c029b56a5383d8624afb44ea4230ed1b3f480d65adf9856f74aa49ae','5a6d6cae9a0765605173fdcea7afd695ca2e0b3b'),
}
def verify_plans():
    for name,(expected,blob) in PLANS.items():
        data=(ROOT/name).read_bytes()
        assert hashlib.sha256(data).hexdigest()==expected,name
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob,name
        plan=json.loads(data)
        assert set(plan)=={'node_to_subgraph','core_schedules'}
        order=[x for s in plan['core_schedules'] for x in s]
        assert len(order)==len(set(order))
        assert set(order)==set(plan['node_to_subgraph'].values())
    # These checks do not assert original-graph coverage or execution feasibility.

def order_diff(a,b):
    assert list(a['node_to_subgraph'].items())==list(b['node_to_subgraph'].items())
    changed=inversions=0
    for sa,sb in zip(a['core_schedules'],b['core_schedules']):
        assert set(sa)==set(sb)
        pos={x:i for i,x in enumerate(sa)}
        changed+=sum(x!=y for x,y in zip(sa,sb))
        p=[pos[x] for x in sb]
        inversions+=sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
    return {'changed_positions':changed,'Kendall_pairs':inversions}

def check_sort_intervals():
    rng=random.Random(20260924); count=0
    for _ in range(120):
        ids=rng.sample(range(1,100),rng.randint(2,9))
        pairs={u:(rng.randint(0,60),rng.randint(0,5)) for u in ids}
        anchor=rng.randint(1,40)
        def order(lag): return sorted(ids,key=lambda u:(pairs[u][0]+pairs[u][1]*lag,u))
        seq=order(anchor); lo,hi=1,None
        for u,v in zip(seq,seq[1:]):
            a=pairs[u][1]-pairs[v][1]
            b=pairs[v][0]-pairs[u][0]-(u>v)
            if a>0: hi=min(hi,b//a) if hi is not None else b//a
            elif a<0: lo=max(lo,-((-b)//a))
            else: assert b>=0
        for lag in range(1,81):
            assert (order(lag)==seq)==(lag>=lo and (hi is None or lag<=hi))
            count+=1
    return count

def main():
    verify_plans()
    load=lambda n:json.loads((ROOT/n).read_text())
    w=load('case008_resource_word_EXACT_GITHUB_PLAN.json')
    c=load('case008_component_EXACT_GITHUB_PLAN.json')
    a=load('case008_affine_eighth_EXACT_GITHUB_PLAN.json')
    assert order_diff(c,w)=={'changed_positions':596,'Kendall_pairs':1116}
    assert order_diff(a,w)=={'changed_positions':720,'Kendall_pairs':3716}
    for stem in ('case008_word_q2_PREFIX_ONLY','case008_word_q3_PREFIX_ONLY'):
        dec=zlib.decompressobj(31)
        text=dec.decompress(base64.b64decode((ROOT/(stem+'.b64')).read_text())).decode()
        assert not dec.eof, 'These artifacts must remain labelled PARTIAL'
        assert text==(ROOT/(stem+'.txt')).read_text()
        assert '"makespan":63768' in text
    count=check_sort_intervals()
    print(json.dumps({'plan_byte_checks':4,'sort_model_comparisons':count,
                      'official_evaluator_calls':0,'full_official_graphs_read':0,
                      'scope':'hash checks, plan differences, partial E0 header reads, synthetic sort models only'},indent=2))
if __name__=='__main__': main()
