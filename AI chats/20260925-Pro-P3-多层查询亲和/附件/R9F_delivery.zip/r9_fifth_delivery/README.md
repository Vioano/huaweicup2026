# R9 fifth-core static delivery

先读 `REPORT.md` 和 `SOURCE_AUDIT.md`。唯一提交文件：`plan_068_K5.json`。
`metadata.json` / `evidence.json` / `raw_witnesses.json` 是静态证据，不能提交为计划。

只用 Python 标准库，无官方 evaluator 导入。示例：

```bash
python construct_fifth.py \
  --graph /path/to/case_068.json \
  --config /path/to/config.txt \
  --cores 5 --out /path/to/new-output-directory
python verify_static.py --graph /path/to/case_068.json --plan plan_068_K5.json
python test_toys.py
```

构造器通用判定“持续轨道数等于核心数减一、非空祖先闭合shared”等守卫，不根据case编号分支。
`--out` 必须不存在；guard失败直接报错，无自动重试/试参。生成JSON只有 `node_to_subgraph`、`core_schedules` 两字段。

在本轮原图/config字节下，打包CLI回放计划SHA256为：

```
ee8364e769437cb226cbe95cde845c0bbea59b2fd4e84dc47806d517949b323b
```

`r9_static_core.py` 为上一R9交付的纯静态helper摘录；`row_recognizer_frozen.py` 为固定认知器 `_ports/_recognize` 等定义摘录，移除官方导入。被复用定义AST相同的核验见 `helper_AST_identity.json`。没有复制/改写官方Task/Step实现。

当前没有任何新的官方结果。82,890是固定计划compute/MV FIFO下界；90,112 B是桶前沿，不是运行时UB峰值。不得将这些数值填为官方成绩。
