"""Read-only artifact/label audit. Does not execute an evaluator or train."""
import argparse,hashlib,json
from pathlib import Path
from collections import Counter

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--evidence-root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();r=a.evidence_root
    m=json.loads((r/'MANIFEST.json').read_text());mismatch=[]
    for x in m['files']:
        p=r/x['path']
        if p.stat().st_size!=x['bytes'] or digest(p)!=x['sha256']:mismatch.append(x['path'])
    inv=json.loads((r/'analysis/evidence_inventory.json').read_text());cli=[]
    for f in sorted((r/'experiments').rglob('run.json')):
        x=json.loads(f.read_text())
        if 'problem' not in x or 'command' not in x:continue
        p=f.parent/'result.json';pl=f.parent/'plan.json';res=json.loads(p.read_text())
        assert digest(p)==x['result_sha256'] and digest(pl)==x['plan_sha256']
        assert res['makespan']==x['makespan'] and res['data_movement_bytes']==x['movement']
        cli.append({'run':f.relative_to(r).as_posix(),'problem':x['problem'],'makespan':res['makespan'],'movement':res['data_movement_bytes'],'result_sha256':digest(p),'plan_sha256':digest(pl)})
    data=json.loads((r/'experiments/synthetic/labels.json').read_text());labels=[]
    acts=['coarse','wave4','frontier1','frontierp']
    for row in data:
        folder=r/'experiments/synthetic'/f"f{row['family']}_{row['seed']:02d}"
        for i,name in enumerate(acts):
            result=json.loads((folder/name/'result.json').read_text())
            assert result['makespan']==row['labels'][i] and result['data_movement_bytes']['spill_added_copy_bytes']==row['spill'][i]
            labels.append({'family':row['family'],'seed':row['seed'],'action':name,'makespan':row['labels'][i],'spill':row['spill'][i]})
    cert=json.loads((r/'analysis/certificate_audit.json').read_text());guard=json.loads((r/'analysis/guarded_certificate_audit.json').read_text());fast=json.loads((r/'analysis/fast_constructor_checks.json').read_text())
    for x in cert: assert digest(r/x['plan'])==x['plan_sha256']
    counterpart=[]
    for p in sorted((r/'src').glob('*.py')):
        q=r/'audit/measured_source'/p.name
        counterpart.append({'src':p.name,'packaged_sha256':digest(p),'measured_exists':q.exists(),'measured_equal':p.read_bytes()==q.read_bytes() if q.exists() else None})
    calls500=[]
    for p in sorted((r/'src').glob('*.py')):
        for n,s in enumerate(p.read_text().splitlines(),1):
            if '2*math.ceil' in s or ('500' in s and p.name in ['core.py','core_v1.py']):calls500.append({'path':p.relative_to(r).as_posix(),'line':n,'text':s})
    o={'kind':'artifact integrity and decoding, NOT performance rerun','payload_count':len(m['files']),'payload_mismatches':mismatch,'cli_count':len(cli),'cli_problem_counts':dict(Counter(x['problem'] for x in cli)),'Q1_original_runs':[x for x in cli if x['problem']==1],'principal_results':[x for x in cli if x['makespan'] in [62819,66901,77846]],'synthetic_graphs':len(data),'full_labels_checked':len(labels),'positive_spill_labels':sum(x['spill']>0 for x in labels),'synthetic_problem':2,'certificate_records':len(cert),'certificate_true':sum(x['no_spill_certificate'] for x in cert),'certificate_comparison_input':'audit_certificate.py expanded_peak(graph,seq) sees boundary graph and raw prioritized sequence BEFORE Step2, not the post-spill seq_ext','guard_rows':len(guard),'fast_pairs':len(fast),'fast_all_recorded_equal':all(x['order_and_metadata_equal'] for x in fast),'src_vs_measured':counterpart,'source_500_or_pair_cost_matches':calls500}
    assert not mismatch and len(cli)==117 and len(labels)==240
    a.output.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in o.items() if not isinstance(v,list)},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
