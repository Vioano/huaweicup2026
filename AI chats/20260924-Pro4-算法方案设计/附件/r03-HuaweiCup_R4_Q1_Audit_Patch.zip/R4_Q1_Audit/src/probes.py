"""Bounded Q1-only semantic audit. No training, broad benchmark, or E0 edits.
Produces new run identities; uses Python return-profile hooks only to observe.
Every successful Q1 CLI is compared to all normalized function-result fields.
"""
import argparse,copy,hashlib,json,platform,subprocess,sys
from pathlib import Path
from collections import defaultdict
from q1_profile import interval_profile,boundary_bytes,spill_byte_identity
sys.dont_write_bytecode=True

def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

class Builder:
    def __init__(self): self.ops=[];self.ts=[];self.es=[];self.n=1;self.t=10001
    def tensor(self,s,pos):
        t=self.t;self.t+=1;self.ts.append({'id':t,'pos':pos,'size':s});return t
    def op(self,name,pipe,cy,ins,s,pos):
        v=self.n;self.n+=1;t=self.tensor(s,pos)
        self.ops.append({'id':v,'op':name,'pipe':pipe,'cycles':cy})
        self.es.extend({'source':x,'target':v} for x in ins);self.es.append({'source':v,'target':t})
        return v,t
    def inp(self,s,pos):
        return self.op('COPY_IN','PIPE_MTE2',1,[self.tensor(s,'DDR')],s,pos)[1]
    def comp(self,cy,ins,s=60,pos='L1',pipe='PIPE_M'):
        return self.op('CONV' if pipe=='PIPE_M' else 'ADD',pipe,cy,ins,s,pos)
    def output(self,t):
        s=next(x['size'] for x in self.ts if x['id']==t)
        self.op('COPY_OUT','PIPE_MTE3',1,[t],s,'DDR')
    def graph(self):return {'ops':self.ops,'tensors':self.ts,'edges':self.es}

def plan(groups,orders):
    return {'node_to_subgraph':{str(v):s for s,vs in enumerate(groups) for v in vs},'core_schedules':orders}

def remote_fixture():
    size=262144
    g={'ops':[{'id':i,'op':'COPY_IN' if i==1 else 'CONV','pipe':'PIPE_MTE2' if i==1 else 'PIPE_M','cycles':0 if i==1 else 4} for i in range(1,9)],'tensors':[{'id':10001+i,'pos':'DDR' if i==0 else 'L1','size':size} for i in range(9)]}
    es=[(10001,1),(1,10002),(10002,2),(2,10003),(10003,3),(3,10004),(3,4),(10002,4),(4,10005),(10005,5),(5,10006),(10006,6),(6,10007),(10007,7),(7,10008),(7,8),(10002,8),(8,10009)]
    g['edges']=[{'source':a,'target':b} for a,b in es]
    return g,plan([list(range(2,9))],[[0],[]])

def strict_fixture(internal=False):
    g,_=remote_fixture();out_nodes=[10004,10008,10009]
    for j,(a,b) in enumerate([(3,4),(7,8)]):
        g['edges'].remove({'source':a,'target':b});t=10100+j
        g['tensors'].append({'id':t,'pos':'L1','size':0})
        g['edges'].extend([{'source':a,'target':t},{'source':t,'target':b}])
    for j,t in enumerate(out_nodes):
        v=20+j;d=10200+j
        g['ops'].append({'id':v,'op':'COPY_OUT','pipe':'PIPE_MTE3','cycles':1})
        g['tensors'].append({'id':d,'pos':'DDR','size':262144})
        g['edges'].extend([{'source':t,'target':v},{'source':v,'target':d}])
    if internal:
        g['ops'][0]={'id':1,'op':'CONV','pipe':'PIPE_M','cycles':4}
        g['tensors'][0]['size']=0
        g['edges'].remove({'source':10001,'target':1})
        g['ops'].append({'id':90,'op':'COPY_IN','pipe':'PIPE_MTE2','cycles':1})
        g['tensors'].append({'id':10300,'pos':'L1','size':0})
        g['edges'].extend([{'source':10001,'target':90},{'source':90,'target':10300},{'source':10300,'target':1}])
    return g

def formal_shape(g,cap):
    ops={o['id']:o for o in g['ops']};ts={t['id']:t for t in g['tensors']};pr=defaultdict(set);cs=defaultdict(set);touch=defaultdict(set)
    direct=[]
    for e in g['edges']:
        a,b=e['source'],e['target']
        if a in ops and b in ts:pr[b].add(a);touch[a].add(b)
        elif a in ts and b in ops:cs[a].add(b);touch[b].add(a)
        else:direct.append([a,b])
    roots_sinks=[t for t in ts if (not pr[t] or not cs[t]) and ts[t]['pos']!='DDR']
    bad_alloc=[]
    for v,o in ops.items():
        if o['op'] in ['COPY_IN','COPY_OUT']:continue
        pk={r:sum(ts[t]['size'] for t in touch[v] if ts[t]['pos']==r) for r in cap}
        if any(pk[r]>cap[r] for r in cap):bad_alloc.append({'op':v,'peak':pk})
    return {'bipartite':not direct,'direct_edges':direct,'non_DDR_endpoints':roots_sinks,'all_compute_IO_fits':not bad_alloc,'bad_alloc':bad_alloc,
            'formal_shape_pass':not direct and not roots_sinks and not bad_alloc}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--evidence-root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    root=a.evidence_root.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    code=root/'official/code';config=root/'official/data/config.txt';sys.path.insert(0,str(code))
    import multicore_cut_evaluate_problem_1 as q1
    from evaluation_validation import read_evaluation_config
    from schedule_step2 import _find_copy_in_backings
    cfg=read_evaluation_config(config);waits=q1.read_scene_a_config(config);cap=cfg['capacity']
    before={p.name:sha(p) for p in sorted(code.glob('*.py'))};before['config.txt']=sha(config)
    rows=[];profiles_by_name={}
    def run(name,g,pl,expected_ok=True):
        folder=out/name;folder.mkdir();dump(folder/'graph.json',g);dump(folder/'plan.json',pl)
        captures=[]
        def observe(frame,event,value):
            if event=='return' and frame.f_code.co_name=='step2_spill_insertion' and Path(frame.f_code.co_filename).resolve()==code/'schedule_step2.py' and isinstance(value,dict):
                gg=copy.deepcopy(frame.f_locals['graph_json']);ss=list(frame.f_locals['seq']);rr=copy.deepcopy(value)
                task=frame.f_back.f_locals.get('task_id')
                pf=interval_profile(gg,ss,cap);bb=_find_copy_in_backings(gg)
                assert pf['zero_spill_certificate']==(len(rr['spill_records'])==0)
                ident=spill_byte_identity(rr['spill_records'],bb);assert ident['equal']
                elig={o['id'] for o in gg['ops'] if o['op'] not in {'COPY_IN','COPY_OUT'}}
                # Explicitly untrusted computation-only projection, for contrast.
                cseq=[v for v in ss if v in elig];small={'ops':[o for o in gg['ops'] if o['id'] in elig],'tensors':gg['tensors'],'edges':[e for e in gg['edges'] if e['source'] in elig or e['target'] in elig]}
                cp=interval_profile(small,cseq,cap)
                captures.append({'task':task,'graph':gg,'seq':ss,'step2':rr,'interval':pf,'initial_backing':bb,'spill_identity':ident,'compute_only_peak_UNTRUSTED':cp['pre_spill_peak']})
        sys.setprofile(observe);fun=None;error=None
        try:fun=q1.evaluate_scene_a(g,pl,cfg['bandwidth'],cap,waits['task_cross_core_wait_cycles'],waits['task_same_core_wait_cycles'])
        except Exception as e:error=type(e).__name__+': '+str(e)
        finally:sys.setprofile(None)
        cmd=[sys.executable,'-B',str(code/'multicore_cut_evaluate_problem_1.py'),str(folder/'graph.json'),str(folder/'plan.json'),'--config',str(config),'-o',str(folder/'result.json'),'--trace-output',str(folder/'trace.json'),'--log-output',str(folder/'log.txt')]
        cp=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
        (folder/'stdout.txt').write_text(cp.stdout);(folder/'stderr.txt').write_text(cp.stderr)
        assert (cp.returncode==0)==expected_ok,(name,cp.stderr,error)
        same=False
        if expected_ok:
            assert fun is not None,(name,error)
            cli=json.loads((folder/'result.json').read_text());norm=json.loads(json.dumps(fun));same=all(cli[k]==v for k,v in norm.items());assert same
            dump(folder/'function_result.json',fun)
            assert boundary_bytes(g,pl)['total']==fun['data_movement_bytes']['scheduled_copy_bytes']-fun['data_movement_bytes']['spill_added_copy_bytes']
        else: assert fun is None and not (folder/'result.json').exists()
        dump(folder/'step2_observation.json',captures);profiles_by_name[name]=captures
        row={'name':name,'status':'ok' if expected_ok else 'expected_rejection','graph_sha256':sha(folder/'graph.json'),'plan_sha256':sha(folder/'plan.json'),'function_error':error,'cli_returncode':cp.returncode,'command':cmd,'all_function_fields_equal_to_CLI':same if expected_ok else None,'shape':formal_shape(g,cap),'boundary':boundary_bytes(g,pl)}
        if fun is not None:
            row.update(makespan=fun['makespan'],movement=fun['data_movement_bytes'],tasks=fun.get('task_timeline'),profiles=[{'task':c['task'],'pre_spill_peak':c['interval']['pre_spill_peak'],'no_spill':c['interval']['zero_spill_certificate'],'compute_only_peak_UNTRUSTED':c['compute_only_peak_UNTRUSTED'],'spill_records':len(c['step2']['spill_records']),'backing_for_10002':c['initial_backing'].get(10002),'target_spills':[r for r in c['step2']['spill_records'] if r['logical_tid']==10002],'spill_identity':c['spill_identity']} for c in captures])
        dump(folder/'run.json',row);rows.append(row);print(name,row.get('makespan'),row['status'],flush=True);return row
    # Published witness: byte-identical fixtures, new run identity and environment.
    g,pl=remote_fixture();r=run('remote_fixture_replay',g,pl)
    assert r['graph_sha256']=='0ce778a22c3d1e4c131ca195812fd86f691b6391991be42eb722183de28ce5d2'
    assert r['plan_sha256']=='170e4f58b5761083cbf82243192f096d1cd9c3c6f297038d888567b391a7a890'
    assert r['makespan']==43728
    # A strictly bipartite, DDR-root/leaf repair, not the same graph/score.
    g=strict_fixture();run('strict_backed',g,plan([list(range(2,9))],[[0],[]]))
    g=strict_fixture(True)
    run('internal_split_backed',g,plan([[1],list(range(2,9))],[[0,1],[]]))
    run('internal_merged_unbacked',g,plan([list(range(1,9))],[[0],[]]))
    # Fixed capacity equality and allocate-before-free at the same operation.
    b=Builder();x=b.inp(65536,'UB');v,y=b.comp(10,[x],65536,'UB','PIPE_V');b.output(y)
    run('capacity_equality',b.graph(),plan([[v]],[[0],[]]))
    # Per-Task repeated input, assignment/order independence of local compilation.
    b=Builder();x=b.inp(4096,'UB');v,y=b.comp(10,[x],4096,'UB','PIPE_V');w,z=b.comp(10,[x],4096,'UB','PIPE_V');b.output(y);b.output(z);g=b.graph()
    for name,pp in [('reuse_separate',plan([[v],[w]],[[0,1],[]])),('reuse_reverse',plan([[v],[w]],[[1,0],[]])),('reuse_cross',plan([[v],[w]],[[0],[1]])),('reuse_empty_append',plan([[v],[w]],[[0,1],[],[]])),('reuse_merged',plan([[v,w]],[[0],[]]))]:run(name,g,pp)
    # Outgoing Task barrier even when producer data are already written.
    b=Builder();x=b.inp(60,'L1');av,at=b.comp(10,[x]);x=b.inp(60,'UB');bv,bt=b.comp(5000,[x],60,'UB','PIPE_V');cv,ct=b.comp(5000,[at]);b.output(bt);b.output(ct);g=b.graph()
    run('exit_separate',g,plan([[av],[bv],[cv]],[[0,1],[2]]));run('exit_merged',g,plan([[av,bv],[cv]],[[0],[1]]))
    # New entry barrier delays formerly independent work.
    b=Builder();x=b.inp(60,'L1');av,at=b.comp(5000,[x]);x=b.inp(60,'L1');dv,dt=b.comp(8000,[x]);bv,bt=b.comp(10,[dt],60,'UB','PIPE_V');b.output(at);b.output(bt);g=b.graph()
    run('entry_separate',g,plan([[av],[bv],[dv]],[[0,1],[2]]));run('entry_merged',g,plan([[av,bv],[dv]],[[0],[1]]))
    # Joint cycle is not caught merely by quotient and direct same-core checks.
    b=Builder();x=b.inp(60,'L1');v,t=b.comp(10,[x]);w,u=b.comp(10,[t]);b.output(u);x=b.inp(60,'L1');z,t=b.comp(10,[x]);h,u=b.comp(10,[t]);b.output(u);g=b.graph()
    run('mixed_joint_cycle',g,plan([[v],[h],[z],[w]],[[1,0],[3,2],[]]),False)
    run('mixed_joint_good',g,plan([[v],[h],[z],[w]],[[0,1],[2,3],[]]))
    # Exact identical local Step1/Step2 under fixed partition, sgids, input.
    base=profiles_by_name['reuse_separate']
    equal={name:base==profiles_by_name[name] for name in ['reuse_reverse','reuse_cross','reuse_empty_append']}
    assert all(equal.values())
    # Deleting COPY from actual raw order need not preserve the peak.
    peak_differences=[{'name':n,'task':x['task'],'actual':x['interval']['pre_spill_peak'],'compute_only':x['compute_only_peak_UNTRUSTED']} for n,cs in profiles_by_name.items() for x in cs if x['interval']['pre_spill_peak']!=x['compute_only_peak_UNTRUSTED']]
    after={p.name:sha(p) for p in sorted(code.glob('*.py'))};after['config.txt']=sha(config);assert before==after
    summary={'python':sys.version,'platform':platform.platform(),'scope':'bounded Q1 semantic probes; no formal-case performance runs','official_sha256':before,'official_unchanged':True,'cli_calls':len(rows),'successful_cli':sum(r['status']=='ok' for r in rows),'expected_rejections':sum(r['status']!='ok' for r in rows),'step2_profiles':sum(len(v) for v in profiles_by_name.values()),'fixed_partition_local_identity':equal,'compute_only_projection_counterexamples':peak_differences,'runs':rows}
    dump(out/'summary.json',summary)
if __name__=='__main__':main()
