"""One additional Q1 CLI: computation-only projection falsely says no spill.
This is a new strict bipartite synthetic fixture, NOT an old or formal-case score.
"""
import argparse,copy,json,subprocess,sys
from pathlib import Path
from probes import strict_fixture,plan,dump,sha,formal_shape
from q1_profile import interval_profile

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--evidence-root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);code=a.evidence_root.resolve()/'official/code';config=code.parent/'data/config.txt';sys.path.insert(0,str(code));sys.dont_write_bytecode=True
    import multicore_cut_evaluate_problem_1 as q1
    from evaluation_validation import read_evaluation_config
    cfg=read_evaluation_config(config);waits=q1.read_scene_a_config(config);cap=cfg['capacity']
    g=strict_fixture()
    for t in g['tensors']:
        if t['size']==262144:t['size']=131073
    pl=plan([list(range(2,9))],[[0],[]]);dump(out/'graph.json',g);dump(out/'plan.json',pl);capt=[]
    def observe(f,event,r):
        if event=='return' and f.f_code.co_name=='step2_spill_insertion' and Path(f.f_code.co_filename).resolve()==code/'schedule_step2.py' and isinstance(r,dict):capt.append({'graph':copy.deepcopy(f.f_locals['graph_json']),'seq':list(f.f_locals['seq']),'step2':copy.deepcopy(r)})
    sys.setprofile(observe)
    try:r=q1.evaluate_scene_a(g,pl,cfg['bandwidth'],cap,waits['task_cross_core_wait_cycles'],waits['task_same_core_wait_cycles'])
    finally:sys.setprofile(None)
    c=capt[0];pf=interval_profile(c['graph'],c['seq'],cap);ids=set(range(2,9));sub={'ops':[o for o in c['graph']['ops'] if o['id'] in ids],'tensors':c['graph']['tensors'],'edges':[e for e in c['graph']['edges'] if e['source'] in ids or e['target'] in ids]};wrong=interval_profile(sub,[v for v in c['seq'] if v in ids],cap)
    assert wrong['zero_spill_certificate'] and not pf['zero_spill_certificate'] and c['step2']['spill_records']
    cmd=[sys.executable,'-B',str(code/'multicore_cut_evaluate_problem_1.py'),str(out/'graph.json'),str(out/'plan.json'),'--config',str(config),'-o',str(out/'result.json'),'--trace-output',str(out/'trace.json'),'--log-output',str(out/'log.txt')]
    cp=subprocess.run(cmd,capture_output=True,text=True,timeout=30);assert cp.returncode==0,cp.stderr
    cli=json.loads((out/'result.json').read_text());assert all(cli[k]==v for k,v in json.loads(json.dumps(r)).items())
    dump(out/'function_result.json',r);dump(out/'observation.json',c);dump(out/'profiles.json',{'actual':pf,'compute_only_UNTRUSTED':wrong})
    summary={'name':'Q1_computation_only_false_negative','graph_sha256':sha(out/'graph.json'),'plan_sha256':sha(out/'plan.json'),'shape':formal_shape(g,cap),'actual_peak':pf['pre_spill_peak'],'wrong_peak':wrong['pre_spill_peak'],'capacity':cap,'spill_records':len(c['step2']['spill_records']),'makespan':r['makespan'],'movement':r['data_movement_bytes'],'all_function_fields_equal_to_CLI':True,'command':cmd,'python':sys.version}
    dump(out/'summary.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
