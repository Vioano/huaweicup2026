"""Read-only, pre-spill interval diagnostics for an ACTUAL Q1 Step1 sequence.
Not a Q1 scheduler, an E0 replacement, or a no-spill-only rejection rule.
Python standard library only. The caller supplies the official boundary graph,
actual complete Step1 sequence, and frozen capacity. Never use a desired order.
"""
from collections import defaultdict


def interval_profile(graph, seq, capacity):
    """Allocate-before-free peak; DDR and untouched tensors are excluded.

    Under the official Step2 input contract, all peaks <= capacity iff Step2
    succeeds with an empty spill_records list. An overflow is not proof that
    the plan is invalid: Step2 may spill and succeed. Failed calls are not
    zero-spill successes. This routine does not validate global execution.
    """
    ops = {o['id'] for o in graph['ops']}
    if len(seq) != len(ops) or set(seq) != ops:
        raise ValueError('Expected the complete official sequence')
    loc = {op:i for i,op in enumerate(seq)}
    uses = defaultdict(set)
    for e in graph['edges']:
        a,b=e['source'],e['target']
        if a in ops and b not in ops:
            uses[b].add(loc[a])
        elif b in ops and a not in ops:
            uses[a].add(loc[b])
    delta = {r:[0]*(len(seq)+1) for r in capacity}
    intervals=[]
    for t in graph['tensors']:
        if t['pos']=='DDR' or not uses[t['id']]:
            continue
        r=t['pos']
        if r not in capacity: raise ValueError('Unknown memory type')
        a,b=min(uses[t['id']]),max(uses[t['id']])
        delta[r][a]+=t['size'];delta[r][b+1]-=t['size']
        intervals.append({'tid':t['id'],'pos':r,'size':t['size'],
                          'first':a,'last':b})
    profiles={};peaks={}
    for r,ds in delta.items():
        live=0;profile=[]
        for d in ds[:-1]: live+=d;profile.append(live)
        if live+ds[-1]!=0: raise AssertionError('Unbalanced intervals')
        profiles[r]=profile;peaks[r]=max(profile,default=0)
    return {'pre_spill_peak':peaks,'profile':profiles,'intervals':intervals,
            'zero_spill_certificate':all(peaks[r]<=capacity[r] for r in capacity)}


def boundary_bytes(graph, plan):
    """Exact pre-spill COPY bytes of Q1's boundary rules, not a time proxy.
    Original bipartite, single-producer domain. Counts PER TASK, not per core.
    """
    mp={int(v):s for v,s in plan['node_to_subgraph'].items()}
    ops={o['id']:o for o in graph['ops']};prod=defaultdict(set);cons=defaultdict(set)
    for e in graph['edges']:
        a,b=e['source'],e['target']
        if a in ops and b not in ops:prod[b].add(a)
        elif b in ops and a not in ops:cons[a].add(b)
        elif a in ops and b in ops:continue
        else:raise ValueError('Unsupported edge')
    ts={t['id']:t for t in graph['tensors']};items=[]
    for t in ts:
        ps=prod[t]&mp.keys();cs=cons[t]&mp.keys()
        if len(ps)>1:raise ValueError('Single producer required')
        psg={mp[v] for v in ps};csg={mp[v] for v in cs}
        out_final=any(ops[v]['op']=='COPY_OUT' for v in cons[t])
        for sg in sorted(psg|csg):
            inp=sg in csg and sg not in psg
            out=sg in psg and (out_final or not cs or bool(csg-{sg}))
            if inp or out:
                items.append({'task':sg,'tid':t,'input':inp,'output':out,
                              'bytes':ts[t]['size']*(int(inp)+int(out))})
    return {'total':sum(x['bytes'] for x in items),'items':items}


def spill_byte_identity(records, initial_backing):
    """Compare conditional per-record sum and logical-tensor aggregation.
    Version/ID/position/event records MUST still be retained by any evaluator.
    """
    counts=defaultdict(int);sizes={}
    for r in records: counts[r['logical_tid']]+=1;sizes[r['logical_tid']]=r['size']
    per_record=sum(r['size']*(1+int(r['spill_out_copies_data'])) for r in records)
    aggregated=sum(sizes[t]*(m+int(t not in initial_backing)) for t,m in counts.items())
    return {'per_record':per_record,'logical_aggregate':aggregated,
            'equal':per_record==aggregated,
            'wrong_fixed_pair':sum(2*r['size'] for r in records)}
