"""Only checks already saved tiny probe results. No E0 calls."""
import argparse,json,sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--evidence-root',type=Path,required=True);ap.add_argument('--probe-results',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();sys.path.insert(0,str(a.evidence_root.resolve()/'official/code'))
    from q1_guards import joint_graph,compute_barrier_bound,can_merge_core_adjacent
    from stub_multicore_cut_and_schedule import derive_multicore_plan
    from evaluation_validation import read_evaluation_config
    import multicore_cut_evaluate_problem_1 as q1
    ws=q1.read_scene_a_config(a.evidence_root/'official/data/config.txt');same=ws['task_same_core_wait_cycles'];cross=ws['task_cross_core_wait_cycles']
    rows=[]
    for path in sorted(a.probe_results.glob('*/result.json')):
        g=json.loads((path.parent/'graph.json').read_text());pl=json.loads((path.parent/'plan.json').read_text());r=json.loads(path.read_text());lb=compute_barrier_bound(g,pl,same,cross);assert lb['lower_bound']<=r['makespan'];rows.append({'name':path.parent.name,'makespan':r['makespan'],**lb})
    p=a.probe_results/'mixed_joint_cycle';g=json.loads((p/'graph.json').read_text());pl=json.loads((p/'plan.json').read_text());derive_multicore_plan(g,pl)
    try:joint_graph(g,pl,same,cross)
    except ValueError:pass
    except Exception as e:assert 'task schedule: dependency cycle' in str(e)
    else:raise AssertionError('Joint cycle not rejected')
    d={r['name']:r for r in rows};assert d['exit_merged']['lower_bound']>d['exit_separate']['makespan'];assert d['entry_merged']['lower_bound']>d['entry_separate']['makespan']
    merge_checks=[]
    for name in ['exit_separate','entry_separate','internal_split_backed','reuse_separate']:
        p=a.probe_results/name;g=json.loads((p/'graph.json').read_text());pl=json.loads((p/'plan.json').read_text());v,ad,_=joint_graph(g,pl,same,cross);ok=can_merge_core_adjacent(v,ad,0,1);assert ok;merge_checks.append({'name':name,'cover_merge_legal':ok})
    # One unit DAG demonstrates why checking only same-core adjacency is wrong.
    v={'core_by_subgraph':{0:0,1:0,2:1},'core_orders':{0:[0,1],1:[2]}};ad={0:{1:100,2:1000},2:{1:1000},1:{}};assert not can_merge_core_adjacent(v,ad,0,1)
    out={'new_E0_calls':0,'joint_cycle_passed_derive_but_failed_joint_check':True,'longer_path_cover_counterexample':True,'bound_checks':rows,'merge_checks':merge_checks,'exit_bad_merge_prunable':True,'entry_bad_merge_prunable':True}
    a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
