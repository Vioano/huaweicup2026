"""Q1 structural guards and a compute-plus-Task-barrier LOWER BOUND.
No new timing evaluator; no DDR/spill approximations are used in the bound.
Requires frozen official modules on sys.path. All unchanged official entry
checks remain necessary for a submitted plan. Bound > incumbent allows pruning
for makespan minimization; equality alone does not address secondary traffic.
"""
from collections import defaultdict,deque
from stub_multicore_cut_and_schedule import (
    derive_multicore_plan,_build_op_adjacency,_contract_excluded_copy_nodes)
from evaluation_validation import validate_task_order

def joint_graph(graph,plan,same_wait,cross_wait):
    view=derive_multicore_plan(graph,plan);validate_task_order(view)
    adj={s:{} for s in view['subgraph_ids']}
    for u,v in view['dependency_pairs']:
        adj[u][v]=cross_wait if view['core_by_subgraph'][u]!=view['core_by_subgraph'][v] else 0
    for order in view['core_orders'].values():
        for u,v in zip(order,order[1:]):adj[u][v]=max(adj[u].get(v,0),same_wait)
    deg={s:0 for s in adj}
    for u in adj:
        for v in adj[u]:deg[v]+=1
    ready=deque(sorted(s for s in adj if deg[s]==0));topo=[]
    while ready:
        s=ready.popleft();topo.append(s)
        for v in sorted(adj[s]):
            deg[v]-=1
            if not deg[v]:ready.append(v)
    if len(topo)!=len(adj):raise ValueError('Joint Task cycle')
    # This one global linear extension has EXACTLY the specified projections.
    for c,order in view['core_orders'].items():
        assert [s for s in topo if view['core_by_subgraph'][s]==c]==order
    return view,adj,topo

def compute_barrier_bound(graph,plan,same_wait,cross_wait):
    view,adj,topo=joint_graph(graph,plan,same_wait,cross_wait)
    mp=view['mapping'];ops={o['id']:o for o in graph['ops']}
    _,succ0=_build_op_adjacency(graph);pr,su=_contract_excluded_copy_nodes(sorted(mp),succ0)
    deg={v:len(pr[v]) for v in mp};ready=deque(sorted(v for v in mp if not deg[v]));path={};load=defaultdict(lambda:defaultdict(int));local_cp=defaultdict(int)
    while ready:
        v=ready.popleft();w=max(1,ops[v]['cycles']);s=mp[v]
        # Only mandatory compute-pipe work. Eligible MTE operations, should
        # an extended input domain contain them, are conservatively ignored.
        is_compute=ops[v]['pipe'] in {'PIPE_M','PIPE_V'}
        w=w if is_compute else 0
        load[s][ops[v]['pipe']]+=w
        path[v]=w+max((path[u] for u in pr[v] if mp[u]==s),default=0)
        local_cp[s]=max(local_cp[s],path[v])
        for u in su[v]:
            deg[u]-=1
            if not deg[u]:ready.append(u)
    ell={s:max(local_cp[s],load[s]['PIPE_M'],load[s]['PIPE_V']) for s in adj}
    start_lb={s:0 for s in adj};finish_lb={}
    for s in topo:
        finish_lb[s]=start_lb[s]+ell[s]
        for u,w in adj[s].items():start_lb[u]=max(start_lb[u],finish_lb[s]+w)
    return {'lower_bound':max(finish_lb.values(),default=0),'task_compute_lower_bounds':ell,'task_finish_lower_bounds':finish_lb,'common_topological_witness':topo}

def can_merge_core_adjacent(view,adj,a,b):
    c=view['core_by_subgraph'][a]
    if view['core_by_subgraph'][b]!=c:raise ValueError('Different cores')
    order=view['core_orders'][c]
    if order.index(b)!=order.index(a)+1:raise ValueError('Not adjacent')
    # In a DAG with edge a->b, contraction is acyclic iff no longer a~>b path.
    queue=[v for v in adj[a] if v!=b];seen=set(queue)
    while queue:
        v=queue.pop()
        if v==b:return False
        for u in adj[v]:
            if u not in seen:seen.add(u);queue.append(u)
    return True
