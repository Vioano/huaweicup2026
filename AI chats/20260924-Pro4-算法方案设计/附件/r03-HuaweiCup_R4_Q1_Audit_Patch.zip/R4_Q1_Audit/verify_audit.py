"""Verify shipped audit bytes; ignores newly generated local-reproduction files."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for item in manifest['files']:
    p=root/item['path'];data=p.read_bytes()
    assert len(data)==item['bytes'],item['path']
    assert hashlib.sha256(data).hexdigest()==item['sha256'],item['path']
print(json.dumps({'verified_files':len(manifest['files']),'note':'Integrity only; not solver acceptance'}))
