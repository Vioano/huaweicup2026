# R4-Q1-A1：单独审计补丁，不覆盖 R4

## 保留

- 原 `HuaweiCup_A_R4_Report.md` 与 `HuaweiCup_A_R4_Evidence.zip` 的字节及实验身份全部保留。见 PROVENANCE.json。
- 原 117 次 CLI、240 份合成 API 标签、56 个证书记录及 14 组增量对照仍是原记录；这次只重新核验其文件与数值绑定，不冒称性能复跑。
- 原 R4-1 / R4-2 在限定的 Q2/Q3 singleton 域中保留；不依赖“spill 必定 COPY 对 / UB / version1”。

## 收紧与纠正

1. R4-2 的右侧明确为“Step2 **成功返回，且 spill_records 为空**”；异常/未调用/不支持不计成零-spill成功。
2. 原56例检查器 `expanded_peak(graph, seq)`实际收到的是**边界图与 spill 之前的序列**，不是换入换出后的 `seq_ext`，也不是 Step3 实际并发峰值。
3. `certify_plan.py`有独立域检查；`Frontier.result()`、`banker_order()`内部也用`no_spill_certificate`字段，但没有完整调用前者的范围护栏。不能把该内部字段用于任意输入或Q1。
4. Banker可证明的是固定作业私有profile、全程共享预留、可自由编排作业前缀的保守模型。Q1没有这个Task内部编排接口。它不成为Q1合法性/零spill筛除条件。
5. R4“搬运相同且零spill”只排除总字节减少和新增spill差异；不能单独把全部时延收益归因于M/V流水，更不能归因于压力函数。
6. 原`packet_assignment()`中的`500 + 2*ceil(size/60)`是B场景跨核通信代理，非spill固定2×size硬剪枝。代码未显示此类spill硬剪枝，但前沿偏好没有区分便宜已有backing与昂贵首次写回，方向偏置不能排除。
7. 原`solve.py/solve_fast.py`对Q1关闭singleton，但Q1的packet种子仍调用B式500延迟/双Pipe时钟代理；“有Q1入口”不等于“有Q1专用构造”。不能只把500机械换成1000：还需同核Task之间100等待、整Task核心占用、按Task计输入。
8. 旧60图240标签全部是Q2；本次仅核验绑定，其中只有7份正spill标签，不证明已有backing/多次换入分支被充分覆盖。冻结它们，不改成Q1训练样本，不重训。
9. “共同拓扑序”是合法核序的存在性表示；只有预先固定某一个序才产生相应的搜索限制。

## Q1可直接接入的新增小部件

- `src/q1_profile.py`：实际Task边界图/Step1序列的闭区间诊断；按Task的精确边界COPY字节；条件spill字节恒等式。
- `src/q1_guards.py`：联合Task图、共同拓扑见证、相邻同核cover合并合法性、纯计算加Task等待的可证下界。
- 这些是审计/构造护栏，不是已实现并验收的新Q1强求解器，不是E1。

## 本补丁新增实测

17次Q1 CLI：16成功、1有意联合环拒绝；16份成功结果逐个与插桩观察的完整函数字段比较一致。30次Task级Step2观察包含重复分区对照。原官方字节未改。没有正式case性能复跑，没有Q2/Q3新CLI，没有训练。
