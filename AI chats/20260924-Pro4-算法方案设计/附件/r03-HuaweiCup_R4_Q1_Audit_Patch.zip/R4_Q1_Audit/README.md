# R4-Q1-A1 审计包

先读 `AUDIT.md`，修改清单见 `PATCH_NOTES.md`。原R4交付不变，身份在 `PROVENANCE.json`。

本包包含17次Q1机制CLI的新图/方案/完整结果、诊断和审计源代码，没有新的正式case性能成绩，也没有训练。`q1_profile.py`、`q1_guards.py`是可用于Q1构造的护栏，不是已完成的Q1求解器。

## 校验

```bash
python -B verify_audit.py
```

## 定点复跑

旧 `HuaweiCup_A_R4_Evidence.zip` 解压后，将下列路径替换成含 `official/` 的目录。输出目录必须尚不存在。

```bash
python -B src/probes.py --evidence-root /path/to/HuaweiCup_A_R4_Evidence --output results/my-probes
python -B src/projection_counterexample.py --evidence-root /path/to/HuaweiCup_A_R4_Evidence --output results/my-projection
python -B src/check_guards.py --evidence-root /path/to/HuaweiCup_A_R4_Evidence --probe-results results/my-probes --output results/my-guards.json
```

这些定点工具只用Python标准库及旧包未修改的官方程序。不会启动GPU或读写仓库。所有新结果归属于本地新运行；不要改名冒充原Mac或R4历史运行。
