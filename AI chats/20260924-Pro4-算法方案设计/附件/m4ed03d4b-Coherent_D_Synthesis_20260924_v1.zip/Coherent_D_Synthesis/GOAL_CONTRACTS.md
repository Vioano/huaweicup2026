# 最终 /goal 完成契约：9个工作包，首批6卡

本轮不创建或启动任务。D0–D2先行准备，D3–D5依赖就绪后并行；D6–D8为条件下游。每张独立TXT已包含共同约束与固定SHA，可整体复制。

---

/goal D0 — 固定见证、指标与不改变语义的最小观测底座

阶段：首批/P0。本卡新评价上限：36（受共同全局额度及授权约束）。

## 每张卡的共同完成契约（随卡复制，不从聊天记忆补义）

本文件是D综合设计，当前没有任何Goal或实验被启动。只有队长明确分配此卡、确认写权和预算账本后才执行；旧Pro候选额度不构成本卡授权。任务开始先按固定归档版本读取AGENTS、当前任务和授权协作通知；不覆盖他人未提交改动，不自动发消息、创建服务或认领他人写域。

研究范围是三问共同框架，按卡声明的q/k特化。正文定义使用Glossary v1；D的Definition Amendments单列为提议。本卡显式附加runtime、合法性层级、动作参数和证据要求，不得反写原Glossary或作者历史结果。

基底固定ARCHIVE提交；跨分支源码按下表固定SHA读取，不能用main猜别支内容，也不能使用后来移动的HEAD冒充as-run。Codex使用本人已授权的组织主库/本地工作树；Pro材料仅通过Vioano镜像。下载/解压官方文件可以到独立只读材料目录，逐字节核验后使用，不修改官方源码、原图或固定config；不要重序列化原图后沿用旧hash。

先冻结protocol.json、RuntimeID、source/input/plan哈希、观测Φ/ρ、动作类、样本选择规则及资源额度。运行代码身份、读取快照和归档提交分别记。未安装或未授权的依赖/硬件不得自行换用；报告阻塞，不借新账号、Colab或GPU绕过。默认CPU、单评价worker。

**共同评价预算候选：首批全局最多96次实际评价执行，不是每卡96次。** 配额：D0=36、D1=0、D2=4、D3=16、D4=16、D5=16、中央保留8。E0、E1、native分账；每次真实后端完整评分尝试均扣一次，自动fallback若再次完整评分另扣一次；一次评分内部的Step1–3局部编译不重复当成E0次数，但须计时。plain/observed、重复、失败、超时、最终确认都计数。派发前预留最坏路由额度，只有确定未调用的预留可释放。中央保留及卡间转额须队长/指定协调者显式确认；卡内余额不允许事后开新族。D6–D8、D2模型阶段及D3 lag支线当前新增评价额度为0。

最多三个活跃研发session；同一性能宿主机的配对计时独占，普通诊断最多两个评价worker且受总内存许可，不由各session各自开满。RSS用整个相关进程组采样口径，报告共享页重计/短峰遗漏；阈值不是OS硬限。取消后清理子进程并持久化账本。

所有结果保留success、official_invalid、official_error、external_timeout、service_error、cancelled、not_evaluated、not_observed、proxy_abstain；禁止用0/无穷代替未知分数。ABSTAIN不是丢弃候选；unsupported不是官方invalid。最终可提交incumbent与探索frontier分离，只提升经本题相应E0确认的候选。

Makespan cycles与solver外层wall分别报告；在线读取/import/预处理/构造/检测/评分/回退/确认/IO/收尾均计入。独立事后裁判可另列，不能省掉在线E0。研究诊断成本单列，不与生产热路径混算。5–10分钟不是硬淘汰、最低运行时间或本队速度终点；限制评价次数也不自动把暴力变成结构化方法。

Q1/Q2正式曲线使用固定singlecore_evaluate基准，1核点按题面为1；算法优化的一核结果另表。Q3另列同核no-L2/cache比值和字节命中率；同plan机制对照与各自优化后的solver对照分开。配置变化只在独立诊断副本，不混进官方成绩。mean-of-ratios不是ratio-of-sums。

证据标明producer、完整性、本session核验方式、FORMAL/EMP/HYP、适用域。CRC/SHA不代表实验重跑；同一来源被多Pro引用不算独立重复。未读或未验标unknown。禁止事后修改guard、候选池、阈值来救结果；预注册假说被否定也是合格交付。

每卡交付目录必须有README、protocol、source/input manifest、事件/调用账本、输出计划与完整必需结果、失败/未评价记录、ACCEPTANCE.json以及逐项hash清单。原产物只读，新运行新目录，不覆盖。任何精确性差异立即隔离该域/快路径，按剩余额度提供最小反例或静态缩减说明；不自动新开Pro、Goal或追加实验。

依赖产物用其提交+manifest哈希绑定；依赖未冻结时可做只读/静态设计，不能猜文件内容或开始下游评价。完成后只交接，不自行触发Research DAG下一个节点。

### 冻结引用表

- ARCHIVE: `eaa15af9dde7365722e3b497df2fb869ff6e1c1e`
- Q1: `4dff90ef699fd51845cf482951e8477066f5f566`
- Q2_STRUCTURE: `74c46372faf5910b9b3cce6ad9a61a7e040b17aa`
- Q2_BUDGET: `0b58c123cccf02fc993b741d79dcd8511e4dd38f`
- Q3: `a4e7ee13310d693ec4fb5cc236669ceb3b172d1f`
- P1_EXACT: `5bfe53a29c1ba05167239f51ea937e602f7f85b4`
- P1_NATIVE: `03f02e79de4b4bd6f55241385664b154f4332454`
- P23_NATIVE: `603b0741e21c449d3db652ebd67c94f2dc014cc9`
- ERRATA: `e1575a1de5e3b921aef350e920720f0584fb1719`
- OFFICIAL_CODE_SHA256: `de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`

## 本卡专属契约

### 核心命题

准确输入身份、分层观测和现有官方结果能形成可信响应证据；只读观测不改变声明范围的官方结果。此卡不证明全局低维性。

### 固定代码与输入

ARCHIVE下docs/a/research/20260924-coherent-pro/{README.md,GLOSSARY_V1_SOURCE.md,ABC_LATEST_FULL.md}与全部三个ZIP；A包中的10份官方源码、case008/case044、word plan及29份既存结果；固定source-manifest与OFFICIAL_OBJECTIVES；ERRATA审查及语义探针只读。Q1/Q3其他完整计划/result按上述固定分支引用恢复。先复用已附材料，不从AUTHOR-REPORT猜原计划。

### 允许修改范围

新建research/a/coherent_d/D0_reference_observer/、tests/coherent_d/D0/、results/a/coherent_d/D0/<run_id>/。本卡是研究公共schema的唯一写者，发布环境/Plan身份封套、ObservationRecord、identity/call ledger接口v0；PlanIR/Operation/Receipt的内部schema由D1在独立命名空间负责。后续schema修改走显式amendment，不覆盖旧版本。

### 禁止改动

不改官方、config、原图、生产E1/E2和三个solver；不改Glossary v1；不排序或改ID后称原始等价；不把观察hook造成的事件变化写成官方事实；不把完整archive哈希核对替代实验验收。

### 实验协议

阶段0零新评价：核验三ZIP、三路全文、消息ID与运行身份；建立WITNESS_REGISTRY，填入每份G/P/q/k/C/H/R及基准/result/trace指针。将008-word同plan三问与113686另一Q1计划分表。恢复051/080等失败则保留AR缺口，不阻塞008已足够的部分。允许对全部100图做只读索引/简单图特征扫描，不能运行100个solver；大图精确width/同构搜索不在本卡。
阶段1先冻结至多18个plain/observed对：15对为三问×1–5核最小严格二部诊断面板，k>1须有实际多核活动（不能仅空核充数）；其余3对分别为已有L1重复incarnation、混合长度联合环、FIFO执行拒绝机制。合成域和正式case分开，图/计划在看到结果前确定。嵌入空核检查可由这些已保存产物的适用子项静态比较，不能假装未构造的嵌入已经测到。
observer只在原程序现有语义边界读取；L1/L2/L3/L4保存真实图/序列/spill/内存依赖，L5优先读取已有result/trace，必要的在飞状态才用最小hook。不新增数值事件切点，不把生成ID映射回logical后抹掉字面差异。保存字面diff与来源对齐diff两视图。每个plain/observed均由同R同I运行，完整结果及失败分类配对。
全部36次均在共同额度中；协议选定面板不足覆盖时报告缺口，不为满足计数补随机有利样本。

### 输出产物

schema-v0.json；WITNESS_REGISTRY.json；observer与只读使用说明；Φ/ρ字段来源表；原始/对齐diff；not_observed/unknown清单；配对完整结果、观察开销；输入/源码/运行清单。

### 验收指标

输入/计划/源码/结果身份逐项可追溯；008同plan与另一Q1计划不混；所声明plain/observed全字段类型、数值及列表顺序无未解释差异。CLI元数据对照单列规则，不无说明剔除。L3能表示spill_out=None、逐次version、L1/UB和Task局部backing。三问各核数触达记录真实，不声称正式全矩阵。

### 失败与停止条件

任何差异立即隔离对应观测能力，其他未验领域不继承通过；输入身份冲突停该W；36次/实验墙钟20分钟/进程组RSS4GiB任一达到即停止。若全L5过贵，可交付只读L1–L4加现成L5投影，并明确哪些下游任务不可开始，不能伪造空事件。

### 依赖

本次六份原件与固定源码；无新算法/可达性定理依赖。

### 并行与互斥

可与D1、D2静态阶段并行；共享schema本卡单写；plain/observed配对在同一宿主机独占评价时段。

### 资源预算

实现窗口建议2小时，超时交检查点；新评价≤36，全局96内；默认单CPU worker，实验墙钟≤20分钟，进程组4GiB采样停止，无GPU/云。

### 成功后解锁

D3/D4/D5所需的逐字段观测能力与固定见证；D2的缓存/路由核验；D6响应统计。未覆盖字段只解锁不依赖该字段的任务。


---

/goal D1 — 薄操作IR、结构可达证明与评分/搜索双账本

阶段：首批/P0。本卡新评价上限：0（受共同全局额度及授权约束）。

## 每张卡的共同完成契约（随卡复制，不从聊天记忆补义）

本文件是D综合设计，当前没有任何Goal或实验被启动。只有队长明确分配此卡、确认写权和预算账本后才执行；旧Pro候选额度不构成本卡授权。任务开始先按固定归档版本读取AGENTS、当前任务和授权协作通知；不覆盖他人未提交改动，不自动发消息、创建服务或认领他人写域。

研究范围是三问共同框架，按卡声明的q/k特化。正文定义使用Glossary v1；D的Definition Amendments单列为提议。本卡显式附加runtime、合法性层级、动作参数和证据要求，不得反写原Glossary或作者历史结果。

基底固定ARCHIVE提交；跨分支源码按下表固定SHA读取，不能用main猜别支内容，也不能使用后来移动的HEAD冒充as-run。Codex使用本人已授权的组织主库/本地工作树；Pro材料仅通过Vioano镜像。下载/解压官方文件可以到独立只读材料目录，逐字节核验后使用，不修改官方源码、原图或固定config；不要重序列化原图后沿用旧hash。

先冻结protocol.json、RuntimeID、source/input/plan哈希、观测Φ/ρ、动作类、样本选择规则及资源额度。运行代码身份、读取快照和归档提交分别记。未安装或未授权的依赖/硬件不得自行换用；报告阻塞，不借新账号、Colab或GPU绕过。默认CPU、单评价worker。

**共同评价预算候选：首批全局最多96次实际评价执行，不是每卡96次。** 配额：D0=36、D1=0、D2=4、D3=16、D4=16、D5=16、中央保留8。E0、E1、native分账；每次真实后端完整评分尝试均扣一次，自动fallback若再次完整评分另扣一次；一次评分内部的Step1–3局部编译不重复当成E0次数，但须计时。plain/observed、重复、失败、超时、最终确认都计数。派发前预留最坏路由额度，只有确定未调用的预留可释放。中央保留及卡间转额须队长/指定协调者显式确认；卡内余额不允许事后开新族。D6–D8、D2模型阶段及D3 lag支线当前新增评价额度为0。

最多三个活跃研发session；同一性能宿主机的配对计时独占，普通诊断最多两个评价worker且受总内存许可，不由各session各自开满。RSS用整个相关进程组采样口径，报告共享页重计/短峰遗漏；阈值不是OS硬限。取消后清理子进程并持久化账本。

所有结果保留success、official_invalid、official_error、external_timeout、service_error、cancelled、not_evaluated、not_observed、proxy_abstain；禁止用0/无穷代替未知分数。ABSTAIN不是丢弃候选；unsupported不是官方invalid。最终可提交incumbent与探索frontier分离，只提升经本题相应E0确认的候选。

Makespan cycles与solver外层wall分别报告；在线读取/import/预处理/构造/检测/评分/回退/确认/IO/收尾均计入。独立事后裁判可另列，不能省掉在线E0。研究诊断成本单列，不与生产热路径混算。5–10分钟不是硬淘汰、最低运行时间或本队速度终点；限制评价次数也不自动把暴力变成结构化方法。

Q1/Q2正式曲线使用固定singlecore_evaluate基准，1核点按题面为1；算法优化的一核结果另表。Q3另列同核no-L2/cache比值和字节命中率；同plan机制对照与各自优化后的solver对照分开。配置变化只在独立诊断副本，不混进官方成绩。mean-of-ratios不是ratio-of-sums。

证据标明producer、完整性、本session核验方式、FORMAL/EMP/HYP、适用域。CRC/SHA不代表实验重跑；同一来源被多Pro引用不算独立重复。未读或未验标unknown。禁止事后修改guard、候选池、阈值来救结果；预注册假说被否定也是合格交付。

每卡交付目录必须有README、protocol、source/input manifest、事件/调用账本、输出计划与完整必需结果、失败/未评价记录、ACCEPTANCE.json以及逐项hash清单。原产物只读，新运行新目录，不覆盖。任何精确性差异立即隔离该域/快路径，按剩余额度提供最小反例或静态缩减说明；不自动新开Pro、Goal或追加实验。

依赖产物用其提交+manifest哈希绑定；依赖未冻结时可做只读/静态设计，不能猜文件内容或开始下游评价。完成后只交接，不自行触发Research DAG下一个节点。

### 冻结引用表

- ARCHIVE: `eaa15af9dde7365722e3b497df2fb869ff6e1c1e`
- Q1: `4dff90ef699fd51845cf482951e8477066f5f566`
- Q2_STRUCTURE: `74c46372faf5910b9b3cce6ad9a61a7e040b17aa`
- Q2_BUDGET: `0b58c123cccf02fc993b741d79dcd8511e4dd38f`
- Q3: `a4e7ee13310d693ec4fb5cc236669ceb3b172d1f`
- P1_EXACT: `5bfe53a29c1ba05167239f51ea937e602f7f85b4`
- P1_NATIVE: `03f02e79de4b4bd6f55241385664b154f4332454`
- P23_NATIVE: `603b0741e21c449d3db652ebd67c94f2dc014cc9`
- ERRATA: `e1575a1de5e3b921aef350e920720f0584fb1719`
- OFFICIAL_CODE_SHA256: `de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`

## 本卡专属契约

### 核心命题

CUT/JOIN/SPLICE及受限RECODE能在明确P_ord域表达结构方案；receipt可精确回滚；当前评分缓存不会删掉未来编辑能力不同的搜索代表。

### 固定代码与输入

ARCHIVE Glossary及C完整回答/ZIP结构脚本；Q1 src/q1/{neighborhood.py,structure.py,release_ideals.py}；Q3 src/q3/construct.py；D0 schema-v0（其冻结前仅设计）。使用所附实际word/component/affine计划及小抽象DAG。

### 允许修改范围

research/a/coherent_d/D1_plan_ops/、tests/coherent_d/D1/、results/a/coherent_d/D1/。不新建重型统一平台；提供四schema、apply/receipt/undo、确定性lowering和最薄frontier/score-cache接口。

### 禁止改动

不得改原constructor策略、owner、ID或候选顺序；禁止REPLACE_PLAN假完备；不修改G中op/tensor ID；不把结构证书贴成exec-certified；不丢弃相同当前分数但动作能力不同的代表。

### 实验协议

零E0/E1/native。静态审核C证明，并将目标拓扑序修正为目标数据+核序联合图的线性扩张；声明规范十进制op键与受限编码域。空图单列，不以5n操作界宣称solver线性。
复用C已存150环境结果作输入核验；独立测试允许有界扩展到最多100000个结构状态/2000000条边/120秒（先到即停），不要求达到上限。记录这是新纯结构检查而非官方实验。
验证apply/undo的字段类型、标签、列表和mapping插入序；过期parent、ID冲突、已移除后gap、同核与跨核SPLICE、非理想CUT及非cover JOIN有正负例。动作参数实例/表示域显式化。
将至少component→word的已给目标plan转换为一次原子macro事务中的primitive程序；只构造不评分。中间结构合法但执行未知，最终字面plan必须匹配指定目标hash。通过并非要求日后在线逐步执行/编译这些证明路径。
将ScoreCache和SearchFrontier分成两接口，用A既存24态反例验证相同评分key不能自动删除另一代表；这里无需新E0。

### 输出产物

PlanIR/Operation/Receipt schema；四模式与测试；P_ord构造性证明及目标联合序修正；路径复杂度/编码限制；lowering字面一致报告；双账本回归。

### 验收指标

回滚恢复精确有序对象且持久化规则明确；操作失败不污染parent；全部结构判断与独立DAG判据一致；无P_exec完备夸大；目标plan字节一致或明确区分格式bytes与有序对象，不能偷改原hash。

### 失败与停止条件

首个反例停止相应普遍证明；两次小设计调整仍无法表达就给最小缺口，不扩展成通用语言平台。结构检查到时间/状态上限即交有界结果。

### 依赖

D0环境/计划schema的冻结接口；数学静态阅读可先行。

### 并行与互斥

与D0/D2并行但不共同改schema；下游只能读本卡发布manifest，不引用未提交工作树。

### 资源预算

新评价0；建议2小时实现窗口，纯结构测试≤120秒，单CPU，2GiB采样停止，无GPU。

### 成功后解锁

D3/D4/D5可重放的macro/反事实；D7受限等价研究；D6 continuation。它不是其他机制研究必须先证明全域完备的门槛。


---

/goal D2 — 编译复用、后端能力与真实费用；不默认增加局部模型

阶段：首批/P0静态＋可选小shadow。本卡新评价上限：4（受共同全局额度及授权约束）。

## 每张卡的共同完成契约（随卡复制，不从聊天记忆补义）

本文件是D综合设计，当前没有任何Goal或实验被启动。只有队长明确分配此卡、确认写权和预算账本后才执行；旧Pro候选额度不构成本卡授权。任务开始先按固定归档版本读取AGENTS、当前任务和授权协作通知；不覆盖他人未提交改动，不自动发消息、创建服务或认领他人写域。

研究范围是三问共同框架，按卡声明的q/k特化。正文定义使用Glossary v1；D的Definition Amendments单列为提议。本卡显式附加runtime、合法性层级、动作参数和证据要求，不得反写原Glossary或作者历史结果。

基底固定ARCHIVE提交；跨分支源码按下表固定SHA读取，不能用main猜别支内容，也不能使用后来移动的HEAD冒充as-run。Codex使用本人已授权的组织主库/本地工作树；Pro材料仅通过Vioano镜像。下载/解压官方文件可以到独立只读材料目录，逐字节核验后使用，不修改官方源码、原图或固定config；不要重序列化原图后沿用旧hash。

先冻结protocol.json、RuntimeID、source/input/plan哈希、观测Φ/ρ、动作类、样本选择规则及资源额度。运行代码身份、读取快照和归档提交分别记。未安装或未授权的依赖/硬件不得自行换用；报告阻塞，不借新账号、Colab或GPU绕过。默认CPU、单评价worker。

**共同评价预算候选：首批全局最多96次实际评价执行，不是每卡96次。** 配额：D0=36、D1=0、D2=4、D3=16、D4=16、D5=16、中央保留8。E0、E1、native分账；每次真实后端完整评分尝试均扣一次，自动fallback若再次完整评分另扣一次；一次评分内部的Step1–3局部编译不重复当成E0次数，但须计时。plain/observed、重复、失败、超时、最终确认都计数。派发前预留最坏路由额度，只有确定未调用的预留可释放。中央保留及卡间转额须队长/指定协调者显式确认；卡内余额不允许事后开新族。D6–D8、D2模型阶段及D3 lag支线当前新增评价额度为0。

最多三个活跃研发session；同一性能宿主机的配对计时独占，普通诊断最多两个评价worker且受总内存许可，不由各session各自开满。RSS用整个相关进程组采样口径，报告共享页重计/短峰遗漏；阈值不是OS硬限。取消后清理子进程并持久化账本。

所有结果保留success、official_invalid、official_error、external_timeout、service_error、cancelled、not_evaluated、not_observed、proxy_abstain；禁止用0/无穷代替未知分数。ABSTAIN不是丢弃候选；unsupported不是官方invalid。最终可提交incumbent与探索frontier分离，只提升经本题相应E0确认的候选。

Makespan cycles与solver外层wall分别报告；在线读取/import/预处理/构造/检测/评分/回退/确认/IO/收尾均计入。独立事后裁判可另列，不能省掉在线E0。研究诊断成本单列，不与生产热路径混算。5–10分钟不是硬淘汰、最低运行时间或本队速度终点；限制评价次数也不自动把暴力变成结构化方法。

Q1/Q2正式曲线使用固定singlecore_evaluate基准，1核点按题面为1；算法优化的一核结果另表。Q3另列同核no-L2/cache比值和字节命中率；同plan机制对照与各自优化后的solver对照分开。配置变化只在独立诊断副本，不混进官方成绩。mean-of-ratios不是ratio-of-sums。

证据标明producer、完整性、本session核验方式、FORMAL/EMP/HYP、适用域。CRC/SHA不代表实验重跑；同一来源被多Pro引用不算独立重复。未读或未验标unknown。禁止事后修改guard、候选池、阈值来救结果；预注册假说被否定也是合格交付。

每卡交付目录必须有README、protocol、source/input manifest、事件/调用账本、输出计划与完整必需结果、失败/未评价记录、ACCEPTANCE.json以及逐项hash清单。原产物只读，新运行新目录，不覆盖。任何精确性差异立即隔离该域/快路径，按剩余额度提供最小反例或静态缩减说明；不自动新开Pro、Goal或追加实验。

依赖产物用其提交+manifest哈希绑定；依赖未冻结时可做只读/静态设计，不能猜文件内容或开始下游评价。完成后只交接，不自行触发Research DAG下一个节点。

### 冻结引用表

- ARCHIVE: `eaa15af9dde7365722e3b497df2fb869ff6e1c1e`
- Q1: `4dff90ef699fd51845cf482951e8477066f5f566`
- Q2_STRUCTURE: `74c46372faf5910b9b3cce6ad9a61a7e040b17aa`
- Q2_BUDGET: `0b58c123cccf02fc993b741d79dcd8511e4dd38f`
- Q3: `a4e7ee13310d693ec4fb5cc236669ceb3b172d1f`
- P1_EXACT: `5bfe53a29c1ba05167239f51ea937e602f7f85b4`
- P1_NATIVE: `03f02e79de4b4bd6f55241385664b154f4332454`
- P23_NATIVE: `603b0741e21c449d3db652ebd67c94f2dc014cc9`
- ERRATA: `e1575a1de5e3b921aef350e920720f0584fb1719`
- OFFICIAL_CODE_SHA256: `de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`

## 本卡专属契约

### 核心命题

可复用编译输入与真实后端路径能够精确声明；官方编译+原生重放与旧近似E2按能力而非名字区分。局部专家只有比现有路径更划算才值得后续开发。

### 固定代码与输入

P1_EXACT docs/a/exact/P1_BATCH.md、src/eval_exact/{batch.py,_scene_a.py,problem1.py}；P1_NATIVE research/a/native-replay-20260924/；P23_NATIVE research/a/e2_search/{P23_HANDOFF.md,scene_b.py,_native_b.py,_official_b.py}及其被调用源；D0现有计划/结果身份。没有逐行读过C++时必须标未审。

### 允许修改范围

research/a/coherent_d/D2_capabilities/、tests/coherent_d/D2/、results/a/coherent_d/D2/。只做能力manifest、独立比较包装器及mock路由；禁止接管生产evaluator。

### 禁止改动

不放宽精确性/数字域，不删事件，不替换生产cache key，不用metrics冒充full，不把P1后端换problem参数用于P23，不用native_enabled当不调用E0的保证。

### 实验协议

阶段0零新评价：按入口递归读到实际调用，能力表必须含q/k/H/R、输入数字域、prepared key、输出级别、fallback原函数、自动回退次数、验收范围。将全局评分和局部编译成本分开；既有性能只能标作者记录。对Q1给固定有序mapping复用的输入依赖表；对Q2/Q3给更强局部图+优先序条件，新增ID失效传播明确。
以mock验证full/fallback/unsupported/timeout路径的费用预留及错误分类；不是官方性能证据。读取已存当前程序/score-cache hit时不删除frontier能力。
可用≤4次评价做两条匹配输入的E0/支持后端shadow配对。调用fallback会额外扣费，额度不足不发。参考输入来自D0已完整记录的小计划；两对不足以宣称后端发布验收或稳定速度。真实构建/加载失败直接报告并保留E0路径，不擅自迁平台。
第二阶段局部专家当前不执行：只有D6标签显示可预测区、当前成本表显示能回本且另获预算时，比较最多两个低复杂度Δ/排序专家与exact-only；按图/父计划留出，detector前置信息、ABSTAIN与挑战槽预注册。

### 输出产物

CAPABILITIES.json；源函数与缓存key依赖表；route-to-actual-call账本；成本分段及仅作者报告范围；mock故障测试；小shadow完整差分；local-expert的Go/Conditional/No-Go门槛建议。

### 验收指标

每一后端能力可追溯到固定实现/输出；full与fallback实际费用显式；无能力证明默认E0；4次shadow结果不扩大为全平台/全域通过。是否模型化首先回答省掉哪段实际成本。

### 失败与停止条件

精确差异立即禁用该shadow域；检测/准备成本不优于精评则No-Go相应代理，不修改原评分器救结果；缺本地库不自动构建或消耗云资源。

### 依赖

D0身份/观测，D1双账本约束；静态能力阅读可先行。模型阶段额外依赖D6标签、校准协议与新授权。

### 并行与互斥

静态阶段与D0/D1并行；计时独占；不占用生产E1/E2 owner写域；D3–D5不必等本卡提速成功，可用E0。

### 资源预算

新评价≤4，全局96内；建议90分钟实现/静态窗口，shadow实验≤10分钟、单worker、4GiB采样停止。新训练/大批benchmark0。

### 成功后解锁

安全exact-first路由和编译上下文分组；后续局部专家是否必要的有成本依据决策。


---

/goal D3 — Q2/Q3重入峰值迁移及可重放宏

阶段：首批/P1，依赖闸门后。本卡新评价上限：16（受共同全局额度及授权约束）。

## 每张卡的共同完成契约（随卡复制，不从聊天记忆补义）

本文件是D综合设计，当前没有任何Goal或实验被启动。只有队长明确分配此卡、确认写权和预算账本后才执行；旧Pro候选额度不构成本卡授权。任务开始先按固定归档版本读取AGENTS、当前任务和授权协作通知；不覆盖他人未提交改动，不自动发消息、创建服务或认领他人写域。

研究范围是三问共同框架，按卡声明的q/k特化。正文定义使用Glossary v1；D的Definition Amendments单列为提议。本卡显式附加runtime、合法性层级、动作参数和证据要求，不得反写原Glossary或作者历史结果。

基底固定ARCHIVE提交；跨分支源码按下表固定SHA读取，不能用main猜别支内容，也不能使用后来移动的HEAD冒充as-run。Codex使用本人已授权的组织主库/本地工作树；Pro材料仅通过Vioano镜像。下载/解压官方文件可以到独立只读材料目录，逐字节核验后使用，不修改官方源码、原图或固定config；不要重序列化原图后沿用旧hash。

先冻结protocol.json、RuntimeID、source/input/plan哈希、观测Φ/ρ、动作类、样本选择规则及资源额度。运行代码身份、读取快照和归档提交分别记。未安装或未授权的依赖/硬件不得自行换用；报告阻塞，不借新账号、Colab或GPU绕过。默认CPU、单评价worker。

**共同评价预算候选：首批全局最多96次实际评价执行，不是每卡96次。** 配额：D0=36、D1=0、D2=4、D3=16、D4=16、D5=16、中央保留8。E0、E1、native分账；每次真实后端完整评分尝试均扣一次，自动fallback若再次完整评分另扣一次；一次评分内部的Step1–3局部编译不重复当成E0次数，但须计时。plain/observed、重复、失败、超时、最终确认都计数。派发前预留最坏路由额度，只有确定未调用的预留可释放。中央保留及卡间转额须队长/指定协调者显式确认；卡内余额不允许事后开新族。D6–D8、D2模型阶段及D3 lag支线当前新增评价额度为0。

最多三个活跃研发session；同一性能宿主机的配对计时独占，普通诊断最多两个评价worker且受总内存许可，不由各session各自开满。RSS用整个相关进程组采样口径，报告共享页重计/短峰遗漏；阈值不是OS硬限。取消后清理子进程并持久化账本。

所有结果保留success、official_invalid、official_error、external_timeout、service_error、cancelled、not_evaluated、not_observed、proxy_abstain；禁止用0/无穷代替未知分数。ABSTAIN不是丢弃候选；unsupported不是官方invalid。最终可提交incumbent与探索frontier分离，只提升经本题相应E0确认的候选。

Makespan cycles与solver外层wall分别报告；在线读取/import/预处理/构造/检测/评分/回退/确认/IO/收尾均计入。独立事后裁判可另列，不能省掉在线E0。研究诊断成本单列，不与生产热路径混算。5–10分钟不是硬淘汰、最低运行时间或本队速度终点；限制评价次数也不自动把暴力变成结构化方法。

Q1/Q2正式曲线使用固定singlecore_evaluate基准，1核点按题面为1；算法优化的一核结果另表。Q3另列同核no-L2/cache比值和字节命中率；同plan机制对照与各自优化后的solver对照分开。配置变化只在独立诊断副本，不混进官方成绩。mean-of-ratios不是ratio-of-sums。

证据标明producer、完整性、本session核验方式、FORMAL/EMP/HYP、适用域。CRC/SHA不代表实验重跑；同一来源被多Pro引用不算独立重复。未读或未验标unknown。禁止事后修改guard、候选池、阈值来救结果；预注册假说被否定也是合格交付。

每卡交付目录必须有README、protocol、source/input manifest、事件/调用账本、输出计划与完整必需结果、失败/未评价记录、ACCEPTANCE.json以及逐项hash清单。原产物只读，新运行新目录，不覆盖。任何精确性差异立即隔离该域/快路径，按剩余额度提供最小反例或静态缩减说明；不自动新开Pro、Goal或追加实验。

依赖产物用其提交+manifest哈希绑定；依赖未冻结时可做只读/静态设计，不能猜文件内容或开始下游评价。完成后只交接，不自行触发Research DAG下一个节点。

### 冻结引用表

- ARCHIVE: `eaa15af9dde7365722e3b497df2fb869ff6e1c1e`
- Q1: `4dff90ef699fd51845cf482951e8477066f5f566`
- Q2_STRUCTURE: `74c46372faf5910b9b3cce6ad9a61a7e040b17aa`
- Q2_BUDGET: `0b58c123cccf02fc993b741d79dcd8511e4dd38f`
- Q3: `a4e7ee13310d693ec4fb5cc236669ceb3b172d1f`
- P1_EXACT: `5bfe53a29c1ba05167239f51ea937e602f7f85b4`
- P1_NATIVE: `03f02e79de4b4bd6f55241385664b154f4332454`
- P23_NATIVE: `603b0741e21c449d3db652ebd67c94f2dc014cc9`
- ERRATA: `e1575a1de5e3b921aef350e920720f0584fb1719`
- OFFICIAL_CODE_SHA256: `de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`

## 本卡专属契约

### 核心命题

case008的近资源下界结果源于一个可定义的计算/张量条件下的资源词构造，而不是“任意M-V-M必快”或L2命中。正域外要可预期失败或退出。

### 固定代码与输入

Q3 src/q3/construct.py及METHOD；A包完整case008、同word plan及Q2/Q3结果；B包component/affine/word原计划、编辑距离及UNVALIDATED邻居；Q2_STRUCTURE与Q2_BUDGET的普通/退化报告仅作来源，原结果需D0补齐。D0只读图扫描给两个新匹配/反匹配实例，规则先冻结。

### 允许修改范围

research/a/coherent_d/D3_reentry/、tests/coherent_d/D3/、results/a/coherent_d/D3/。一个研究宏、图detector和primitive lowering；不改生产construct。

### 禁止改动

不按case文件名选策略；不以计算模板检查冒充完整张量同构；不把初始priority坐标当实际开始时刻；不因7.65倍把全部收益归于Cache或并行；不直接使用B未验证邻居作成绩。

### 实验协议

先零新评价回读008完整参考，核对M工作/资源下界及Q3全miss。冻结guard：真正串行计算模板、首尾时长与中间总量、每核job数量；tensor support/size/pos另列，不声称自动相同。
新评价最多四个父环境（每个为具体G与k），每环境普通/word两plan×Q2/Q3=4次，总≤16。建议两环境来自至少两个未用于挑guard的正式匹配图；其余为保持计算总量但改变重入/共享support/tensor尺寸的严格二部反匹配副本。无新匹配图则报告覆盖不足，不能复制008改种子装作跨图。
每环境固定同partition和owner，只改声明的priority。先验证有序plan，再E0；owner/ID/映射序不控制则本对照作废。用D0快照核对M等待V、COPY、MEM依赖与全局时间，若不能完整归因，明确只支持总效应。
已有B单插入候选可以作为四环境中一个预注册局部对，但其预算替换其他配额而非追加；评价前必须恢复完整G并做合法检查。不能把word替换这一大宏称小敏感方向。
lag区间PB06不纳入当前评价：只在真正计划开启lag参数族且另获批准时，比较精确cell生成与parameter-scan+plan-hash-dedup，分母是distinct plans。

### 输出产物

graph/mapping guard；普通/word对照原件及primitive program；near-bound参照；M/V/COPY/MEM响应表；全miss对照；迁移/反匹配表；macro candidate或明确限定的基线。

### 验收指标

字面lowering与目标plan一致；证据可辨计算模板和张量结构；新正域改善与最差退化完整报告。首轮可用“相对同核普通方案≥10%”作探索标志，但两图四环境不宣布普适80%成功率。至少一个新实例支持或清楚否定已冻结迁移预测，均可完成研究卡。部署Go还要D6独立覆盖/成本验收。

### 失败与停止条件

只在008有效则保留参数局部/未分类，不强称structural；同guard反例出现就收紧或拒绝，不倒写阈值；观测缺MEM/COPY不能宣称V唯一因果。到16次/20分钟/RSS4GiB停止。

### 依赖

D0见证与所需观测能力，D1薄操作/receipt；D2仅用于已有支持域，否则E0。

### 并行与互斥

可与D4、D5独立开发；各自目录及账本；配对计时预约独占，不共享可变Task/Cache。

### 资源预算

实现窗口建议2小时；最多16次评价，全局96内，每次默认30秒外部保护（超时是删失），实验≤20分钟，单CPU、4GiB，无GPU。

### 成功后解锁

资源重入guarded macro候选；D6多核轨迹；D8低成本直接构造。


---

/goal D4 — Q1非前缀释放理想与backing边界的联合候选设计

阶段：首批/P1，依赖闸门后。本卡新评价上限：16（受共同全局额度及授权约束）。

## 每张卡的共同完成契约（随卡复制，不从聊天记忆补义）

本文件是D综合设计，当前没有任何Goal或实验被启动。只有队长明确分配此卡、确认写权和预算账本后才执行；旧Pro候选额度不构成本卡授权。任务开始先按固定归档版本读取AGENTS、当前任务和授权协作通知；不覆盖他人未提交改动，不自动发消息、创建服务或认领他人写域。

研究范围是三问共同框架，按卡声明的q/k特化。正文定义使用Glossary v1；D的Definition Amendments单列为提议。本卡显式附加runtime、合法性层级、动作参数和证据要求，不得反写原Glossary或作者历史结果。

基底固定ARCHIVE提交；跨分支源码按下表固定SHA读取，不能用main猜别支内容，也不能使用后来移动的HEAD冒充as-run。Codex使用本人已授权的组织主库/本地工作树；Pro材料仅通过Vioano镜像。下载/解压官方文件可以到独立只读材料目录，逐字节核验后使用，不修改官方源码、原图或固定config；不要重序列化原图后沿用旧hash。

先冻结protocol.json、RuntimeID、source/input/plan哈希、观测Φ/ρ、动作类、样本选择规则及资源额度。运行代码身份、读取快照和归档提交分别记。未安装或未授权的依赖/硬件不得自行换用；报告阻塞，不借新账号、Colab或GPU绕过。默认CPU、单评价worker。

**共同评价预算候选：首批全局最多96次实际评价执行，不是每卡96次。** 配额：D0=36、D1=0、D2=4、D3=16、D4=16、D5=16、中央保留8。E0、E1、native分账；每次真实后端完整评分尝试均扣一次，自动fallback若再次完整评分另扣一次；一次评分内部的Step1–3局部编译不重复当成E0次数，但须计时。plain/observed、重复、失败、超时、最终确认都计数。派发前预留最坏路由额度，只有确定未调用的预留可释放。中央保留及卡间转额须队长/指定协调者显式确认；卡内余额不允许事后开新族。D6–D8、D2模型阶段及D3 lag支线当前新增评价额度为0。

最多三个活跃研发session；同一性能宿主机的配对计时独占，普通诊断最多两个评价worker且受总内存许可，不由各session各自开满。RSS用整个相关进程组采样口径，报告共享页重计/短峰遗漏；阈值不是OS硬限。取消后清理子进程并持久化账本。

所有结果保留success、official_invalid、official_error、external_timeout、service_error、cancelled、not_evaluated、not_observed、proxy_abstain；禁止用0/无穷代替未知分数。ABSTAIN不是丢弃候选；unsupported不是官方invalid。最终可提交incumbent与探索frontier分离，只提升经本题相应E0确认的候选。

Makespan cycles与solver外层wall分别报告；在线读取/import/预处理/构造/检测/评分/回退/确认/IO/收尾均计入。独立事后裁判可另列，不能省掉在线E0。研究诊断成本单列，不与生产热路径混算。5–10分钟不是硬淘汰、最低运行时间或本队速度终点；限制评价次数也不自动把暴力变成结构化方法。

Q1/Q2正式曲线使用固定singlecore_evaluate基准，1核点按题面为1；算法优化的一核结果另表。Q3另列同核no-L2/cache比值和字节命中率；同plan机制对照与各自优化后的solver对照分开。配置变化只在独立诊断副本，不混进官方成绩。mean-of-ratios不是ratio-of-sums。

证据标明producer、完整性、本session核验方式、FORMAL/EMP/HYP、适用域。CRC/SHA不代表实验重跑；同一来源被多Pro引用不算独立重复。未读或未验标unknown。禁止事后修改guard、候选池、阈值来救结果；预注册假说被否定也是合格交付。

每卡交付目录必须有README、protocol、source/input manifest、事件/调用账本、输出计划与完整必需结果、失败/未评价记录、ACCEPTANCE.json以及逐项hash清单。原产物只读，新运行新目录，不覆盖。任何精确性差异立即隔离该域/快路径，按剩余额度提供最小反例或静态缩减说明；不自动新开Pro、Goal或追加实验。

依赖产物用其提交+manifest哈希绑定；依赖未冻结时可做只读/静态设计，不能猜文件内容或开始下游评价。完成后只交接，不自行触发Research DAG下一个节点。

### 冻结引用表

- ARCHIVE: `eaa15af9dde7365722e3b497df2fb869ff6e1c1e`
- Q1: `4dff90ef699fd51845cf482951e8477066f5f566`
- Q2_STRUCTURE: `74c46372faf5910b9b3cce6ad9a61a7e040b17aa`
- Q2_BUDGET: `0b58c123cccf02fc993b741d79dcd8511e4dd38f`
- Q3: `a4e7ee13310d693ec4fb5cc236669ceb3b172d1f`
- P1_EXACT: `5bfe53a29c1ba05167239f51ea937e602f7f85b4`
- P1_NATIVE: `03f02e79de4b4bd6f55241385664b154f4332454`
- P23_NATIVE: `603b0741e21c449d3db652ebd67c94f2dc014cc9`
- ERRATA: `e1575a1de5e3b921aef350e920720f0584fb1719`
- OFFICIAL_CODE_SHA256: `de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`

## 本卡专属契约

### 核心命题

通过依赖理想直接选成员，可以产生旧Step1真前缀生成器没覆盖的释放机会；收益须扣除新增Task等待、真实COPY、延迟出口及backing/spill变化，而非仅减少流量。

### 固定代码与输入

Q1 src/q1/{release_ideals.py,profile_candidates.py,profile_refine.py}及Q1_RELEASE_IDEALS_REVIEW、TRACE_EXPLANATION、TRACE_PROSPECTIVE；051旧父/cut4/cut5，044好坏merge/零spill坏split；ERRATA L1 backing探针。原计划/结果未取得时由D0标阻塞，不照文本自行造同名计划。

### 允许修改范围

research/a/coherent_d/D4_release/、tests/coherent_d/D4/、results/a/coherent_d/D4/。只做研究生成器及profile消费者；不改Q1默认solver、不并行改共享observer。

### 禁止改动

不提交Task内部op顺序；不继承跨Task私有backing；不把局部Step3时长作下界；不按零spill/最小cut硬删；不把min-cut代理最优当Makespan最优；不继续仅对全零提前量旧候选调权重。

### 实验协议

零新评价先审核已有051/044机制记录；分清当前父时间线、入口控制前驱及早出口。成员候选必须是内部偏序理想，可为非旧Step1前缀；旧前缀只作基线。至少包含一种“输入提前量为零但可能提前远端出口”的候选规则，防止入口单指标盲区。
冻结三个父环境（051已见对照＋两个未用来选规则的父计划，核数可从2/4/5中预选），每环境父plan+两旧规则候选+两新理想/出口候选，共5次；合计≤15次，余1次仅预留预注册确认/失败，不增新族。两生成器使用相同候选槽和精评上限；记录实际成本，不用同上限冒充同用量。
每次CUT同核相邻；JOIN只在完整数据+核链cover域；产生新计划后重新官方构图Step1/2/3。计算真实预spill边界，并按每Task初始backing/是否实际写回/pos/version记录条件spill。旧父冻结release标签只用于提议；接受新父后必须失效。
小整数min-cut只求原文定义的boundary/work代理；如无充分信息/容量溢出则退回直接理想/出口候选，不能假称图无解。源码检测及既存反例解释计入研究成本，在线候选生成成本另给。

### 输出产物

旧/新候选的成员与receipt；非前缀见证；入口/出口gate说明；真实boundary/backing/spill表；每候选完整结果、incumbent按调用/墙钟轨迹；可部署或停止的决定。

### 验收指标

至少明确检验一种旧前缀无法覆盖的候选，并在新父计划上形成可证伪预测；检查联合DAG但不声称P_exec必成功。条件spill字节逐记录与官方匹配；总收益和中介机制分开。同预算有净收益才建议接入；全失败或全部零机会也可作为负交付，不能用051单例替代迁移。

### 失败与停止条件

依赖源材料缺失则停止该W；标签过期、旧backing继承、非理想CUT出现即拒绝生成逻辑；三父环境无覆盖增量则暂缓，不开全切点搜索。16次/20分钟/RSS4GiB任一达到停止。

### 依赖

D0原始Q1见证与L1–L4/gate观测；D1 CUT/JOIN/receipt；可用E0不依赖D2提速。

### 并行与互斥

与D3/D5可并行；本卡统一负责原PB02与PB03，避免两个session分别改同一Q1候选生成器。

### 资源预算

建议2小时实现窗口；新评价≤16，全局96内，单CPU、4GiB，实验≤20分钟，每调用30秒保护可按预注册大图单独声明；不授权整批正式图。

### 成功后解锁

Q1 ReleaseIdeal/ExitClosure宏及backing-aware风险特征；失败可明确排除无用候选/排序，而非回到固定2×size错误。


---

/goal D5 — Q3 Cache相位与排名翻转：从同plan对照到预先预测

阶段：首批/P1，依赖闸门后。本卡新评价上限：16（受共同全局额度及授权约束）。

## 每张卡的共同完成契约（随卡复制，不从聊天记忆补义）

本文件是D综合设计，当前没有任何Goal或实验被启动。只有队长明确分配此卡、确认写权和预算账本后才执行；旧Pro候选额度不构成本卡授权。任务开始先按固定归档版本读取AGENTS、当前任务和授权协作通知；不覆盖他人未提交改动，不自动发消息、创建服务或认领他人写域。

研究范围是三问共同框架，按卡声明的q/k特化。正文定义使用Glossary v1；D的Definition Amendments单列为提议。本卡显式附加runtime、合法性层级、动作参数和证据要求，不得反写原Glossary或作者历史结果。

基底固定ARCHIVE提交；跨分支源码按下表固定SHA读取，不能用main猜别支内容，也不能使用后来移动的HEAD冒充as-run。Codex使用本人已授权的组织主库/本地工作树；Pro材料仅通过Vioano镜像。下载/解压官方文件可以到独立只读材料目录，逐字节核验后使用，不修改官方源码、原图或固定config；不要重序列化原图后沿用旧hash。

先冻结protocol.json、RuntimeID、source/input/plan哈希、观测Φ/ρ、动作类、样本选择规则及资源额度。运行代码身份、读取快照和归档提交分别记。未安装或未授权的依赖/硬件不得自行换用；报告阻塞，不借新账号、Colab或GPU绕过。默认CPU、单评价worker。

**共同评价预算候选：首批全局最多96次实际评价执行，不是每卡96次。** 配额：D0=36、D1=0、D2=4、D3=16、D4=16、D5=16、中央保留8。E0、E1、native分账；每次真实后端完整评分尝试均扣一次，自动fallback若再次完整评分另扣一次；一次评分内部的Step1–3局部编译不重复当成E0次数，但须计时。plain/observed、重复、失败、超时、最终确认都计数。派发前预留最坏路由额度，只有确定未调用的预留可释放。中央保留及卡间转额须队长/指定协调者显式确认；卡内余额不允许事后开新族。D6–D8、D2模型阶段及D3 lag支线当前新增评价额度为0。

最多三个活跃研发session；同一性能宿主机的配对计时独占，普通诊断最多两个评价worker且受总内存许可，不由各session各自开满。RSS用整个相关进程组采样口径，报告共享页重计/短峰遗漏；阈值不是OS硬限。取消后清理子进程并持久化账本。

所有结果保留success、official_invalid、official_error、external_timeout、service_error、cancelled、not_evaluated、not_observed、proxy_abstain；禁止用0/无穷代替未知分数。ABSTAIN不是丢弃候选；unsupported不是官方invalid。最终可提交incumbent与探索frontier分离，只提升经本题相应E0确认的候选。

Makespan cycles与solver外层wall分别报告；在线读取/import/预处理/构造/检测/评分/回退/确认/IO/收尾均计入。独立事后裁判可另列，不能省掉在线E0。研究诊断成本单列，不与生产热路径混算。5–10分钟不是硬淘汰、最低运行时间或本队速度终点；限制评价次数也不自动把暴力变成结构化方法。

Q1/Q2正式曲线使用固定singlecore_evaluate基准，1核点按题面为1；算法优化的一核结果另表。Q3另列同核no-L2/cache比值和字节命中率；同plan机制对照与各自优化后的solver对照分开。配置变化只在独立诊断副本，不混进官方成绩。mean-of-ratios不是ratio-of-sums。

证据标明producer、完整性、本session核验方式、FORMAL/EMP/HYP、适用域。CRC/SHA不代表实验重跑；同一来源被多Pro引用不算独立重复。未读或未验标unknown。禁止事后修改guard、候选池、阈值来救结果；预注册假说被否定也是合格交付。

每卡交付目录必须有README、protocol、source/input manifest、事件/调用账本、输出计划与完整必需结果、失败/未评价记录、ACCEPTANCE.json以及逐项hash清单。原产物只读，新运行新目录，不覆盖。任何精确性差异立即隔离该域/快路径，按剩余额度提供最小反例或静态缩减说明；不自动新开Pro、Goal或追加实验。

依赖产物用其提交+manifest哈希绑定；依赖未冻结时可做只读/静态设计，不能猜文件内容或开始下游评价。完成后只交接，不自行触发Research DAG下一个节点。

### 冻结引用表

- ARCHIVE: `eaa15af9dde7365722e3b497df2fb869ff6e1c1e`
- Q1: `4dff90ef699fd51845cf482951e8477066f5f566`
- Q2_STRUCTURE: `74c46372faf5910b9b3cce6ad9a61a7e040b17aa`
- Q2_BUDGET: `0b58c123cccf02fc993b741d79dcd8511e4dd38f`
- Q3: `a4e7ee13310d693ec4fb5cc236669ceb3b172d1f`
- P1_EXACT: `5bfe53a29c1ba05167239f51ea937e602f7f85b4`
- P1_NATIVE: `03f02e79de4b4bd6f55241385664b154f4332454`
- P23_NATIVE: `603b0741e21c449d3db652ebd67c94f2dc014cc9`
- ERRATA: `e1575a1de5e3b921aef350e920720f0584fb1719`
- OFFICIAL_CODE_SHA256: `de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`

## 本卡专属契约

### 核心命题

080同plan Q2/Q3排序翻转具有可定位的请求/准入/FIFO/两池条件；命中率或Q2排序本身不能替代Q3评价。

### 固定代码与输入

Q3 pilot的080 component/affine两plan、配对完整结果；044命中率下降对照；A包008全miss完整结果；冻结Q3官方copy_tensor_info/insert_cache/retire/issue与P23能力只读。080结果取得前只算AUTHOR-REPORT。

### 允许修改范围

research/a/coherent_d/D5_cache_phase/、tests/coherent_d/D5/、results/a/coherent_d/D5/。仅合法priority/grain宏候选、观察后解释及廉价前置detector原型。

### 禁止改动

不换FIFO为LRU，不加预取/等待/重算；不合并同时miss；不把hit完成前被逐出后的再插入删掉；不跨评价继承Cache；不从scheduled_copy扣hit_bytes冒充官方字段。

### 实验协议

阶段0完整回读080两plan的q2/q3，原字节一致是对照前提。用008零hit作为排除性控制，用044hit降低但更快作为反单指标控制；缺完整记录先D0恢复，不能只看最后数值做因果结论。
最多16新评价：四个预冻结比较单元，每单元两plan×Q2/Q3=4次。单元1为080原对照（若有同runtime完整可用原件则不重跑）；单元2为合法单插入邻居相对父；单元3为新匹配图；单元4可为一个L2容量/相位诊断副本，改变轴明确。未使用配额不追加第二个临界参数搜索。
追踪发射查Cache、完成插入、有序FIFO、在飞hit被逐出、DDR与CACHE_READ各自活跃集合、关键COPY及原op时刻。运行后ρ用于解释；前置detector仅使用执行前可获得特征，不得读取候选缓存轨迹后宣称预测。
在新单元评价前固定收益方向或ABSTAIN；报告失败/反转/未预测。配置副本的结果与正式固定配置分表；若多个早期guard同时变化，写复合干预，不归因于一个hit。

### 输出产物

同plan跨q见证及原hash；Cache/两池事件diff；前置预测与实际结果表；graph support特征；Q3专用macro候选或只宜离线解释的结论。

### 验收指标

原反转身份一致且被完整产物或复评确认；至少一项新单元的前置可证伪预测完成检验。不能只用事后命中率解释，不把008高峰归功于L2。输出CacheGain_sameplan和独立solver对照标签，不混B-normalized倍率。

### 失败与停止条件

未读原计划不得继续归因；只有事后指标有效则不给detector线上地位；同guard反例要保留/收窄；16次/20分钟/RSS4GiB停止，不开展全Cache参数相图。

### 依赖

D0完整Cache字段/见证及对齐；D1合法变换；支持域不足直接E0。

### 并行与互斥

与D3/D4独立；不共享运行中Cache、不修改他人适配器；性能配对独占。

### 资源预算

建议2小时实现窗口；新评价≤16，全局96内，单CPU、4GiB，实验≤20分钟，普通调用30秒保护，无GPU。

### 成功后解锁

Q3 SharedInputPhase候选及局部专家的可用/拒答域；D6跨核相位边界。


---

/goal D6 — 映射族与1–5核：响应统计、空核嵌入和warm/cold

阶段：条件下游/P2。本卡新评价上限：0（受共同全局额度及授权约束）。

## 每张卡的共同完成契约（随卡复制，不从聊天记忆补义）

本文件是D综合设计，当前没有任何Goal或实验被启动。只有队长明确分配此卡、确认写权和预算账本后才执行；旧Pro候选额度不构成本卡授权。任务开始先按固定归档版本读取AGENTS、当前任务和授权协作通知；不覆盖他人未提交改动，不自动发消息、创建服务或认领他人写域。

研究范围是三问共同框架，按卡声明的q/k特化。正文定义使用Glossary v1；D的Definition Amendments单列为提议。本卡显式附加runtime、合法性层级、动作参数和证据要求，不得反写原Glossary或作者历史结果。

基底固定ARCHIVE提交；跨分支源码按下表固定SHA读取，不能用main猜别支内容，也不能使用后来移动的HEAD冒充as-run。Codex使用本人已授权的组织主库/本地工作树；Pro材料仅通过Vioano镜像。下载/解压官方文件可以到独立只读材料目录，逐字节核验后使用，不修改官方源码、原图或固定config；不要重序列化原图后沿用旧hash。

先冻结protocol.json、RuntimeID、source/input/plan哈希、观测Φ/ρ、动作类、样本选择规则及资源额度。运行代码身份、读取快照和归档提交分别记。未安装或未授权的依赖/硬件不得自行换用；报告阻塞，不借新账号、Colab或GPU绕过。默认CPU、单评价worker。

**共同评价预算候选：首批全局最多96次实际评价执行，不是每卡96次。** 配额：D0=36、D1=0、D2=4、D3=16、D4=16、D5=16、中央保留8。E0、E1、native分账；每次真实后端完整评分尝试均扣一次，自动fallback若再次完整评分另扣一次；一次评分内部的Step1–3局部编译不重复当成E0次数，但须计时。plain/observed、重复、失败、超时、最终确认都计数。派发前预留最坏路由额度，只有确定未调用的预留可释放。中央保留及卡间转额须队长/指定协调者显式确认；卡内余额不允许事后开新族。D6–D8、D2模型阶段及D3 lag支线当前新增评价额度为0。

最多三个活跃研发session；同一性能宿主机的配对计时独占，普通诊断最多两个评价worker且受总内存许可，不由各session各自开满。RSS用整个相关进程组采样口径，报告共享页重计/短峰遗漏；阈值不是OS硬限。取消后清理子进程并持久化账本。

所有结果保留success、official_invalid、official_error、external_timeout、service_error、cancelled、not_evaluated、not_observed、proxy_abstain；禁止用0/无穷代替未知分数。ABSTAIN不是丢弃候选；unsupported不是官方invalid。最终可提交incumbent与探索frontier分离，只提升经本题相应E0确认的候选。

Makespan cycles与solver外层wall分别报告；在线读取/import/预处理/构造/检测/评分/回退/确认/IO/收尾均计入。独立事后裁判可另列，不能省掉在线E0。研究诊断成本单列，不与生产热路径混算。5–10分钟不是硬淘汰、最低运行时间或本队速度终点；限制评价次数也不自动把暴力变成结构化方法。

Q1/Q2正式曲线使用固定singlecore_evaluate基准，1核点按题面为1；算法优化的一核结果另表。Q3另列同核no-L2/cache比值和字节命中率；同plan机制对照与各自优化后的solver对照分开。配置变化只在独立诊断副本，不混进官方成绩。mean-of-ratios不是ratio-of-sums。

证据标明producer、完整性、本session核验方式、FORMAL/EMP/HYP、适用域。CRC/SHA不代表实验重跑；同一来源被多Pro引用不算独立重复。未读或未验标unknown。禁止事后修改guard、候选池、阈值来救结果；预注册假说被否定也是合格交付。

每卡交付目录必须有README、protocol、source/input manifest、事件/调用账本、输出计划与完整必需结果、失败/未评价记录、ACCEPTANCE.json以及逐项hash清单。原产物只读，新运行新目录，不覆盖。任何精确性差异立即隔离该域/快路径，按剩余额度提供最小反例或静态缩减说明；不自动新开Pro、Goal或追加实验。

依赖产物用其提交+manifest哈希绑定；依赖未冻结时可做只读/静态设计，不能猜文件内容或开始下游评价。完成后只交接，不自行触发Research DAG下一个节点。

### 冻结引用表

- ARCHIVE: `eaa15af9dde7365722e3b497df2fb869ff6e1c1e`
- Q1: `4dff90ef699fd51845cf482951e8477066f5f566`
- Q2_STRUCTURE: `74c46372faf5910b9b3cce6ad9a61a7e040b17aa`
- Q2_BUDGET: `0b58c123cccf02fc993b741d79dcd8511e4dd38f`
- Q3: `a4e7ee13310d693ec4fb5cc236669ceb3b172d1f`
- P1_EXACT: `5bfe53a29c1ba05167239f51ea937e602f7f85b4`
- P1_NATIVE: `03f02e79de4b4bd6f55241385664b154f4332454`
- P23_NATIVE: `603b0741e21c449d3db652ebd67c94f2dc014cc9`
- ERRATA: `e1575a1de5e3b921aef350e920720f0584fb1719`
- OFFICIAL_CODE_SHA256: `de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`

## 本卡专属契约

### 核心命题

已固定宏的条件响应能否跨图/q/k保持；空核保值与实际使用新核获益分开；不要求所有宏对所有场景有效。

### 固定代码与输入

D0–D5发布的不可变manifest；固定singlecore入口；Q1/Q2/Q3各自的已确认宏与冷构造基线。使用尚未参与guard选择的结构匹配实例。

### 允许修改范围

research/a/coherent_d/D6_family/、tests/coherent_d/D6/、results/a/coherent_d/D6/。

### 禁止改动

不改已冻结宏后冒称前瞻；不把从每个k独立重构叫continuation；不把warm父解成本隐藏；不把空核full元数据变化当数值错误；不从加速曲线单独推导瓶颈因果。

### 实验协议

当前仅汇总已有数据、冻结下一面板，不执行新评价。下一实验需单独批准：每q保留一条1→5核谱系，包含旧方案末尾空核、一次固定warm宏和独立cold种子；同plan跨q与各q独立质量分表。按图/父计划冻结平衡动作类与编辑尺度、sign及响应阈值；原图不可达的资源影响保留。只有所有q/k标注齐全才称面板覆盖。最终100图矩阵另属D8，不从小面板推总体均值。

### 输出产物

FAMILY_PROTOCOL、coverage/unknown矩阵、父子谱系、冷/暖成本拆解、敏感能量及反向响应、后续明确评价上限申请。

### 验收指标

本阶段零新调用且既有身份无混用；下一阶段的Go需真实同预算质量/时间改善，或明确收窄宏适用域；少量动作比例解释80%等仅预注册探索标准，不当定理。

### 失败与停止条件

小域结构不足不强行拟合相图；warm持续输cold保留双种子；空核活动投影有差异先隔离支持域，不宣称最优值单调已破。

### 依赖

D0/D1；按场景消费D3/D4/D5的宏，不等待三个都成功。

### 并行与互斥

独立q轨迹可分片；单轨迹前后依赖不可并行；时延对照独占。

### 资源预算

当前新增评价0；只读准备建议60分钟CPU、4GiB。后续额度需新的明确批准，禁止挪用首批保留8。

### 成功后解锁

多核路由和条件迁移证据；D2局部专家校准候选数据；D8最终评估设计。


---

/goal D7 — 受限行为商与未来充分状态：只做能回本的分支

阶段：可选，不阻塞主线。本卡新评价上限：0（受共同全局额度及授权约束）。

## 每张卡的共同完成契约（随卡复制，不从聊天记忆补义）

本文件是D综合设计，当前没有任何Goal或实验被启动。只有队长明确分配此卡、确认写权和预算账本后才执行；旧Pro候选额度不构成本卡授权。任务开始先按固定归档版本读取AGENTS、当前任务和授权协作通知；不覆盖他人未提交改动，不自动发消息、创建服务或认领他人写域。

研究范围是三问共同框架，按卡声明的q/k特化。正文定义使用Glossary v1；D的Definition Amendments单列为提议。本卡显式附加runtime、合法性层级、动作参数和证据要求，不得反写原Glossary或作者历史结果。

基底固定ARCHIVE提交；跨分支源码按下表固定SHA读取，不能用main猜别支内容，也不能使用后来移动的HEAD冒充as-run。Codex使用本人已授权的组织主库/本地工作树；Pro材料仅通过Vioano镜像。下载/解压官方文件可以到独立只读材料目录，逐字节核验后使用，不修改官方源码、原图或固定config；不要重序列化原图后沿用旧hash。

先冻结protocol.json、RuntimeID、source/input/plan哈希、观测Φ/ρ、动作类、样本选择规则及资源额度。运行代码身份、读取快照和归档提交分别记。未安装或未授权的依赖/硬件不得自行换用；报告阻塞，不借新账号、Colab或GPU绕过。默认CPU、单评价worker。

**共同评价预算候选：首批全局最多96次实际评价执行，不是每卡96次。** 配额：D0=36、D1=0、D2=4、D3=16、D4=16、D5=16、中央保留8。E0、E1、native分账；每次真实后端完整评分尝试均扣一次，自动fallback若再次完整评分另扣一次；一次评分内部的Step1–3局部编译不重复当成E0次数，但须计时。plain/observed、重复、失败、超时、最终确认都计数。派发前预留最坏路由额度，只有确定未调用的预留可释放。中央保留及卡间转额须队长/指定协调者显式确认；卡内余额不允许事后开新族。D6–D8、D2模型阶段及D3 lag支线当前新增评价额度为0。

最多三个活跃研发session；同一性能宿主机的配对计时独占，普通诊断最多两个评价worker且受总内存许可，不由各session各自开满。RSS用整个相关进程组采样口径，报告共享页重计/短峰遗漏；阈值不是OS硬限。取消后清理子进程并持久化账本。

所有结果保留success、official_invalid、official_error、external_timeout、service_error、cancelled、not_evaluated、not_observed、proxy_abstain；禁止用0/无穷代替未知分数。ABSTAIN不是丢弃候选；unsupported不是官方invalid。最终可提交incumbent与探索frontier分离，只提升经本题相应E0确认的候选。

Makespan cycles与solver外层wall分别报告；在线读取/import/预处理/构造/检测/评分/回退/确认/IO/收尾均计入。独立事后裁判可另列，不能省掉在线E0。研究诊断成本单列，不与生产热路径混算。5–10分钟不是硬淘汰、最低运行时间或本队速度终点；限制评价次数也不自动把暴力变成结构化方法。

Q1/Q2正式曲线使用固定singlecore_evaluate基准，1核点按题面为1；算法优化的一核结果另表。Q3另列同核no-L2/cache比值和字节命中率；同plan机制对照与各自优化后的solver对照分开。配置变化只在独立诊断副本，不混进官方成绩。mean-of-ratios不是ratio-of-sums。

证据标明producer、完整性、本session核验方式、FORMAL/EMP/HYP、适用域。CRC/SHA不代表实验重跑；同一来源被多Pro引用不算独立重复。未读或未验标unknown。禁止事后修改guard、候选池、阈值来救结果；预注册假说被否定也是合格交付。

每卡交付目录必须有README、protocol、source/input manifest、事件/调用账本、输出计划与完整必需结果、失败/未评价记录、ACCEPTANCE.json以及逐项hash清单。原产物只读，新运行新目录，不覆盖。任何精确性差异立即隔离该域/快路径，按剩余额度提供最小反例或静态缩减说明；不自动新开Pro、Goal或追加实验。

依赖产物用其提交+manifest哈希绑定；依赖未冻结时可做只读/静态设计，不能猜文件内容或开始下游评价。完成后只交接，不自行触发Research DAG下一个节点。

### 冻结引用表

- ARCHIVE: `eaa15af9dde7365722e3b497df2fb869ff6e1c1e`
- Q1: `4dff90ef699fd51845cf482951e8477066f5f566`
- Q2_STRUCTURE: `74c46372faf5910b9b3cce6ad9a61a7e040b17aa`
- Q2_BUDGET: `0b58c123cccf02fc993b741d79dcd8511e4dd38f`
- Q3: `a4e7ee13310d693ec4fb5cc236669ceb3b172d1f`
- P1_EXACT: `5bfe53a29c1ba05167239f51ea937e602f7f85b4`
- P1_NATIVE: `03f02e79de4b4bd6f55241385664b154f4332454`
- P23_NATIVE: `603b0741e21c449d3db652ebd67c94f2dc014cc9`
- ERRATA: `e1575a1de5e3b921aef350e920720f0584fb1719`
- OFFICIAL_CODE_SHA256: `de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`

## 本卡专属契约

### 核心命题

在指定Φ/动作alphabet/封闭域中，是否存在非平凡、能省总成本的D15/D17表示；完整result大商不再研究。

### 固定代码与输入

A包24态完整结果、保存transition/labels和源码；C的C04/双账本；D1动作规格。未来字段消融使用D0已观测状态，不能用不可达想象状态冒充plan反例。

### 允许修改范围

research/a/coherent_d/D7_restricted_state/、tests/coherent_d/D7/、results/a/coherent_d/D7/。

### 禁止改动

不将未知continuation当非法，不只比较双方可执行交集；不改变动作含义救等价；不凭hash同或h步相同永久删frontier；不宣称checkpoint就是D17。

### 实验协议

当前零新增评价：复核既存24态的动作closure、0/1/2步细化及完整结果恢复；对一个明确简化Φ/A拟定闭合义务。新状态充分性须分别证明enabled、transition、observation；字段删除反例要证明在目标plan域可达。新官方测试和更大状态枚举需另批，不以“理论探索”无限穷举。

### 输出产物

等价关系/观察/动作manifest；最短区分词；sample是否闭合；score复用与frontier能力表；成本/压缩比及No-Go/条件Go。

### 验收指标

证明或封闭有限域可以产生D15；非封闭只给h-view。即使找到大类也要解释能节约哪项有用搜索工作；常量makespan域不当优化突破。

### 失败与停止条件

κ接近1或建签名/闭合成本超过所省评价即停止该Φ/A；不能由单小域失败宣称所有商无用；不挡D3–D5。

### 依赖

D1动作明确；深层状态依赖D0/编译表；无求解器质量依赖。

### 并行与互斥

低资源静态副线；主评价预算不向本卡转移。

### 资源预算

当前新评价0；建议90分钟静态/既存数据窗口，2GiB，无新模型训练。

### 成功后解锁

严格受限去重或字段必要性结论；失败则保留PlanIR/编译缓存，不维护强行为商路线。


---

/goal D8 — 竞争版蒸馏与最终质量—时间矩阵

阶段：下游整合；本轮只设计。本卡新评价上限：0（受共同全局额度及授权约束）。

## 每张卡的共同完成契约（随卡复制，不从聊天记忆补义）

本文件是D综合设计，当前没有任何Goal或实验被启动。只有队长明确分配此卡、确认写权和预算账本后才执行；旧Pro候选额度不构成本卡授权。任务开始先按固定归档版本读取AGENTS、当前任务和授权协作通知；不覆盖他人未提交改动，不自动发消息、创建服务或认领他人写域。

研究范围是三问共同框架，按卡声明的q/k特化。正文定义使用Glossary v1；D的Definition Amendments单列为提议。本卡显式附加runtime、合法性层级、动作参数和证据要求，不得反写原Glossary或作者历史结果。

基底固定ARCHIVE提交；跨分支源码按下表固定SHA读取，不能用main猜别支内容，也不能使用后来移动的HEAD冒充as-run。Codex使用本人已授权的组织主库/本地工作树；Pro材料仅通过Vioano镜像。下载/解压官方文件可以到独立只读材料目录，逐字节核验后使用，不修改官方源码、原图或固定config；不要重序列化原图后沿用旧hash。

先冻结protocol.json、RuntimeID、source/input/plan哈希、观测Φ/ρ、动作类、样本选择规则及资源额度。运行代码身份、读取快照和归档提交分别记。未安装或未授权的依赖/硬件不得自行换用；报告阻塞，不借新账号、Colab或GPU绕过。默认CPU、单评价worker。

**共同评价预算候选：首批全局最多96次实际评价执行，不是每卡96次。** 配额：D0=36、D1=0、D2=4、D3=16、D4=16、D5=16、中央保留8。E0、E1、native分账；每次真实后端完整评分尝试均扣一次，自动fallback若再次完整评分另扣一次；一次评分内部的Step1–3局部编译不重复当成E0次数，但须计时。plain/observed、重复、失败、超时、最终确认都计数。派发前预留最坏路由额度，只有确定未调用的预留可释放。中央保留及卡间转额须队长/指定协调者显式确认；卡内余额不允许事后开新族。D6–D8、D2模型阶段及D3 lag支线当前新增评价额度为0。

最多三个活跃研发session；同一性能宿主机的配对计时独占，普通诊断最多两个评价worker且受总内存许可，不由各session各自开满。RSS用整个相关进程组采样口径，报告共享页重计/短峰遗漏；阈值不是OS硬限。取消后清理子进程并持久化账本。

所有结果保留success、official_invalid、official_error、external_timeout、service_error、cancelled、not_evaluated、not_observed、proxy_abstain；禁止用0/无穷代替未知分数。ABSTAIN不是丢弃候选；unsupported不是官方invalid。最终可提交incumbent与探索frontier分离，只提升经本题相应E0确认的候选。

Makespan cycles与solver外层wall分别报告；在线读取/import/预处理/构造/检测/评分/回退/确认/IO/收尾均计入。独立事后裁判可另列，不能省掉在线E0。研究诊断成本单列，不与生产热路径混算。5–10分钟不是硬淘汰、最低运行时间或本队速度终点；限制评价次数也不自动把暴力变成结构化方法。

Q1/Q2正式曲线使用固定singlecore_evaluate基准，1核点按题面为1；算法优化的一核结果另表。Q3另列同核no-L2/cache比值和字节命中率；同plan机制对照与各自优化后的solver对照分开。配置变化只在独立诊断副本，不混进官方成绩。mean-of-ratios不是ratio-of-sums。

证据标明producer、完整性、本session核验方式、FORMAL/EMP/HYP、适用域。CRC/SHA不代表实验重跑；同一来源被多Pro引用不算独立重复。未读或未验标unknown。禁止事后修改guard、候选池、阈值来救结果；预注册假说被否定也是合格交付。

每卡交付目录必须有README、protocol、source/input manifest、事件/调用账本、输出计划与完整必需结果、失败/未评价记录、ACCEPTANCE.json以及逐项hash清单。原产物只读，新运行新目录，不覆盖。任何精确性差异立即隔离该域/快路径，按剩余额度提供最小反例或静态缩减说明；不自动新开Pro、Goal或追加实验。

依赖产物用其提交+manifest哈希绑定；依赖未冻结时可做只读/静态设计，不能猜文件内容或开始下游评价。完成后只交接，不自行触发Research DAG下一个节点。

### 冻结引用表

- ARCHIVE: `eaa15af9dde7365722e3b497df2fb869ff6e1c1e`
- Q1: `4dff90ef699fd51845cf482951e8477066f5f566`
- Q2_STRUCTURE: `74c46372faf5910b9b3cce6ad9a61a7e040b17aa`
- Q2_BUDGET: `0b58c123cccf02fc993b741d79dcd8511e4dd38f`
- Q3: `a4e7ee13310d693ec4fb5cc236669ceb3b172d1f`
- P1_EXACT: `5bfe53a29c1ba05167239f51ea937e602f7f85b4`
- P1_NATIVE: `03f02e79de4b4bd6f55241385664b154f4332454`
- P23_NATIVE: `603b0741e21c449d3db652ebd67c94f2dc014cc9`
- ERRATA: `e1575a1de5e3b921aef350e920720f0584fb1719`
- OFFICIAL_CODE_SHA256: `de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0`

## 本卡专属契约

### 核心命题

去掉通用解释/观测开销并专门化已验证宏后，能保持提交语义并改善完整质量—时间，而非只优化评分内核。

### 固定代码与输入

已冻结D1、D2路由和被保留的D3/D4/D5宏；D6明确适用域；原题100图及配置、官方baseline来源。全部依赖提交通过manifest解析，未发布则阻塞执行。

### 允许修改范围

后续授权的新research/a/coherent_d/D8_distill/或专用生产PR；当前仅协议、接口及接受标准草案，不覆盖旧默认solver。

### 禁止改动

不删除保底/错误分类/精确确认，不把代理当下界，不增加预算救质量，不用同训练图变种当跨图验收；不把新版结果覆盖历史研究身份。

### 实验协议

当前零新运行。后续先固定同一候选流，比较逻辑结果/路由/失败、测架构开销；再独立同总预算solver对照。最终Q1/Q2覆盖100图×2–5核并固定baseline一核点；Q3覆盖100图×1–5核no-L2/cache；补报算法一核研究结果但不改官方曲线。明确在这些正式图上已开发过的偏差；不得称全部为独立封存泛化。

### 输出产物

自包含求解器候选、源码/环境lock、协议、按例quality/wall/movement/cache表、完整matrix coverage、cold/warm/RSS/失败、解释信息损失及回滚计划。

### 验收指标

固定候选流无未解释语义差异；同预算质量不被已确认保底击败；采用改动须公开质量—时间Pareto。可另预注册非劣性容忍和加速门槛，但不沿用任意0.5%/2%/1.5x当官方标准；样本量/重复时延和最坏退化不能省。

### 失败与停止条件

固定流语义差异禁用快路径；没有净收益不合入；尚未有统一solver/完整输入/预算时只交设计不启动大矩阵。

### 依赖

D0/D1、D2安全能力及被保留宏；D6的适用域；不要求D7或局部专家成功。

### 并行与互斥

接口冻结后按q单写实现可分工；共用router/schema/发布由整合者单写；性能宿主机独占。

### 资源预算

本轮新增评价/训练/云支出0；后续总matrix预算、宿主机、单例期限和失败保底由队长单独批准。

### 成功后解锁

可归档、可复现的正式三问求解方案与真实最终指标；不是仅有研究图和漂亮局部峰值。

