from pathlib import Path
import json, datetime
root=Path(__file__).parent
heads={
'main':'f27ef37bb76dcf556f35d3f2328e405d92241d9c',
'codex/q1-bounded-search-20260924':'4dff90ef699fd51845cf482951e8477066f5f566',
'codex/q2-structure-nikolastarx':'74c46372faf5910b9b3cce6ad9a61a7e040b17aa',
'codex/q2-budget-search-yuanzhifang':'0b58c123cccf02fc993b741d79dcd8511e4dd38f',
'codex/q3-core-nikolastarx':'a4e7ee13310d693ec4fb5cc236669ceb3b172d1f',
'codex/q1-exact-batch-20260924':'5bfe53a29c1ba05167239f51ea937e602f7f85b4',
'codex/evaluator-native-probe-20260924':'03f02e79de4b4bd6f55241385664b154f4332454'}
files=[]
def add(branch,path,read='full returned text',source=None):
    files.append(dict(branch=branch,commit=heads[branch],path=path,read_scope=read,source_reference=source))
add('main','README.md',source='turn21file0')
add('main','docs/a/OFFICIAL_OBJECTIVES.md','sections 1–4 and beginning of 5; requested 1–170, response truncated','turn54file0')
add('main','docs/a/source-manifest.json','source lines 1–28; manifest header only, not a fresh whole-tree hash verification','turn61file0')
add('main','data/raw/a/official/code/singlecore_evaluate.py','full source returned (requested 1–180)','turn60file0')
add('main','data/raw/a/official/code/multicore_cut_evaluate_problem_2.py','source lines 20–220','turn62file0')
add('main','AI chats/README.md',source='turn65file0')
add('main','AI chats/20260924-Pro3-数学结构算法构造/README.md',source='turn66file0')
q1='codex/q1-bounded-search-20260924'
for p,s in [('src/q1/neighborhood.py','turn28file0'),('src/q1/search.py','turn29file0'),('src/q1/release_ideals.py','turn30file0'),('src/q1/structure.py','turn64file0'),('results/a/q1-profile-refine-20260924/summary.json','turn49file0')]:add(q1,p,source=s)
add(q1,'results/a/q1-profile-refine-20260924/case044/summary.json','prefix covering seed and split/merge candidate records; whole-file response truncated','turn50file0')
add(q1,'results/a/q1-profile-refine-20260924/case051/summary.json','source lines 1–170','turn51file0')
q2s='codex/q2-structure-nikolastarx'
for p,s in [('src/q2_nikolastarx/joint.py','turn40file0'),('src/q2_nikolastarx/pilot.py','turn41file0'),('results/a/q2-nikolastarx/joint-20260924/REPORT.md','turn57file0')]:add(q2s,p,source=s)
q2b='codex/q2-budget-search-yuanzhifang'
for p,s in [('src/q2/proposals.py','turn48file0'),('results/a/q2-yuanzhifang/stage-b-20260924-042906/REPORT.md','turn55file0')]:add(q2b,p,source=s)
q3='codex/q3-core-nikolastarx'
for p,s in [('src/q3/construct.py','turn42file0'),('docs/a/q3/METHOD.md','turn43file0'),('results/a/q3-nikolastarx/pilot-20260924/REPORT.md','turn45file0')]:add(q3,p,source=s)
add(q3,'src/q3/report.py','source lines 1–190 requested; response truncated near end','turn44file0')
e='codex/q1-exact-batch-20260924'
for p,s in [('src/eval_exact/problem1.py','turn58file0'),('src/eval_exact/batch.py','turn59file0')]:add(e,p,source=s)
n='codex/evaluator-native-probe-20260924'
for p,s in [('research/a/native-replay-20260924/HANDOFF.md','turn53file0'),('research/a/native-replay-20260924/README.md','turn63file0')]:add(n,p,source=s)
manifest={
'repository':'Vioano/huaweicup2026',
'heads':heads,
'head_policy':'Resolved using authorized GitHub connector at beginning; all subsequent source reads pinned to these commits. No branch writes.',
'glossary':'User-supplied Coherent Research Glossary v1, D00–D39; proposed amendments are not adopted',
'official_code_hash_reported_in_manifest':'de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0',
'whole_official_tree_rehashed_this_session':False,
'files_read':files,
'access_failures':[{'path':'src/q2','ref':heads[q2s], 'result':'authorized connector returned 404; resolved by tree read to actual src/q2_nikolastarx, not evidence that repository is unavailable'}],
'results_evidence_policy':'Repository reports were read alongside key constructor source. No new official evaluation and no fresh all-field/archived-byte independent validation; report numerical claims are AUTHOR-REPORT here.',
'new_checks':'algebra_structural_checks.py: pure abstract structural tests, zero E0/E1/E2/native solver calls',
'not_done':['No full optimization','No repository changes or pushed branches','No deployed services or Goals started','No all-100-case benchmark','No new GPU/hardware tests','No general P_exec connectivity claim','No D15 certification for W']}
(root/'READ_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(root/'HEADS.json').write_text(json.dumps(heads,ensure_ascii=False,indent=2)+'\n')
print(len(files),'files recorded')
