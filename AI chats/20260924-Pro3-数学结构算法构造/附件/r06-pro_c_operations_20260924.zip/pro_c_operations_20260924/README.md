# CRG v1 / Pro C 交付

- RESEARCH_REPORT.md：严格对应原请求13节，并列出尚未采用的Definition Amendments。
- CODEX_GOALS.md：8个候选/goal，每项含命题、冻结输入、范围、协议、验收、停止、依赖、并行和资源。没有启动任何Goal。
- HEADS.json / READ_MANIFEST.json：授权GitHub实际读取快照与范围；未把阅读报告冒充重放实验。
- algebra_structural_checks.py / .json：纯组合小验证，150个环境、9676个结构合法状态，零官方评价。

本次没有新E0/E1/E2/native运行、没有全量优化、没有修改仓库或开启服务。所有仓库数值保留AUTHOR-REPORT等级；新FORMAL结论明确限定结构合法域，未证明全P_exec连通或W为D15强行为商。

复跑纯结构检查：

```sh
python algebra_structural_checks.py
```

这会重写本目录同名结果JSON；需要保持交付字节时应先复制到新目录运行。
