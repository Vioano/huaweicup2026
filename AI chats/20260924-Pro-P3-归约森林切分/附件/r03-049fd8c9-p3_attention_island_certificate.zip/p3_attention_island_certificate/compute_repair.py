"""Compute-only, proof-carrying capsule repair. No official evaluator imports.

Scope: positive-duration M/V ops, individual external input-port releases,
fixed delay on inter-core dependencies, one slot per (core, pipe).
This is not a raw-JSON motif recognizer, COPY model, or memory certificate.
The optional pressure_guard is an integration hook, not an implemented E0 check.

Calendar: persistent AVL free intervals. The interface follows the fixed-source
q3/gap_calendar.py (Fang a37eb931, reused by q3); this implementation adds deletion
and interval release, maintaining nonempty coalesced free intervals.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from math import inf
import heapq
from typing import Callable

@dataclass(frozen=True)
class Port:
    """An external producer not included in this abstract graph. None = no locality."""
    key: str
    ready: int
    owner: int | None = None
    size: int = 0
    pos: str = 'UB'

@dataclass(frozen=True)
class Op:
    key: str
    pipe: str
    duration: int
    pred: tuple[str, ...] = ()
    ports: tuple[Port, ...] = ()

@dataclass
class Witness:
    owner: dict[str, int]
    start: dict[str, int]
    end: dict[str, int]
    @property
    def span(self):
        return max(self.end.values(), default=0)

@dataclass(frozen=True)
class Node:
    lo: int
    hi: float | int
    left: Node | None = None
    right: Node | None = None
    height: int = 1
    maximum: float | int = 0

def ht(x): return x.height if x else 0

def make(lo, hi, left=None, right=None):
    return Node(lo, hi, left, right, 1 + max(ht(left), ht(right)),
                max(hi-lo, left.maximum if left else 0, right.maximum if right else 0))

def rot_l(x):
    y=x.right
    return make(y.lo,y.hi,make(x.lo,x.hi,x.left,y.left),y.right)

def rot_r(x):
    y=x.left
    return make(y.lo,y.hi,y.left,make(x.lo,x.hi,y.right,x.right))

def bal(x):
    if ht(x.left)-ht(x.right)>1:
        if ht(x.left.left)<ht(x.left.right):
            x=make(x.lo,x.hi,rot_l(x.left),x.right)
        return rot_r(x)
    if ht(x.right)-ht(x.left)>1:
        if ht(x.right.right)<ht(x.right.left):
            x=make(x.lo,x.hi,x.left,rot_r(x.right))
        return rot_l(x)
    return x

def put(x,lo,hi):
    if hi<=lo: raise ValueError('empty interval')
    if x is None: return make(lo,hi)
    if lo==x.lo: return make(lo,hi,x.left,x.right)
    if lo<x.lo: return bal(make(x.lo,x.hi,put(x.left,lo,hi),x.right))
    return bal(make(x.lo,x.hi,x.left,put(x.right,lo,hi)))

def delete(x,lo):
    if x is None: raise ValueError('missing interval')
    if lo<x.lo: return bal(make(x.lo,x.hi,delete(x.left,lo),x.right))
    if lo>x.lo: return bal(make(x.lo,x.hi,x.left,delete(x.right,lo)))
    if x.left is None: return x.right
    if x.right is None: return x.left
    y=x.right
    while y.left: y=y.left
    return bal(make(y.lo,y.hi,x.left,delete(x.right,y.lo)))

def floor(x,t):
    ans=None
    while x:
        if x.lo<=t: ans,x=x,x.right
        else: x=x.left
    return ans

def ceil_node(x,t):
    ans=None
    while x:
        if x.lo>=t: ans,x=x,x.left
        else: x=x.right
    return ans

def fit(x,t,d):
    if x is None or x.maximum<d: return None
    if x.lo<t: return fit(x.right,t,d)
    z=fit(x.left,t,d)
    if z: return z
    return x if x.hi-x.lo>=d else fit(x.right,t,d)

def earliest(x,t,d):
    if type(t) is not int or t<0 or type(d) is not int or d<=0:
        raise ValueError('invalid integer time/duration')
    y=floor(x,t)
    if y and y.hi>=t+d: return t
    y=fit(x,t,d)
    if y is None: raise ValueError('missing unbounded final interval')
    return y.lo

def reserve(x,t,d):
    y=floor(x,t)
    if y is None or y.hi<t+d: raise ValueError('reservation collision')
    x=delete(x,y.lo)
    if y.lo<t: x=put(x,y.lo,t)
    if t+d<y.hi: x=put(x,t+d,y.hi)
    return x

def release(x,t,d):
    """Free precisely a currently occupied interval, in O(log n)."""
    e=t+d; left=floor(x,t); right=ceil_node(x,t)
    if (left and left.hi>t) or (right and right.lo<e):
        raise ValueError('release overlaps already-free space')
    lo,hi=t,e
    if left and left.hi==t:
        lo=left.lo; x=delete(x,left.lo)
    right=ceil_node(x,e)
    if right and right.lo==e:
        hi=right.hi; x=delete(x,right.lo)
    return put(x,lo,hi)

def validate_graph(ops):
    for u,o in ops.items():
        if u!=o.key or o.pipe not in ('M','V') or type(o.duration) is not int or o.duration<=0:
            raise ValueError('unsupported op')
        if len(set(o.pred))!=len(o.pred) or not set(o.pred)<=set(ops):
            raise ValueError('bad predecessors')
        if any(p.ready<0 for p in o.ports): raise ValueError('negative port release')

def port_release(o,core,delta):
    return max((p.ready + (delta if p.owner is not None and p.owner!=core else 0)
                for p in o.ports),default=0)

def check(ops,w,delta):
    validate_graph(ops)
    if set(w.owner)!=set(ops) or set(w.start)!=set(ops) or set(w.end)!=set(ops):
        raise ValueError('incomplete witness')
    by_resource={}
    for u,o in ops.items():
        if w.start[u]<0 or w.end[u]!=w.start[u]+o.duration: raise ValueError('bad time')
        if w.start[u]<port_release(o,w.owner[u],delta): raise ValueError('external port not ready')
        for p in o.pred:
            if w.start[u]<w.end[p]+delta*(w.owner[p]!=w.owner[u]):
                raise ValueError('dependency violation')
        by_resource.setdefault((w.owner[u],o.pipe),[]).append((w.start[u],w.end[u],u))
    for word in by_resource.values():
        word.sort()
        if any(x[1]>y[0] for x,y in zip(word,word[1:])): raise ValueError('pipe overlap')
    return True

def compile_words(w,cores):
    """Only words and ownership are submitted; timestamps are discarded safely."""
    words=[[] for _ in range(cores)]
    for u in sorted(w.owner,key=lambda u:(w.start[u],u)):
        words[w.owner[u]].append(u)
    return words

def longest_path(ops,owner,words,delta):
    validate_graph(ops)
    if sorted(u for a in words for u in a)!=sorted(ops): raise ValueError('word cover')
    pred={u:{p:delta*(owner[p]!=owner[u]) for p in o.pred} for u,o in ops.items()}
    for c,word in enumerate(words):
        last={}
        for u in word:
            if owner[u]!=c: raise ValueError('word owner mismatch')
            pipe=ops[u].pipe
            if pipe in last: pred[u][last[pipe]]=max(pred[u].get(last[pipe],0),0)
            last[pipe]=u
    succ={u:[] for u in ops}; degree={u:len(p) for u,p in pred.items()}
    for v in ops:
        for u,d in pred[v].items(): succ[u].append((v,d))
    ready=[u for u in ops if not degree[u]];heapq.heapify(ready)
    s={u:port_release(o,owner[u],delta) for u,o in ops.items()};end={}
    while ready:
        u=heapq.heappop(ready);end[u]=s[u]+ops[u].duration
        for v,d in succ[u]:
            s[v]=max(s[v],end[u]+d);degree[v]-=1
            if not degree[v]: heapq.heappush(ready,v)
    if len(end)!=len(ops): raise ValueError('enhanced DAG cycle')
    w=Witness(dict(owner),s,end);check(ops,w,delta);return w

def exits(ops,inside):
    """Return actual outgoing compute edges, plus dead/global-sink vertices."""
    succ={u:set() for u in ops}
    for v,o in ops.items():
        for u in o.pred:succ[u].add(v)
    return [(u,v) for u in sorted(inside) for v in sorted(succ[u]-inside)] + \
           [(u,None) for u in sorted(inside) if not succ[u]]

def arrival_vector(w,border,delta):
    return tuple(w.end[u] + (delta*(w.owner[u]!=w.owner[v]) if v is not None else 0)
                 for u,v in border)

def dominates(a,b,strict=False):
    return all(x<=y for x,y in zip(a,b)) and (not strict or any(x<y for x,y in zip(a,b)))

def repair(ops,anchor,cores,delta,capsules,pressure_guard:Callable|None=None):
    """One pass; each capsule record has nodes, islands, and a closed single sink.

    Island sets MUST come from original-node cones/suffixes, not rewritten ops.
    Whole-home re-insertion is the control; a split must componentwise improve
    its actual outgoing arrival vector. All outside intervals remain fixed.
    Recognition and production memory/traffic integration are intentionally external.
    """
    check(ops,anchor,delta)
    w=Witness(dict(anchor.owner),dict(anchor.start),dict(anchor.end))
    roots={(c,p):make(0,inf) for c in range(cores) for p in ('M','V')}
    for u in sorted(ops,key=lambda u:w.start[u]):
        r=(w.owner[u],ops[u].pipe);roots[r]=reserve(roots[r],w.start[u],ops[u].duration)
    seen=set(); log=[]
    for rec in capsules:
        inside=set(rec['nodes'])
        if not inside or inside & seen: raise ValueError('empty/overlapping capsules')
        seen|=inside
        homes={w.owner[u] for u in inside}
        if len(homes)!=1: raise ValueError('anchor capsule not wholly local')
        home=next(iter(homes));border=exits(ops,inside)
        if not border or len({u for u,_ in border})!=1: raise ValueError('not single exit')
        word=sorted(inside,key=lambda u:(w.start[u],u))
        base=dict(roots)
        for u in word:
            r=(home,ops[u].pipe);base[r]=release(base[r],w.start[u],ops[u].duration)
        old_av=arrival_vector(w,border,delta)
        def trial(island,helper):
            own={u:(helper if u in island else home) for u in inside}
            rr=dict(base);local_s={};local_e={}
            for u in word:
                o=ops[u];c=own[u];t=port_release(o,c,delta)
                for p in o.pred:
                    po=own[p] if p in inside else w.owner[p]
                    pe=local_e[p] if p in inside else w.end[p]
                    t=max(t,pe+delta*(po!=c))
                r=(c,o.pipe);s=earliest(rr[r],t,o.duration)
                rr[r]=reserve(rr[r],s,o.duration);local_s[u]=s;local_e[u]=s+o.duration
            tw=Witness(w.owner|own,w.start|local_s,w.end|local_e)
            av=arrival_vector(tw,border,delta)
            if not dominates(av,old_av):return None
            if pressure_guard is not None and not pressure_guard(ops,inside,tw):return None
            return av,tw,rr
        control=trial(set(),home)
        if control is None: control=(old_av,w,roots)
        best=control;mode='whole_home'
        for i,island in enumerate(rec['islands']):
            island=set(island)
            if not island or not island<inside:raise ValueError('island is not a proper subset')
            for helper in range(cores):
                if helper==home:continue
                result=trial(island,helper)
                if result and dominates(result[0],control[0],strict=True):
                    if (max(result[0]),sum(result[0]),i,helper)<(max(best[0]),sum(best[0]),999,999):
                        best=result;mode=f'island:{i}/helper:{helper}'
        av,tw,rr=best
        # The original operational contract is verified independently here.
        check(ops,tw,delta)
        if tw.span>anchor.span:raise AssertionError('witness dominance broken')
        w,roots=tw,rr;log.append({'mode':mode,'old_arrivals':old_av,'new_arrivals':av})
    final_words=compile_words(w,cores)
    final=longest_path(ops,w.owner,final_words,delta)
    if final.span>w.span:raise AssertionError('compiled FIFO lost witness')
    return final,final_words,log
