"""Small, deterministic checks of the stated abstract claims. No E0 imports."""
from __future__ import annotations
import json
from pathlib import Path
from dataclasses import asdict
from compute_repair import *

OUT=Path(__file__).parent
DELTA=500

def dump_witness(ops,w,words):
    return {'makespan':w.span,'core_words':words,'operations':[
        {'op':u,'pipe':ops[u].pipe,'duration':ops[u].duration,'predecessors':list(ops[u].pred),
         'external_input_ports':[asdict(p) for p in ops[u].ports],
         'core':w.owner[u],'start':w.start[u],'end':w.end[u]}
        for u in sorted(ops)]}

def ffn(n=3,A=2000,e=10):
    ops={}
    for j in range(n):
        a,b,c,d=(f'{x}{j}' for x in 'abcd')
        ops[a]=Op(a,'M',A)
        ops[b]=Op(b,'V',e,(a,))
        ops[c]=Op(c,'V',e,(a,b))
        ops[d]=Op(d,'M',A,(c,))
    return ops

records=[]
ops=ffn()
owner={u:(1 if u.endswith('1') else 0) for u in ops}
words=[['a0','b0','c0','a2','b2','c2','d0','d2'],['a1','b1','c1','d1']]
w=longest_path(ops,owner,words,DELTA)
caps=[{'nodes':[f'{x}2' for x in 'abcd'],'islands':[{'d2'}]}]
new,nw,log=repair(ops,w,2,DELTA,caps)
assert w.span==8000 and new.span==6520
records.append({'name':'three_FFN_one_tail_migration','co_location_optimum_proved':8000,
                'baseline':dump_witness(ops,w,words),'candidate':dump_witness(ops,new,nw),'repair':log})

ops=ffn(n=1)
owner={u:0 for u in ops};words=[list('abcd'[i]+'0' for i in range(4)),[]]
w=longest_path(ops,owner,words,DELTA)
new,nw,log=repair(ops,w,2,DELTA,[{'nodes':set(ops),'islands':[{'d0'}]}])
assert w.span==4020 and new.span==4020 and new.owner==owner
records.append({'name':'isolated_serial_FFN_no_gain','baseline':dump_witness(ops,w,words),
                'candidate':dump_witness(ops,new,nw),'repair':log})

# Exact original-style 2-key row: 12*n-4=20 original operations.
ops={}
def add(u,p,d,pred=(),ports=()):ops[u]=Op(u,p,d,tuple(pred),tuple(ports))
for j in range(2):
    add(f'score{j}','M',1,ports=(Port('Q',0,0),Port(f'K{j}',0,0)))
    add(f'div{j}','V',1,(f'score{j}',), (Port('scale',0,None,2),))
    add(f'maxred{j}','V',1,(f'div{j}',))
add('maxsub','V',1,('maxred0','maxred1'))
add('maxrelu','V',1,('maxsub',))
add('maxadd','V',1,('maxrelu','maxred1'))
for j in range(2):
    add(f'shift{j}','V',1,(f'div{j}','maxadd'))
    add(f'exp{j}','V',1,(f'shift{j}',))
    add(f'sumred{j}','V',1,(f'exp{j}',))
    add(f'product{j}','M',4000,(f'exp{j}',),(Port(f'V{j}',0,0),))
add('denominator','V',1,('sumred0','sumred1'))
add('numerator','V',1,('product0','product1'))
add('output','V',1,('numerator','denominator'))
word=['score0','score1','div0','div1','maxred0','maxred1','maxsub','maxrelu','maxadd',
      'shift0','shift1','exp0','exp1','sumred0','sumred1','denominator','product0','product1','numerator','output']
owner={u:0 for u in ops};words=[word,[]]
w=longest_path(ops,owner,words,DELTA)
new,nw,log=repair(ops,w,2,DELTA,[{'nodes':set(ops),'islands':[{'product0'},{'product1'}]}])
assert len(ops)==20 and new.span<8000<=w.span
records.append({'name':'two_key_original_style_attention_row','scope':'synthetic 20-op row; not an official case',
                'co_location_M_work_lower_bound':8002,'baseline':dump_witness(ops,w,words),
                'candidate':dump_witness(ops,new,nw),'repair':log})

for early in (True,False):
    ops={'u':Op('u','M',1200,ports=(Port('Pu',0 if early else 5000,0),)),
         'v':Op('v','M',1200,ports=(Port('Pv',5000,0),)),
         'j':Op('j','V',1,('u','v'))}
    owner={u:0 for u in ops};words=[['u','v','j'],[]]
    w=longest_path(ops,owner,words,DELTA)
    new,nw,log=repair(ops,w,2,DELTA,[{'nodes':set(ops),'islands':[{'u'},{'v'}]}])
    assert (w.span,new.span)==((6201,6201) if early else (7401,7201))
    records.append({'name':'same_max_port_release_early' if early else 'same_max_port_release_late',
                    'baseline':dump_witness(ops,w,words),'candidate':dump_witness(ops,new,nw),'repair':log})

ops={'a':Op('a','M',1),'b':Op('b','V',1,('a',)), 'c':Op('c','V',1,('a','b')),
     'd':Op('d','M',1,('c',)),'x':Op('x','M',602),'z':Op('z','V',1,('d',))}
owner={u:0 for u in ops};words=[['a','b','c','x','d','z'],[]]
w=longest_path(ops,owner,words,DELTA)
new,nw,log=repair(ops,w,2,DELTA,[{'nodes':{'a','b','c','d'},'islands':[{'d'}]}])
assert w.end['d']==604 and w.start['z']==604 and new.owner['d']==0
records.append({'name':'faster_tail_but_later_future_join_rejected',
                'rejected_remote_tail_finish':504,'rejected_arrival_to_z':1004,
                'baseline':dump_witness(ops,w,words),'candidate':dump_witness(ops,new,nw),'repair':log})

# Direct free-interval reserve/release check against a finite occupancy oracle.
r=make(0,inf);occupied=set()
for start,dur in [(0,3),(5,2),(7,4),(12,5)]:
    r=reserve(r,start,dur);occupied.update(range(start,start+dur))
for start,dur in [(5,2),(0,3),(12,5),(7,4)]:
    r=release(r,start,dur);occupied.difference_update(range(start,start+dur))
    for t in range(18):
        for d in (1,2,5):
            oracle=next(s for s in range(t,40) if not set(range(s,s+d))&occupied)
            assert earliest(r,t,d)==oracle

out={'source_material_commit':'6732c77c1b90f75a038122ad699baed83ef497da',
     'official_evaluations':0,'raw_official_cases_read':0,'scope':'self-contained compute+delta examples only',
     'memory_or_cache_claims':False,'examples':records,
     'interval_calendar_oracle_checks':4*18*3}
(OUT/'abstract_certificates.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'name':x['name'],'before':x['baseline']['makespan'],'after':x['candidate']['makespan']} for x in records],indent=2))
