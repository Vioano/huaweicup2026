import sys,pathlib,json,cProfile,pstats,signal,time,io
sys.dont_write_bytecode=True
root=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);case=sys.argv[3];sys.path.insert(0,str(root/'code'))
from singlecore_evaluate import evaluate_singlecore
from evaluation_validation import read_evaluation_config
x=json.loads((root/'data'/f'{case}.json').read_bytes());cfg=read_evaluation_config(root/'data/config.txt')
prof=cProfile.Profile();begin=time.perf_counter()
def expired(*args):raise TimeoutError('20-second diagnostic profile only')
signal.signal(signal.SIGALRM,expired);signal.alarm(20)
try:prof.enable();result=evaluate_singlecore(x,**cfg);state='completed'
except Exception as exc:state=f'{type(exc).__name__}: {exc}'
finally:
 prof.disable();signal.alarm(0)
 s=io.StringIO();s.write(state+'\n');pstats.Stats(prof,stream=s).sort_stats('cumulative').print_stats(35);text=s.getvalue();out.write_text(text);print(text)
