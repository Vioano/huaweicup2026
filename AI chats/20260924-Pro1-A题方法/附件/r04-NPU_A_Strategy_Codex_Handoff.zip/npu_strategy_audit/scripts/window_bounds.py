"""Provable compute head/tail energy bounds on a sampled threshold grid."""
import pathlib,json,collections,math,sys,bisect
from scan_cases import views

def bound(g,n,grid=48):
    ops,ts,prod,cons,V,pred,succ,ets=views(g)
    degree={v:len(pred[v]) for v in V};q=collections.deque(v for v in sorted(V) if not degree[v]);order=[];head={v:0 for v in V}
    while q:
        v=q.popleft();order.append(v)
        for w in succ[v]:
            head[w]=max(head[w],head[v]+ops[v]['cycles']);degree[w]-=1
            if not degree[w]:q.append(w)
    tail={v:0 for v in V}
    for v in reversed(order):tail[v]=max((ops[w]['cycles']+tail[w] for w in succ[v]),default=0)
    def thresholds(values):
        vals=sorted(set(values));return sorted({0}|{vals[round(i*(len(vals)-1)/max(1,grid-1))] for i in range(grid)})
    A=thresholds(head.values());B=thresholds(tail.values());best=max((head[v]+ops[v]['cycles'] for v in V),default=0);witness={'type':'critical_path','bound':best}
    for pipe in ['PIPE_M','PIPE_V']:
        weights=[[0]*len(B) for _ in A]
        for v in V:
            if ops[v]['pipe']==pipe:weights[bisect.bisect_right(A,head[v])-1][bisect.bisect_right(B,tail[v])-1]+=ops[v]['cycles']
        for i in reversed(range(len(A))):
            for j in reversed(range(len(B))):
                if i+1<len(A):weights[i][j]+=weights[i+1][j]
                if j+1<len(B):weights[i][j]+=weights[i][j+1]
                if i+1<len(A) and j+1<len(B):weights[i][j]-=weights[i+1][j+1]
                # An empty subset imposes no interval-capacity constraint.
                if weights[i][j]:
                    value=math.ceil(A[i]+B[j]+weights[i][j]/n)
                    if value>best:best=value;witness={'type':'head_tail_energy','pipe':pipe,'head_threshold':A[i],'tail_threshold':B[j],'subset_work':weights[i][j],'cores':n,'bound':best}
    return best,witness

def main():
    data,out=map(pathlib.Path,sys.argv[1:3]);rows=[]
    for p in sorted(data.glob('case_*.json')):
        g=json.loads(p.read_bytes());b,w=bound(g,4);rows.append({'case':p.stem,'N':4,'compute_window_bound':b,'witness':w})
    out.write_text(json.dumps(rows,indent=2));print('written',len(rows))
    for r in rows:
        if r['case'] in ['case_010','case_014','case_048','case_051','case_064','case_087']:print(r)
if __name__=='__main__':main()
