#!/usr/bin/env python3
"""Synthetic conformance probes using unmodified official evaluator."""
import contextlib,io,json,pathlib,sys,traceback
ROOT=pathlib.Path(sys.argv[1]);OUT=pathlib.Path(sys.argv[2]);OUT.mkdir(parents=True,exist_ok=True)
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'code'))
from multicore_cut_evaluate_problem_1 import evaluate_scene_a
from multicore_cut_evaluate_problem_2 import evaluate_scene_b
from multicore_cut_evaluate_problem_3 import evaluate_problem_3
from stub_multicore_cut_and_schedule import derive_multicore_plan
from evaluation_validation import read_evaluation_config
from multicore_cut_evaluate_problem_1 import read_scene_a_config
from multicore_cut_evaluate_problem_2 import read_scene_b_config
from multicore_cut_evaluate_problem_3 import read_cache_config
cfg=ROOT/'data/config.txt';kw=read_evaluation_config(cfg);ak=read_scene_a_config(cfg);bk=read_scene_b_config(cfg);ck=read_cache_config(cfg)
class Graph:
 def __init__(self):self.g={'ops':[],'tensors':[],'edges':[]};self.i=0
 def nid(self):self.i+=1;return self.i
 def tensor(self,size,pos='UB'):
  i=self.nid();self.g['tensors'].append({'id':i,'size':size,'pos':pos});return i
 def op(self,inputs,size,cycles=30,name='RELU',pipe='PIPE_V',pos='UB'):
  i=self.nid();self.g['ops'].append({'id':i,'op':name,'pipe':pipe,'cycles':cycles});t=self.tensor(size,pos)
  self.g['edges'].extend([{'source':s,'target':i} for s in inputs]);self.g['edges'].append({'source':i,'target':t});return i,t
 def input(self,size):
  t=self.tensor(size,'DDR');return self.op([t],size,0,'COPY_IN','PIPE_MTE2')[1]
 def output(self,t,size):return self.op([t],size,0,'COPY_OUT','PIPE_MTE3','DDR')

def run(label,g,plan,p):
 d=OUT/f'{label}_p{p}';d.mkdir(exist_ok=True)
 (d/'graph.json').write_text(json.dumps(g,indent=2));(d/'plan.json').write_text(json.dumps(plan,indent=2))
 row={'label':label,'problem':p}
 try:
  derive_multicore_plan(g,plan);row['initial_plan_validation']='passed'
  if p==1:r=evaluate_scene_a(g,plan,**kw,cross_core_wait=ak['task_cross_core_wait_cycles'],same_core_wait=ak['task_same_core_wait_cycles'])
  elif p==2:r=evaluate_scene_b(g,plan,**kw,cross_core_copy_delay=bk['cross_core_copy_delay_cycles'])
  else:r=evaluate_problem_3(g,plan,**kw,cross_core_copy_delay=bk['cross_core_copy_delay_cycles'],**ck)
  row.update(status='ok',makespan=r['makespan'],traffic=r['data_movement_bytes'],cache=r.get('cache_stats'))
  (d/'result.json').write_text(json.dumps(r,indent=2))
 except Exception as e:
  row.update(status='error',error_type=type(e).__name__,error=str(e),cycle=getattr(e,'cycle',None))
 (d/'summary.json').write_text(json.dumps(row,indent=2));return row
rows=[]
# Per-destination COPY_OUT duplication.
g=Graph();x=g.input(600);a,y=g.op([x],600);b,z=g.op([y],60);c,w=g.op([y],60);g.output(z,60);g.output(w,60)
plan={'node_to_subgraph':{str(a):0,str(b):1,str(c):2},'core_schedules':[[0],[1],[2]]}
for p in [1,2,3]:rows.append(run('multicast',g.g,plan,p))
# Acyclic input/subgraph graph can still result in global FIFO waiting cycle.
g=Graph();x=g.input(60);a,t=g.op([x],60);b,u=g.op([t],60);y=g.input(60);c,v=g.op([y],60);d,w=g.op([v],60);g.output(u,60);g.output(w,60)
plan={'node_to_subgraph':{str(a):0,str(b):1,str(c):2,str(d):3},'core_schedules':[[3,0],[1,2]]}
for p in [1,2,3]:rows.append(run('wait_cycle',g.g,plan,p))
# Same graph/core allocation, only reorder two independent subgraphs on core 1.
g=Graph();x=g.input(6000);a,t=g.op([x],60);b,u=g.op([x],60);y=g.input(6000);c,v=g.op([y],60);g.output(t,60);g.output(u,60);g.output(v,60)
for label,order in [('cold_simultaneous',[1,2]),('cold_stagger',[2,1])]:
 plan={'node_to_subgraph':{str(a):0,str(b):1,str(c):2},'core_schedules':[[0],order]}
 for p in [2,3]:rows.append(run(label,g.g,plan,p))
(OUT/'summary.json').write_text(json.dumps(rows,indent=2))
for r in rows:print(json.dumps(r,ensure_ascii=False))
