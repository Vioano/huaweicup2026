#!/usr/bin/env python3
"""Enumerate EVERY partition/core assignment/core order for a tiny graph."""
import contextlib,io,itertools,json,pathlib,sys,time,collections
root=pathlib.Path(sys.argv[1]);graph_path=pathlib.Path(sys.argv[2]);out=pathlib.Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
sys.dont_write_bytecode=True;sys.path.insert(0,str(root/'code'))
from multicore_cut_evaluate_problem_1 import evaluate_scene_a
from multicore_cut_evaluate_problem_2 import evaluate_scene_b
from multicore_cut_evaluate_problem_3 import evaluate_problem_3
from evaluation_validation import read_evaluation_config
from multicore_cut_evaluate_problem_1 import read_scene_a_config
from multicore_cut_evaluate_problem_2 import read_scene_b_config
from multicore_cut_evaluate_problem_3 import read_cache_config
cfg=root/'data/config.txt';kw=read_evaluation_config(cfg);ak=read_scene_a_config(cfg);bk=read_scene_b_config(cfg);ck=read_cache_config(cfg)
g=json.loads(graph_path.read_text());ids=sorted(o['id'] for o in g['ops'] if o['op'] not in ('COPY_IN','COPY_OUT'))
if len(ids)>5:raise ValueError('This complete oracle is intentionally limited to <=5 compute ops.')

def partitions(n,prefix=()):
 if len(prefix)==n:yield prefix;return
 for label in range(max(prefix,default=-1)+2):yield from partitions(n,prefix+(label,))

rows=[]
for problem in [1,2,3]:
 begin=time.perf_counter();best=None;tested=valid=0;errors=collections.Counter()
 for part in partitions(len(ids)):
  k=max(part)+1
  for assignment in itertools.product(range(2),repeat=k):
   per_core=[[j for j in range(k) if assignment[j]==c] for c in range(2)]
   for orders in itertools.product(*(list(itertools.permutations(x)) for x in per_core)):
    plan={'node_to_subgraph':dict(zip(map(str,ids),part)),'core_schedules':[list(x) for x in orders]};tested+=1
    try:
     with contextlib.redirect_stderr(io.StringIO()),contextlib.redirect_stdout(io.StringIO()):
      if problem==1:r=evaluate_scene_a(g,plan,**kw,cross_core_wait=ak['task_cross_core_wait_cycles'],same_core_wait=ak['task_same_core_wait_cycles'])
      elif problem==2:r=evaluate_scene_b(g,plan,**kw,cross_core_copy_delay=bk['cross_core_copy_delay_cycles'])
      else:r=evaluate_problem_3(g,plan,**kw,cross_core_copy_delay=bk['cross_core_copy_delay_cycles'],**ck)
     valid+=1
     if best is None or r['makespan']<best[0]:best=(r['makespan'],plan,r)
    except Exception as exc:errors[type(exc).__name__]+=1
 row={'problem':problem,'compute_ops':len(ids),'cores':2,'all_encodings_enumerated':tested,'officially_valid':valid,'errors':dict(errors),'optimal_makespan_over_complete_space':best[0],'seconds':time.perf_counter()-begin}
 (out/f'p{problem}_optimal_plan.json').write_text(json.dumps(best[1],indent=2));(out/f'p{problem}_optimal_result.json').write_text(json.dumps(best[2],indent=2));rows.append(row)
(out/'summary.json').write_text(json.dumps(rows,indent=2));(out/'graph.json').write_text(json.dumps(g,indent=2));print(json.dumps(rows,indent=2))
