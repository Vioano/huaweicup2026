#!/usr/bin/env python3
"""Independent, bounded, end-to-end probes. All hardware config values from frozen config.
Not a claim of general proof or of new 100-case performance results.
"""
import json,pathlib,sys,time,hashlib
ROOT=pathlib.Path(sys.argv[1]);OUT=pathlib.Path(sys.argv[2]);OUT.mkdir(parents=True,exist_ok=True)
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'code'))
from evaluation_validation import read_evaluation_config
from multicore_cut_evaluate_problem_1 import evaluate_scene_a,read_scene_a_config
from multicore_cut_evaluate_problem_2 import evaluate_scene_b,read_scene_b_config,_build_scene_b_tasks
from multicore_cut_evaluate_problem_3 import evaluate_problem_3,read_cache_config
cfg=ROOT/'data/config.txt';C=read_evaluation_config(cfg);A=read_scene_a_config(cfg);B=read_scene_b_config(cfg);L=read_cache_config(cfg)
class Graph:
 def __init__(self):self.g={'ops':[],'tensors':[],'edges':[]};self.i=0
 def nid(self):self.i+=1;return self.i
 def tensor(self,size,pos='UB'):
  i=self.nid();self.g['tensors'].append({'id':i,'size':size,'pos':pos});return i
 def op(self,inputs,size,cycles=30,name='RELU',pipe='PIPE_V',pos='UB'):
  i=self.nid();self.g['ops'].append({'id':i,'op':name,'pipe':pipe,'cycles':cycles});t=self.tensor(size,pos)
  self.g['edges'].extend([{'source':s,'target':i} for s in inputs]);self.g['edges'].append({'source':i,'target':t});return i,t
 def input(self,size):
  t=self.tensor(size,'DDR');return self.op([t],size,0,'COPY_IN','PIPE_MTE2')[1]
 def output(self,t,size):return self.op([t],size,0,'COPY_OUT','PIPE_MTE3','DDR')
rows=[]
def run(label,g,plan,p,extra=None):
 d=OUT/f'{label}_p{p}';d.mkdir(exist_ok=True)
 for name,obj in [('graph',g),('plan',plan)]: (d/f'{name}.json').write_text(json.dumps(obj,indent=2))
 st=time.perf_counter()
 if p==1:r=evaluate_scene_a(g,plan,**C,cross_core_wait=A['task_cross_core_wait_cycles'],same_core_wait=A['task_same_core_wait_cycles'])
 elif p==2:r=evaluate_scene_b(g,plan,**C,cross_core_copy_delay=B['cross_core_copy_delay_cycles'])
 else:r=evaluate_problem_3(g,plan,**C,cross_core_copy_delay=B['cross_core_copy_delay_cycles'],**L)
 (d/'result.json').write_text(json.dumps(r,indent=2)); row={'label':label,'problem':p,'makespan':r['makespan'],'elapsed_seconds':time.perf_counter()-st,'data_movement_bytes':r['data_movement_bytes'],'cache_stats':r.get('cache_stats'),'annotations':extra}
 (d/'summary.json').write_text(json.dumps(row,indent=2));rows.append(row);return r
# Independent C's data is ready, but same-Pipe B is FIFO head and awaits a remote tensor.
g=Graph();x=g.input(60);a,ta=g.op([x],60,100); y=g.input(60);d,td=g.op([y],60,10,'MATMUL','PIPE_M');b,tb=g.op([ta],60,5);c,tc=g.op([td],60,800);g.output(tb,60);g.output(tc,60)
mp={str(a):0,str(d):1,str(b):2,str(c):3}
for label,order in [('head_blocks',[1,2,3]),('head_reordered',[1,3,2])]:
 plan={'node_to_subgraph':mp,'core_schedules':[[0],order]}
 for p in [2,3]:run(label,g.g,plan,p,{'source':a,'local_setup':d,'waiting_head':b,'independent_later_op':c})
# Appending an empty core preserves the already assigned work.
plan={'node_to_subgraph':mp,'core_schedules':[[0],[1,3,2],[]]}
run('append_empty_core',g.g,plan,2)
# Previously loaded long-lived logical tensor is evicted by Step2 and read again from L2.
g=Graph();x=g.input(49152);comp=[];u=x
for j in range(6):
 o,u=g.op([u],49152,30);comp.append(o)
g.output(u,49152)
o,v=g.op([x],49152,30);comp.append(o);g.output(v,49152)
plan={'node_to_subgraph':{str(o):i for i,o in enumerate(comp)},'core_schedules':[list(range(len(comp))),[]]}
for p in [2,3]:
 r=run('spill_logical_cache',g.g,plan,p,{'long_lived_original_local_tid':x,'input_size_bytes':49152,'note':'Fixed official capacity/bandwidth, not the teammate capacity-sweep fixture.'})
 tasks,*_= _build_scene_b_tasks(g.g,plan,**C)
 t=tasks[0]
 (OUT/f'spill_logical_cache_p{p}'/'compiled_spill_provenance.json').write_text(json.dumps({'spills':t.get('step2',t.get('spill_records','unknown')),'task_keys':list(t.keys()),'renamed_tensors':[a for a in t['tensor_by_id'].values() if 'logical_tid' in a],'spill_ops':[a for a in t['op_by_id'].values() if 'spill_logical_tid' in a]},indent=2))
# Teammate's ranking fixture, but config read from frozen official file (not copied constants).
fx=json.loads((pathlib.Path(__file__).parents[1]/'form/tests/adversarial/ranking-inversion-pair.json').read_text())
for key in ['a','b']:run('form_ranking_'+key,fx['graph'],fx['pair'][key]['plan'],1,{'teammate_claim':fx['pair'][key]['official_makespan']})
(OUT/'summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(json.dumps(rows,ensure_ascii=False,indent=2))
