import pathlib,json,hashlib,platform,sys,collections
R=pathlib.Path('/mnt/data/research_r2'); O=R/'new_evidence'; O.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/'previous/npu_strategy_audit/official_manifest.json').read_text()); mismatch=[]
for p,h in m['files'].items():
 a=R/'official'/p
 if not a.exists() or sha(a)!=h:mismatch.append(p)
z=pathlib.Path('/mnt/data/通用神经网络处理器下的多核调度问题  附件.zip')
f=json.loads((R/'form/MANIFEST.json').read_text());fm=[]
for i in f['files']:
 p=R/'form'/i['git_path']
 if not p.exists() or sha(p)!=i['sha256']:fm.append(i['git_path'])
old=R/'previous/npu_strategy_audit/evidence';new=O/'micro_replay'; comparisons=[]
for d in sorted(new.iterdir()):
 if not d.is_dir():continue
 before=old/'micro'/d.name/'summary.json';after=d/'summary.json'
 a=json.loads(before.read_text());b=json.loads(after.read_text());diff={k:[a.get(k),b.get(k)] for k in set(a)|set(b) if a.get(k)!=b.get(k)}
 rf1=before.parent/'result.json';rf2=d/'result.json';full=(json.loads(rf1.read_text())==json.loads(rf2.read_text())) if rf1.exists() and rf2.exists() else None
 comparisons.append({'probe':d.name,'summary_equal':not diff,'summary_diff':diff,'full_json_values_equal':full,'status':b['status'],'makespan':b.get('makespan')})
linecounts={p.name:len([l for l in p.read_text().splitlines() if l.strip()]) for p in old.glob('*.jsonl')}
cpu='unknown'
for l in pathlib.Path('/proc/cpuinfo').read_text().splitlines():
 if l.startswith('model name'):cpu=l.split(':',1)[1].strip();break
r={'environment':{'platform':platform.platform(),'python':sys.version,'cpu_model':cpu,'logical_cpus_visible':__import__('os').cpu_count(),'gpu_benchmark_performed':False},'official_files_checked':len(m['files']),'official_mismatches':mismatch,'original_zip_sha256':sha(z),'original_zip_matches_archived':sha(z)==m['zip_sha256'],'form_payload_files_checked':len(f['files']),'form_hash_mismatches':fm,'form_commit':f['commit'],'form_payload_extensions':dict(collections.Counter(pathlib.Path(i['git_path']).suffix for i in f['files'])),'aggregate_freeze_hash_from_user':'de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0','aggregate_hash_recipe':'not supplied in these inputs; individual file identities verified instead','archived_jsonl_linecounts_only_not_rerun':linecounts,'old_micro_replay':comparisons}
(O/'asset_and_replay_audit.json').write_text(json.dumps(r,indent=2,ensure_ascii=False));print(json.dumps(r,indent=2,ensure_ascii=False))
