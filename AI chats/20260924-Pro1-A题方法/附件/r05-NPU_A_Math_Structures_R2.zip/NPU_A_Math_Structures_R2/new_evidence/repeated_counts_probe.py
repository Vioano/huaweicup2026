#!/usr/bin/env python3
"""Small official-Q2 test of a *restricted* count symmetry, and an interface counterexample.
No statement about symmetry of arbitrary repeated subgraphs. Uses frozen config unchanged.
"""
import sys,json,pathlib,itertools,time
sys.dont_write_bytecode=True
ROOT=pathlib.Path(sys.argv[1]);OUT=pathlib.Path(sys.argv[2]);OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'code'))
from evaluation_validation import read_evaluation_config
from multicore_cut_evaluate_problem_2 import evaluate_scene_b,read_scene_b_config
C=read_evaluation_config(ROOT/'data/config.txt'); D=read_scene_b_config(ROOT/'data/config.txt')
class Graph:
 def __init__(self):self.g={'ops':[],'tensors':[],'edges':[]};self.i=0
 def tid(self,size,pos='UB'):
  self.i+=1;self.g['tensors'].append({'id':self.i,'size':size,'pos':pos});return self.i
 def op(self,ins,size,cycles=100,name='RELU',pipe='PIPE_V',pos='UB'):
  self.i+=1;o=self.i;self.g['ops'].append({'id':o,'op':name,'pipe':pipe,'cycles':cycles});t=self.tid(size,pos)
  self.g['edges'] += [{'source':v,'target':o} for v in ins]+[{'source':o,'target':t}];return o,t
 def inp(self,size):return self.op([self.tid(size,'DDR')],size,0,'COPY_IN','PIPE_MTE2')[1]
 def out(self,t,size):self.op([t],size,0,'COPY_OUT','PIPE_MTE3','DDR')
def run(g,mapping,label):
 p={'node_to_subgraph':{str(o):k for o,k in mapping.items()},'core_schedules':[[k] if k in mapping.values() else [] for k in range(2)]}
 r=evaluate_scene_b(g,p,**C,cross_core_copy_delay=D['cross_core_copy_delay_cycles'])
 (OUT/f'{label}.json').write_text(json.dumps({'graph':g,'plan':p,'official_result':r},ensure_ascii=False))
 return r['makespan']
g=Graph();ops=[]
for i in range(5):
 x=g.inp(60);o,t=g.op([x],60,100);g.out(t,60);ops.append(o)
bycount={};values=[]
for j,col in enumerate(itertools.product(range(2),repeat=5)):
 t=run(g.g,dict(zip(ops,col)),f'private_identical_{j:02d}');n0=col.count(0);bycount.setdefault(n0,set()).add(t);values.append({'assignment':col,'count_core0':n0,'makespan':t})
assert all(len(v)==1 for v in bycount.values())
# Same local operation labels, but unlike external interfaces: only A feeds a long successor.
g=Graph();a,ta=g.op([g.inp(60)],60,20);b,tb=g.op([g.inp(60)],60,20);d,td=g.op([ta],60,800);g.out(tb,60);g.out(td,60)
x=run(g.g,{a:0,b:1,d:0},'unequal_interface_A_local');y=run(g.g,{a:1,b:0,d:0},'unequal_interface_A_remote')
assert x!=y
report={'scope':'32 assignments of five independent identical private COPY_IN-RELU-COPY_OUT chains, two cores, one subgraph per nonempty core, frozen official config, Q2; not a universal symmetry theorem', 'evaluated':32,'makespans_by_count_core0':{str(k):list(v) for k,v in sorted(bycount.items())},'within_count_differences':0,'unequal_external_interface_counterexample':{'same_branch_local_labels':True,'first_assignment_makespan':x,'second_assignment_makespan':y},'evaluations':values}
(OUT/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='evaluations'},ensure_ascii=False,indent=2))
