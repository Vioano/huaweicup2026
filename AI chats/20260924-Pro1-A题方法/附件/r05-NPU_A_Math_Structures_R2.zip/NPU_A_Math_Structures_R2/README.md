# NPU A 数学结构研究 R2

先读 `RESEARCH_MEMO.md`，文献细目见 `LITERATURE.md`，全部证据范围/缺口见 `EVIDENCE_INDEX.md`。这里不分配人员、不启动服务，不是最终求解器。

本包只含本轮研究与有界实验，不重复装入官方代码、100个大图或外部论文PDF。理论公式使用M编号，与聊天正文的R编号区分。

## 复现本轮小核验

仅Python标准库；将`OFFICIAL`设为已有官方附件解压后的根目录（内有`code/`、`data/config.txt`）。输出用独立目录。

```bash
python new_evidence/structure_checks.py
python new_evidence/official_new_probes.py "$OFFICIAL" ./rerun/new_official
python new_evidence/repeated_counts_probe.py "$OFFICIAL" ./rerun/repeated_counts
python new_evidence/replay_old_microprobes.py "$OFFICIAL" ./rerun/old_micro
```

`official_new_probes.py`会读取本包`form/tests/adversarial/ranking-inversion-pair.json`，这是用户本次增量夹具的一份未修改复制。包装脚本只构造微图并调用官方函数，不修改原代码/config。`verify_assets.py`是本轮挂载目录身份审计脚本，路径对应本会话环境，不是通用交付CLI。

`payload_manifest.json`列出文件身份。第一次和第二次包装脚本开发错误作为追溯记录保留；完整新结果为v3，不能把旧partial目录当作额外完整实验。
