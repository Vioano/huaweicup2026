#!/usr/bin/env python3
"""Static audit of the contest Op-Tensor graph. Python standard library only.

NOT the official evaluator: no Task construction, spill insertion, multicore
simulation, measured Makespan, or contest score is produced.

Usage:
  python profile_graph.py data/case_001.json --config data/config.txt --out audit
  python profile_graph.py data --config data/config.txt --out audit

The DFS/lifetime experiment is a transcription of the supplied documentation,
not a verified reproduction of the official Python implementation. Its memory
peaks are sequential no-spill peaks, NOT multicore runtime peaks.
"""
from __future__ import annotations
import argparse
import collections
import hashlib
import heapq
import json
import math
from pathlib import Path
from typing import Any, Iterable

COPY = {"COPY_IN", "COPY_OUT"}
PIPES = {"PIPE_M", "PIPE_V", "PIPE_MTE2", "PIPE_MTE3"}


def natural(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{label}: expected a nonnegative integer")
    return value


def read_config(path: Path) -> dict[str, dict[str, int]]:
    """Read the supplied whitespace-delimited configuration; no guessed values."""
    result: dict[str, dict[str, int]] = {}
    section = None
    for number, raw in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            if section in result:
                raise ValueError(f"Duplicate config section: {section}")
            result[section] = {}
        else:
            parts = line.split()
            if section is None or len(parts) != 2:
                raise ValueError(f"Invalid config line {number}: {raw}")
            key, text = parts
            value = int(text)
            if value <= 0 or key in result[section]:
                raise ValueError(f"Invalid/duplicate config key at line {number}")
            result[section][key] = value
    for section, keys in {
        "capacity": ("L1", "UB"), "bandwidth": ("bandwidth",),
        "problem_3": ("cache_capacity_bytes", "cache_bandwidth_bytes_per_cycle"),
    }.items():
        for key in keys:
            if key not in result.get(section, {}):
                raise ValueError(f"Missing config value [{section}] {key}")
    return result


def topo(nodes: Iterable[int], successors: dict[int, set[int]]) -> list[int]:
    nodes = set(nodes)
    indegree = dict.fromkeys(nodes, 0)
    for u in nodes:
        for v in successors[u]:
            if v in nodes:
                indegree[v] += 1
    ready = [u for u, n in indegree.items() if n == 0]
    heapq.heapify(ready)
    order = []
    while ready:
        u = heapq.heappop(ready)
        order.append(u)
        for v in sorted(successors[u]):
            if v in nodes:
                indegree[v] -= 1
                if indegree[v] == 0:
                    heapq.heappush(ready, v)
    if len(order) != len(nodes):
        raise ValueError("Graph is cyclic")
    return order


def components(nodes: Iterable[int], edges: Iterable[tuple[int, int]]) -> list[set[int]]:
    """Weak components: temporarily ignore edge direction, never discard nodes."""
    nodes = set(nodes)
    adjacent = {u: set() for u in nodes}
    for u, v in edges:
        if u in nodes and v in nodes:
            adjacent[u].add(v)
            adjacent[v].add(u)
    remaining = set(nodes)
    result = []
    while remaining:
        root = min(remaining)
        remaining.remove(root)
        found = {root}
        stack = [root]
        while stack:
            u = stack.pop()
            for v in adjacent[u]:
                if v in remaining:
                    remaining.remove(v)
                    found.add(v)
                    stack.append(v)
        result.append(found)
    return result


def audit(path: Path, config: dict[str, dict[str, int]]) -> dict[str, Any]:
    raw = path.read_bytes()
    graph = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(graph, dict) or not all(isinstance(graph.get(k), list) for k in ("ops", "tensors", "edges")):
        raise ValueError("Not an original graph: expected ops/tensors/edges arrays")
    ops, tensors = {}, {}
    for item in graph["ops"]:
        oid = natural(item["id"], "op.id")
        natural(item["cycles"], "op.cycles")
        if oid in ops or item["pipe"] not in PIPES or not isinstance(item["op"], str):
            raise ValueError(f"Invalid/duplicate op {oid}")
        ops[oid] = item
    for item in graph["tensors"]:
        tid = natural(item["id"], "tensor.id")
        natural(item["size"], "tensor.size")
        if tid in tensors or tid in ops or item["pos"] not in {"DDR", "L1", "UB"}:
            raise ValueError(f"Invalid/duplicate tensor {tid}")
        tensors[tid] = item
    if not ops:
        raise ValueError("No operations")
    ins = {o: set() for o in ops}
    outs = {o: set() for o in ops}
    prods = {t: set() for t in tensors}
    cons = {t: set() for t in tensors}
    edges = set()
    for edge in graph["edges"]:
        u = natural(edge["source"], "edge.source")
        v = natural(edge["target"], "edge.target")
        if (u, v) in edges:
            raise ValueError(f"Duplicate edge {u}->{v}")
        edges.add((u, v))
        if u in ops and v in tensors:
            outs[u].add(v); prods[v].add(u)
        elif u in tensors and v in ops:
            ins[v].add(u); cons[u].add(v)
        else:
            raise ValueError(f"Non-bipartite or missing endpoint: {u}->{v}")
    if any(len(ps) > 1 for ps in prods.values()):
        raise ValueError("This analyzer requires single-producer tensors")
    allnodes = set(ops) | set(tensors)
    bsucc = {u: set() for u in allnodes}
    for u, v in edges:
        bsucc[u].add(v)
    topo(allnodes, bsucc)
    preds = {o: set() for o in ops}
    succs = {o: set() for o in ops}
    for tid in tensors:
        for u in prods[tid]:
            for v in cons[tid]:
                succs[u].add(v); preds[v].add(u)
    order = topo(ops, succs)
    compute = {o for o in ops if ops[o]["op"] not in COPY}
    op_edges = {(u, v) for u in ops for v in succs[u]}
    comp_edges = {(u, v) for u, v in op_edges if u in compute and v in compute}
    full_comps = components(allnodes, edges)
    compute_comps = components(compute, comp_edges)
    pipe_cycles = {pipe: sum(o["cycles"] for o in ops.values() if o["pipe"] == pipe and o["op"] not in COPY) for pipe in sorted(PIPES)}

    depth, dp, parent = {}, {}, {}
    for o in order:
        depth[o] = max((depth[u] + 1 for u in preds[o]), default=0)
        best = max(preds[o], key=lambda u: (dp[u], -u), default=None)
        parent[o] = best
        dp[o] = (dp[best] if best is not None else 0) + (ops[o]["cycles"] if o in compute else 0)
    current = max(ops, key=lambda u: (dp[u], -u))
    compute_cp = dp[current]
    cp_path = []
    while current is not None:
        cp_path.append(current)
        current = parent[current]
    cp_path.reverse()

    def component_record(group: set[int]) -> dict[str, Any]:
        co = group & compute
        tin = {t for o in co for t in ins[o]}
        tout = {t for o in co for t in outs[o]}
        ext_in = {t for t in tin if not prods[t] & co}
        ext_out = {t for t in tout if cons[t] - co or not cons[t]}
        return {
            "compute_ops": len(co), "op_ids": sorted(co),
            "M_cycles": sum(ops[o]["cycles"] for o in co if ops[o]["pipe"] == "PIPE_M"),
            "V_cycles": sum(ops[o]["cycles"] for o in co if ops[o]["pipe"] == "PIPE_V"),
            "op_types": dict(sorted(collections.Counter(ops[o]["op"] for o in co).items())),
            "external_input_tensor_ids": sorted(ext_in),
            "external_input_bytes": sum(tensors[t]["size"] for t in ext_in),
            "external_output_tensor_ids": sorted(ext_out),
            "external_output_bytes": sum(tensors[t]["size"] for t in ext_out),
        }

    cindex = {o: i for i, group in enumerate(compute_comps) for o in group}
    shared = []
    for tid in sorted(tensors):
        groups = {cindex[o] for o in cons[tid] if o in cindex}
        if len(groups) > 1:
            shared.append({"tensor_id": tid, "bytes": tensors[tid]["size"], "components": sorted(groups), "consumer_ops": sorted(cons[tid])})

    # Follow the documented reverse-DFS traversal, without Task modifications.
    def key(o: int) -> tuple[bool, int, int]:
        return (ops[o]["op"] != "COPY_IN", depth[o], -o)
    def start_key(o: int) -> tuple[bool, int, int]:
        return (ops[o]["op"] != "COPY_OUT", depth[o], -o)
    stack = sorted((o for o in ops if not succs[o]), key=start_key)
    seen, seq = set(), []
    while stack or len(seen) < len(ops):
        if not stack:
            stack = sorted(set(ops) - seen, key=key)
        u = stack[-1]
        if u in seen:
            stack.pop(); continue
        ps = preds[u] - seen
        if ps:
            stack.extend(sorted(ps, key=key))
        else:
            seen.add(u); seq.append(u); stack.pop()
    rank = {o: i for i, o in enumerate(seq)}
    if len(rank) != len(ops) or any(rank[u] >= rank[v] for u, v in op_edges):
        raise ValueError("Documented DFS reconstruction failed topological validation")

    def memory_profile(sequence: list[int]) -> dict[str, Any]:
        onchip = {t for t in tensors if tensors[t]["pos"] != "DDR"}
        remaining = {t: len(prods[t] | cons[t]) for t in onchip}
        active = {t for t in onchip if not prods[t] and cons[t]}
        used = {m: sum(tensors[t]["size"] for t in active if tensors[t]["pos"] == m) for m in ("L1", "UB")}
        peak = used.copy()
        peak_at: dict[str, Any] = {}
        overflow_steps = {m: int(used[m] > config["capacity"][m]) for m in used}
        for step, o in enumerate(sequence):
            touched = (ins[o] | outs[o]) & onchip
            for t in sorted(touched):
                if t not in active:
                    active.add(t); used[tensors[t]["pos"]] += tensors[t]["size"]
            for mem in used:
                if used[mem] > peak[mem]:
                    peak[mem] = used[mem]
                    peak_at[mem] = {"step": step, "op": o}
                if used[mem] > config["capacity"][mem]:
                    overflow_steps[mem] += 1
            for t in sorted(touched):
                remaining[t] -= 1
                if remaining[t] == 0:
                    active.remove(t); used[tensors[t]["pos"]] -= tensors[t]["size"]
        if active or any(used.values()):
            raise ValueError("Sequential lifecycle accounting did not return to zero")
        return {"peak_bytes": peak, "peak_at": peak_at, "overflow_step_counts": overflow_steps, "final_bytes": used}

    sources = {t for t in tensors if tensors[t]["pos"] == "DDR" and not prods[t] and cons[t]}
    sinks = {t for t in tensors if tensors[t]["pos"] == "DDR" and not cons[t] and prods[t]}
    original_in = sum(sum(tensors[t]["size"] for t in outs[o]) for o in ops if ops[o]["op"] == "COPY_IN")
    original_out = sum(sum(tensors[t]["size"] for t in ins[o]) for o in ops if ops[o]["op"] == "COPY_OUT")
    minimal_ddr = sum(tensors[t]["size"] for t in sources | sinks)
    bounds = []
    for n in range(1, 6):
        terms = {"compute_path": compute_cp, "M_work_per_core": pipe_cycles["PIPE_M"]/n,
                 "V_work_per_core": pipe_cycles["PIPE_V"]/n,
                 "mandatory_DDR_bytes_over_bandwidth": minimal_ddr/config["bandwidth"]["bandwidth"]}
        bounds.append({"num_cores": n, "terms": terms, "integer_cycle_lower_bound": math.ceil(max(terms.values()))})

    largest_vector = max(compute_comps, key=lambda co: sum(ops[o]["cycles"] for o in co if ops[o]["pipe"] == "PIPE_V"), default=set())
    # Diagnostic threshold only: not a recommended universal partition rule.
    large_edges = {(u,v) for t in tensors if tensors[t]["size"] > 2
                   for u in prods[t] for v in cons[t] if u in largest_vector and v in largest_vector}
    islands = components(largest_vector, large_edges)
    island_counts = collections.Counter((len(co), sum(ops[o]["cycles"] for o in co)) for co in islands)
    return {
        "analysis_type": "STATIC_ONLY_NOT_OFFICIAL_EVALUATION",
        "input_name": path.name, "input_sha256": hashlib.sha256(raw).hexdigest(), "input_bytes": len(raw),
        "config": config,
        "checks": {"global_unique_ids": True, "bipartite": True, "DAG": True, "single_producer": True,
                   "does_not_check_official_multicore_plan_validity": True},
        "counts": {"all_nodes": len(allnodes), "ops": len(ops), "compute_ops": len(compute), "tensors": len(tensors),
                   "bipartite_edges": len(edges), "op_dependency_edges": len(op_edges), "compute_dependency_edges": len(comp_edges),
                   "full_weak_components": len(full_comps), "compute_weak_components": len(compute_comps)},
        "op_counts": dict(sorted(collections.Counter(o["op"] for o in ops.values()).items())),
        "pipe_counts": dict(sorted(collections.Counter(o["pipe"] for o in ops.values()).items())),
        "compute_cycles_by_pipe": pipe_cycles,
        "tensor_stats_by_position": {m:{"count":sum(t["pos"]==m for t in tensors.values()),
            "total_bytes_not_peak":sum(t["size"] for t in tensors.values() if t["pos"]==m),
            "max_single_tensor_bytes":max((t["size"] for t in tensors.values() if t["pos"]==m),default=0)} for m in ("DDR","L1","UB")},
        "raw_DDR_source_count":len(sources), "raw_DDR_source_bytes":sum(tensors[t]["size"] for t in sources),
        "raw_DDR_output_count":len(sinks), "raw_DDR_output_bytes":sum(tensors[t]["size"] for t in sinks),
        "original_copy_bytes":{"COPY_IN":original_in,"COPY_OUT":original_out,"total":original_in+original_out},
        "compute_only_critical_path_cycles":compute_cp, "compute_only_critical_path_op_ids":cp_path,
        "no_L2_resource_lower_bounds":bounds,
        "lower_bound_assumptions":"All given compute operations must execute once; N homogeneous cores; each Pipe is serial; no L2; mandatory external inputs/outputs transferred at least once; no computation rewriting. Not an attainable-runtime prediction.",
        "full_components":[component_record(co) for co in full_comps],
        "compute_components":[component_record(co) for co in compute_comps],
        "shared_inputs_between_compute_components":shared,
        "top_fanout_tensors":[{"tensor_id":t, "position":tensors[t]["pos"], "bytes":tensors[t]["size"],
            "producers":sorted(prods[t]),"consumers":sorted(cons[t])} for t in sorted(tensors,key=lambda t:(-len(cons[t]),t))[:20]],
        "sequential_no_spill_memory":{
            "documented_reverse_DFS":memory_profile(seq),
            "id_priority_topological":memory_profile(order),
            "qualification":"Documentation transcription only, original whole graph, alloc-before-last-use-free, no spill insertion, no multicore/Pipe concurrency. Neither an official result nor a runtime-memory prediction.",
        },
        "largest_V_component_scalar_cut_diagnostic":{
            "component":component_record(largest_vector), "retained_edge_tensor_size_threshold_bytes":2,
            "meaning":"Remove only compute dependencies carried by tensors of at most 2 bytes; used for static structure discovery, not as a feasible output partition.",
            "island_count":len(islands),
            "island_shape_counts":[{"ops":n,"compute_cycles":c,"count":k} for (n,c),k in sorted(island_counts.items())],
            "islands":[component_record(co) for co in islands],
        },
    }


def markdown(report: dict[str, Any]) -> str:
    c = report["counts"]
    rows = ["# Static graph audit", "", "**Not an official evaluation or a submitted solution.**", "",
            f"Input: `{report['input_name']}`", f"SHA-256: `{report['input_sha256']}`", "", "## Counts", "",
            "| Metric | Value |", "|---|---:|"]
    rows += [f"| {k} | {v:,} |" for k,v in c.items()]
    rows += ["", "## Compute work", "", "| Pipe | Cycles (not Makespan) |", "|---|---:|"]
    rows += [f"| {p} | {v:,} |" for p,v in report["compute_cycles_by_pipe"].items()]
    rows += ["",f"Compute-only critical path: {report['compute_only_critical_path_cycles']:,} cycles.",
             f"Raw DDR inputs: {report['raw_DDR_source_count']} tensors, {report['raw_DDR_source_bytes']:,} bytes.",
             f"Raw DDR outputs: {report['raw_DDR_output_count']} tensors, {report['raw_DDR_output_bytes']:,} bytes.",
             "", "## Relaxed resource lower bounds without L2", "", report["lower_bound_assumptions"], "",
             "| Cores | Lower bound (integer cycles) |", "|---|---:|"]
    rows += [f"| {r['num_cores']} | {r['integer_cycle_lower_bound']:,} |" for r in report["no_L2_resource_lower_bounds"]]
    rows += ["", "## Sequential no-spill memory scan", "", report["sequential_no_spill_memory"]["qualification"], "",
             "| Scan order | L1 peak (bytes) | UB peak (bytes) |", "|---|---:|---:|"]
    for name in ("documented_reverse_DFS", "id_priority_topological"):
        peaks = report["sequential_no_spill_memory"][name]["peak_bytes"]
        rows.append(f"| {name} | {peaks['L1']:,} | {peaks['UB']:,} |")
    rows += ["", "## Compute-dependency components", "",
             "Shared input tensors can couple these components through communication even when no compute-to-compute dependency crosses them.","",
             "| Component | Ops | M cycles | V cycles | External-input bytes |", "|---|---:|---:|---:|---:|"]
    for i, comp in enumerate(report["compute_components"]):
        rows.append(f"| {i} | {comp['compute_ops']} | {comp['M_cycles']:,} | {comp['V_cycles']:,} | {comp['external_input_bytes']:,} |")
    rows += ["", "## Largest V component: scalar-cut diagnostic", "",
             report["largest_V_component_scalar_cut_diagnostic"]["meaning"], "",
             "| Island ops | Island compute cycles | Count |", "|---|---:|---:|"]
    for row in report["largest_V_component_scalar_cut_diagnostic"]["island_shape_counts"]:
        rows.append(f"| {row['ops']} | {row['compute_cycles']} | {row['count']} |")
    rows += ["", "Exact component membership, tensor consumers, and all derived metrics are in the accompanying JSON.", ""]
    return "\n".join(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="One original graph JSON or its directory")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path("audit"))
    args = parser.parse_args()
    try:
        config = read_config(args.config)
    except (OSError, ValueError, KeyError) as exc:
        parser.error(str(exc))
    paths = sorted(args.input.glob("*.json")) if args.input.is_dir() else [args.input]
    args.out.mkdir(parents=True, exist_ok=True)
    summaries, failures = [], []
    for path in paths:
        # Do not interpret previous result/Trace JSONs as original inputs.
        if args.input.is_dir() and any(token in path.stem for token in ("_res", "_trace", "_profile")):
            continue
        try:
            report = audit(path, config)
            stem = path.stem + "_profile"
            (args.out / (stem + ".json")).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            (args.out / (stem + ".md")).write_text(markdown(report), encoding="utf-8")
            summaries.append({"input":path.name,"sha256":report["input_sha256"], **report["counts"],
                              "M_cycles":report["compute_cycles_by_pipe"]["PIPE_M"],
                              "V_cycles":report["compute_cycles_by_pipe"]["PIPE_V"],
                              "compute_cp":report["compute_only_critical_path_cycles"],
                              "raw_input_bytes":report["raw_DDR_source_bytes"]})
            print(f"OK {path.name}: {report['counts']['compute_ops']} compute ops; {report['counts']['compute_weak_components']} compute components")
        except (OSError, ValueError, KeyError, TypeError) as exc:
            failures.append({"input":str(path),"error":str(exc)})
            print(f"ERROR {path}: {exc}")
    (args.out / "batch_summary.json").write_text(json.dumps({"static_only":True,"successes":summaries,"failures":failures}, ensure_ascii=False, indent=2)+"\n",encoding="utf-8")
    return 1 if failures or not summaries else 0

if __name__ == "__main__":
    raise SystemExit(main())
