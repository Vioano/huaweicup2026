from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[1]
heads=json.loads((R/'evidence/heads.json').read_text())
# Reading registration, not an assertion that remote bodies were materialized.
rows=[]
def add(ref, paths, scope='full text through authorized GitHub connector'):
    for p in paths:
        rows.append({'repo':'Vioano/huaweicup2026','ref':ref,'path':p,'read_scope':scope})
q1='4dff90ef699fd51845cf482951e8477066f5f566'
add(q1,[f'docs/a/{n}.md' for n in ['Q1_SEARCH','Q1_GUIDED_MOVES','Q1_PROFILE_REFINE','Q1_RELEASE_IDEALS_REVIEW','Q1_TRACE_EXPLANATION','Q1_TRACE_PROSPECTIVE']]+['docs/a/research/20260924-pro-archive/PRO4_Q1_AUDIT_UPDATE.md','results/a/q1-q2-mechanism-pro008-20260924/summary.json'])
add('5bfe53a29c1ba05167239f51ea937e602f7f85b4',['docs/a/exact/P1_BATCH.md','src/eval_exact/batch.py'])
add('03f02e79de4b4bd6f55241385664b154f4332454',['research/a/native-replay-20260924/README.md','research/a/native-replay-20260924/HANDOFF.md'])
add('74c46372faf5910b9b3cce6ad9a61a7e040b17aa',['results/a/q2-nikolastarx/joint-20260924/summary.json','results/a/q2-nikolastarx/joint-20260924/metrics.csv'])
add('0b58c123cccf02fc993b741d79dcd8511e4dd38f',['results/a/q2-yuanzhifang/stage-b-20260924-042906/REPORT.md'])
add('0b58c123cccf02fc993b741d79dcd8511e4dd38f',['src/q2/budget_search.py'],'lines 1-210')
add('0b58c123cccf02fc993b741d79dcd8511e4dd38f',['docs/a/Q2_HANDOFF.md'],'visible body; tail tool-truncated, not claimed complete')
add('a4e7ee13310d693ec4fb5cc236669ceb3b172d1f',['src/q3/construct.py','results/a/q3-nikolastarx/pilot-20260924/metrics.csv','results/a/q3-nikolastarx/pilot-20260924/REPORT.md','results/a/q3-nikolastarx/online-20260924/REPORT.md','results/a/q3-nikolastarx/pilot-20260924/best/manifest.json'])
add('abdfd31f358a035e5ecca3b0482a9d0881060ffe',['docs/a/e2/CONCURRENT_EVALUATION_DESIGN.md'],'sections 1-4 / requested lines1-175; tail tool-truncated')
add('abdfd31f358a035e5ecca3b0482a9d0881060ffe',['docs/a/e2/NEEDS_AND_EVIDENCE.md'],'visible content body (response metadata tail truncated)')
add('abdfd31f358a035e5ecca3b0482a9d0881060ffe',['docs/a/e2/ROUTE_COST_REVIEW.md'])
add('603b0741e21c449d3db652ebd67c94f2dc014cc9',['research/a/e2_search/P23_HANDOFF.md','research/a/e2_search/scene_b.py'])
add('f27ef37bb76dcf556f35d3f2328e405d92241d9c',['README.md'])
add('f27ef37bb76dcf556f35d3f2328e405d92241d9c',['docs/a/source-manifest.json'],'lines1-90 and94-115 plus prior local bytes identity; not full case manifest revalidation')
add('f27ef37bb76dcf556f35d3f2328e405d92241d9c',['data/raw/a/official/code/multicore_cut_evaluate_problem_2.py'],'connector lines482-610; entire file separately read from identical local official attachment')
add('65d6c0e6facee2ec8ce9694c30dd805de99abf7e',['formal/SPEC.md'],'visible sections0-4 plus partial reproducibility section; tool tail truncated')
add('e1575a1de5e3b921aef350e920720f0584fb1719',['results/a/review/q1-form-65d6c0e/REVIEW.md'],'lines1-100; no new run of this historical probe')
local=[]
for n in ['multicore_cut_evaluate_problem_1.py','multicore_cut_evaluate_problem_2.py','multicore_cut_evaluate_problem_3.py','schedule_step1.py','schedule_step2.py','schedule_step3.py','singlecore_evaluate.py']:
 p=R/'source/official/code'/n
 local.append({'path':'source/official/code/'+n,'read_scope':'entire source read in runtime','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'identity':'same frozen source manifest as main; not fetched anew in full through connector'})
local += [{'path':'source/official/code/evaluation_validation.py','read_scope':'relevant validation and execution checks'}, {'path':'source/official/code/stub_multicore_cut_and_schedule.py','read_scope':'COPY contraction and plan derivation'}, {'path':'source/context/docs__a__contract-v1.md','read_scope':'sections1-4.4, local DELTA matched remote Git blob65227eaea35fa1aa9457005cc0832aa2bb363afd'}, {'path':'source/context/formal__SPEC.md','read_scope':'historical86b local context; not latest65d; no whole-FORM acceptance'}]
manifest={'head_pinning':'authorized refs were read individually, then files read by immutable SHA; not one atomic multi-ref transaction','heads':heads,'remote_reads':rows,'local_reads':local,'runtime_transport_limits':'No private GitHub URLs used in web search. Container download attempts failed; peak plan reconstructed then matched both published digests.'}
(R/'READ_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
p=R/'RESEARCH_MEMO.md';s=p.read_text();s=s.replace('用于固定事件图/max-plus背景；Paige–Tarjan','本轮进一步读了§3.2.3中Theorem 3.17/3.20与证明的路径解释，用于固定事件图/max-plus背景；Paige–Tarjan').replace('核对元数据及原报告入口，本实现','核对元数据，并通过原稿前两页截图读了关系最粗细化问题的定义，本实现');p.write_text(s)
# Include only the two explicitly used formal cases, not all100 mounted cases.
selected=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R).as_posix()
 if rel=='MANIFEST.json' or '__pycache__' in rel or p.suffix=='.pyc':continue
 if rel.startswith('source/official/data/') and p.name not in ['case_008.json','case_044.json','config.txt']:continue
 if rel.startswith('source/official/') and not (rel.startswith('source/official/code/') or rel.startswith('source/official/data/')):continue
 selected.append(p)
files=[{'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected]
(R/'MANIFEST.json').write_text(json.dumps({'scope':'all ZIP payload files except MANIFEST itself','files':files},ensure_ascii=False,indent=2)+'\n')
archive=R.parent/'Official_Mapping_Architecture.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in selected+[R/'MANIFEST.json']:
  z.write(p,'Official_Mapping_Architecture/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(archive) as z:
 for row in files:
  data=z.read('Official_Mapping_Architecture/'+row['path'])
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
print(json.dumps({'payload_files':len(files),'zip_bytes':archive.stat().st_size,'zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'member_hashes_verified':True},indent=2))
