"""Exact finite-view test for CRG D14 versus D15.
Scope: frozen official Q2, k=1; four independent tensor-free ops; all 24 singleton
orders. Synthetic API-domain input, not claimed representative of formal cases.
24 E0 function calls only. All future adjacent position swaps stay inside this
closed domain, so finite partition refinement checks the specified full D15
relation on THIS 24-state universe, not a sampled larger state space.
"""
from pathlib import Path
import sys,json,itertools,hashlib,gzip,time
R=Path(__file__).resolve().parents[1]; O=R/'source/official';sys.path.insert(0,str(O/'code'))
from multicore_cut_evaluate_problem_2 import evaluate_scene_b
from evaluation_validation import read_evaluation_config
OUT=R/'evidence/new/quotient';OUT.mkdir(parents=True,exist_ok=False)
g={'ops':[{'id':1,'op':'CONV','pipe':'PIPE_M','cycles':2},{'id':2,'op':'CONV','pipe':'PIPE_M','cycles':5},{'id':3,'op':'VADD','pipe':'PIPE_V','cycles':3},{'id':4,'op':'VADD','pipe':'PIPE_V','cycles':11}], 'tensors':[],'edges':[]}
perms=list(itertools.permutations(range(4))); lookup={p:i for i,p in enumerate(perms)}
config=read_evaluation_config(str(O/'data/config.txt'))
protocol={'domain':'Q2 API-valid tensor-free four-op synthetic domain; not formal-data distribution', 'k':1,'max_e0_function_calls':24,'primitive':'a_i swaps positions i,i+1 in core0, i=0,1,2; map fixed', 'observations':{'phi_time':'per-original-op exact (start,end) keyed by op_id', 'phi_full':'entire official Python result converted losslessly for numeric keys for this sample'},'closed_under_operations':True,'new_score_claim':False}
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n'); (OUT/'graph.json').write_text(json.dumps(g,indent=2)+'\n')
rows=[];start=time.monotonic()
for i,order in enumerate(perms):
 p={'node_to_subgraph':{str(u):u-1 for u in range(1,5)},'core_schedules':[list(order)]}
 result=evaluate_scene_b(g,p,bandwidth=config['bandwidth'],capacity=config['capacity'],cross_core_copy_delay=500)
 t=tuple((op['op_id'],op['start'],op['end']) for op in sorted(result['per_core_timeline'][0]['ops'],key=lambda x:x['op_id']))
 encoded=json.dumps(result,ensure_ascii=False,separators=(',',':'))
 with gzip.open(OUT/f'{i:02d}.json.gz','wt',encoding='utf-8') as f:json.dump({'plan':p,'result':result},f,ensure_ascii=False)
 rows.append({'index':i,'order':list(order),'times':t,'makespan':result['makespan'],'full_hash':hashlib.sha256(encoded.encode()).hexdigest()})
def label(keys):
 d={};return [d.setdefault(k,len(d)) for k in keys]
trans=[]
for p in perms:
 row=[]
 for j in range(3):
  q=list(p);q[j],q[j+1]=q[j+1],q[j];row.append(lookup[tuple(q)])
 trans.append(row)
labels=label([r['times'] for r in rows]);levels=[{'horizon':0,'classes':len(set(labels)),'labels':labels}]
for h in range(1,25):
 new=label([(labels[i],tuple(labels[j] for j in trans[i])) for i in range(24)])
 levels.append({'horizon':h,'classes':len(set(new)),'labels':new})
 if len(set(new))==len(set(labels)):break
 labels=new
# Select an explicit same-current/different-one-step witness, without additional E0.
witness=None
for i in range(24):
 for j in range(i+1,24):
  if rows[i]['times']!=rows[j]['times']:continue
  for a in range(3):
   if rows[trans[i][a]]['times']!=rows[trans[j][a]]['times']:
    witness={'p1':rows[i],'p2':rows[j],'operation_position':a,'after1':rows[trans[i][a]],'after2':rows[trans[j][a]]};break
  if witness:break
 if witness:break
summary={'new_e0_function_calls':24,'wall_seconds':time.monotonic()-start,'immediate_time_classes':len(set(r['times'] for r in rows)), 'immediate_makespan_classes':len(set(r['makespan'] for r in rows)), 'full_result_classes':len(set(r['full_hash'] for r in rows)), 'levels':levels,'transition_table':trans,'witness':witness, 'scope':protocol}
(OUT/'rows.json').write_text(json.dumps(rows,indent=2)+'\n');(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print({k:v for k,v in summary.items() if k in ['new_e0_function_calls','wall_seconds','immediate_time_classes','immediate_makespan_classes','full_result_classes']});print([(l['horizon'],l['classes']) for l in levels])
