"""Bounded new E0 verification. No search, no changes to official bytes.
Exactly five CLI requests declared before running; per-call deadline 30s.
"""
from pathlib import Path
import sys,json,subprocess,hashlib,time,platform
R=Path(__file__).resolve().parents[1];O=R/'source/official';out=R/'evidence/new/peak'
out.mkdir(parents=True,exist_ok=False)
plan=R/'source/reconstructed/case008_resource_word.json'
settings=[('single008','singlecore_evaluate.py','008',None),('single044','singlecore_evaluate.py','044',None),('q2_peak008','multicore_cut_evaluate_problem_2.py','008',plan),('q3_peak008','multicore_cut_evaluate_problem_3.py','008',plan),('q1_same_plan008','multicore_cut_evaluate_problem_1.py','008',plan)]
hash_file=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p.name:hash_file(p) for p in sorted((O/'code').glob('*.py'))}
protocol={'calls':[(label,script,case) for label,script,case,_ in settings],'max_calls':5,'timeout_each':30,'kind':'specific published peak and cross-q diagnostic, not a search','python':sys.version,'platform':platform.platform(),'official_hashes':before}
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
rows=[]
for label,script,case,p in settings:
 d=out/label;d.mkdir();cmd=[sys.executable,'-B',str(O/'code'/script),str(O/f'data/case_{case}.json')]
 if p:cmd.append(str(p))
 cmd+=['--config',str(O/'data/config.txt'),'-o',str(d/'result.json'),'--trace-output',str(d/'trace.json'),'--log-output',str(d/'log.txt')]
 row={'label':label,'command':cmd,'graph_sha256':hash_file(O/f'data/case_{case}.json'),'plan_sha256':hash_file(p) if p else None,'status':'dispatched'};rows.append(row)
 (out/'ledger.json').write_text(json.dumps(rows,indent=2)+'\n');start=time.monotonic()
 try:
  run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
  (d/'stdout.txt').write_bytes(run.stdout);(d/'stderr.txt').write_bytes(run.stderr)
  row.update(wall_seconds=time.monotonic()-start,returncode=run.returncode)
  if run.returncode==0:
   result=json.loads((d/'result.json').read_text());row.update(status='ok',makespan=result['makespan'],movement=result['data_movement_bytes'],result_sha256=hash_file(d/'result.json'))
   if 'cache_stats' in result:row['cache_stats']=result['cache_stats']
  else:row['status']='error'
 except subprocess.TimeoutExpired:row.update(status='timeout',wall_seconds=time.monotonic()-start)
 (out/'ledger.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(label,row.get('makespan'),row['status'])
 if row['status']!='ok':break
assert before=={p.name:hash_file(p) for p in sorted((O/'code').glob('*.py'))}
summary={'rows':rows,'official_files_unchanged':True,'new_e0_cli_calls':len(rows)}
if len(rows)==5 and all(x['status']=='ok' for x in rows):
 assert rows[2]['makespan']==rows[3]['makespan']==63768
 summary['speedup008']=rows[0]['makespan']/63768
 summary['q1_reported044_speedup']=rows[1]['makespan']/114443
 summary['q1_reported044_note']='114443 from pinned AUTHOR-REPORT; not independently rerun here'
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
