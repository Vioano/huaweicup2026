"""Zero new evaluations. Verify logical-plan recovery from saved complete results.
Canonicalization here ONLY checks a theorem: it is not installed as a cache key.
"""
from pathlib import Path
import json,gzip
R=Path(__file__).resolve().parents[1]
def recover(g,result):
 eligible={op['id'] for op in g['ops'] if op['op'] not in {'COPY_IN','COPY_OUT'}}
 mapping={}; orders=[None]*result['num_cores']
 for core in result['per_core_timeline']:
  orders[core['core_id']]=[t['subgraph_id'] for t in core['subgraphs']]
  for op in core['ops']:
   if op['op_id'] not in eligible:continue
   assert op['op_id'] not in mapping
   mapping[op['op_id']]=op.get('subgraph_id',op['task_id'])
 assert set(mapping)==eligible and all(row is not None for row in orders)
 return {'node_to_subgraph':{str(i):mapping[i] for i in sorted(mapping)},'core_schedules':orders}
def canonical(p):return {'node_to_subgraph':{str(i):v for i,v in sorted((int(i),v) for i,v in p['node_to_subgraph'].items())},'core_schedules':p['core_schedules']}
rows=[];g=json.loads((R/'source/official/data/case_008.json').read_text());p=json.loads((R/'source/reconstructed/case008_resource_word.json').read_text())
for lab in ['q1_same_plan008','q2_peak008','q3_peak008']:
 result=json.loads((R/f'evidence/new/peak/{lab}/result.json').read_text());assert recover(g,result)==canonical(p);rows.append(lab)
g=json.loads((R/'evidence/new/quotient/graph.json').read_text())
for path in sorted((R/'evidence/new/quotient').glob('*.json.gz')):
 with gzip.open(path,'rt') as f:x=json.load(f)
 assert recover(g,x['result'])==canonical(x['plan']);rows.append(path.name)
out={'checked_results':len(rows),'new_evaluator_calls':0,'all_logical_plans_recovered':True,'items':rows,'limit':'Numeric logical mapping and ordered core_schedules only; raw JSON insertion order/spelling not reconstructed.'}
(R/'evidence/new/recovery.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
