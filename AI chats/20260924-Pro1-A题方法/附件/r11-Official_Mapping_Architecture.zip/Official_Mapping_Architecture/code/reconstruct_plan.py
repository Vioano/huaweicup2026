"""Reconstruct the pinned source's resource_word output; require both published hashes.
Not a new solver nor a source-file-byte reproduction. Only the plan bytes are verified.
"""
from pathlib import Path
import sys,json,heapq,hashlib
ROOT=Path(__file__).resolve().parents[1]
OFF=ROOT/'source/official'; sys.path.insert(0,str(OFF/'code'))
from stub_multicore_cut_and_schedule import _build_op_adjacency,_contract_excluded_copy_nodes,derive_multicore_plan

def topo(nodes,succ):
    nodes=set(nodes); deg=dict.fromkeys(nodes,0)
    for u in nodes:
        for v in succ[u]:
            if v in nodes: deg[v]+=1
    ready=[u for u in nodes if not deg[u]]; heapq.heapify(ready); out=[]
    while ready:
        u=heapq.heappop(ready);out.append(u)
        for v in sorted(succ[u]):
            if v in nodes:
                deg[v]-=1
                if not deg[v]: heapq.heappush(ready,v)
    assert len(out)==len(nodes);return out

def construct(g,k=4,strategy='resource_word'):
    ops={o['id']:o for o in g['ops'] if o['op'] not in {'COPY_IN','COPY_OUT'}}
    _,osucc=_build_op_adjacency(g);pred,succ=_contract_excluded_copy_nodes(ops,osucc)
    order=topo(ops,succ);remaining=set(ops);owner={};components=[]
    for root in order:
        if root not in remaining:continue
        j=len(components);components.append([]);remaining.remove(root);stack=[root]
        while stack:
            u=stack.pop();owner[u]=j
            for v in pred[u]|succ[u]:
                if v in remaining:remaining.remove(v);stack.append(v)
    for u in order:components[owner[u]].append(u)
    d=lambda u:max(1,ops[u]['cycles']);pipes=('PIPE_M','PIPE_V','PIPE_MTE2','PIPE_MTE3')
    work=[[sum(d(u) for u in c if ops[u]['pipe']==p) for p in pipes] for c in components]
    total=[max(1,sum(w[p] for w in work)) for p in range(4)]
    load=[[0]*4 for _ in range(k)];groups=[[] for _ in range(k)]
    for j in sorted(range(len(work)),key=lambda j:(-max(work[j]),-sum(work[j]),min(components[j]))):
        c=min(range(k),key=lambda c:(max((load[c][p]+work[j][p])/total[p] for p in range(4)),sum(load[c]),c))
        groups[c].append(j)
        for p in range(4):load[c][p]+=work[j][p]
    for jobs in groups:jobs.sort(key=lambda j:min(components[j]))
    desc=[]
    for job in components:
        ps=[ops[u]['pipe'] for u in job]
        assert len(job)>=3 and ps[0]==ps[-1]=='PIPE_M' and all(p=='PIPE_V' for p in ps[1:-1])
        assert all(v in succ[u] for u,v in zip(job,job[1:]));desc.append(tuple(d(u) for u in job))
    assert len(set(desc))==1 and desc[0][0]==desc[0][-1]
    a,b=desc[0][0],sum(desc[0][1:-1]);assert b<=2*a
    ahead=1+(b+a-1)//a; seqs=[]
    for jobs in groups:
        nodes=[u for j in jobs for u in components[j]]
        if strategy=='component':seqs.append(nodes);continue
        first=[components[j][0] for j in jobs];last=[components[j][-1] for j in jobs]
        mword=first[:ahead]
        for i,u in enumerate(last):
            mword.append(u)
            if i+ahead<len(first):mword.append(first[i+ahead])
        vword=[u for j in jobs for u in components[j][1:-1]]
        s={u:set(succ[u]) for u in nodes}
        for word in (mword,vword):
            for u,v in zip(word,word[1:]):s[u].add(v)
        ordered=topo(nodes,s);early=dict.fromkeys(nodes,0)
        for u in ordered:
            for v in s[u]:early[v]=max(early[v],early[u]+d(u))
        seqs.append(sorted(nodes,key=lambda u:(early[u],u)))
    mapping={str(u):i for i,u in enumerate(order)}
    plan={'node_to_subgraph':mapping,'core_schedules':[[mapping[str(u)] for u in seq] for seq in seqs]}
    derive_multicore_plan(g,plan)
    return plan,dict(components=len(components),ops=len(ops),a=a,b=b,lookahead=ahead)

if __name__=='__main__':
    g=json.loads((OFF/'data/case_008.json').read_text());p,meta=construct(g)
    raw=(json.dumps(p,separators=(',',':'))+'\n').encode();sha=hashlib.sha256(raw).hexdigest();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert sha=='1935d89ad16a59a52ad62b2e00b4b43f30e783ade40fe481fc6063d905da64ce',(sha,blob)
    assert blob=='9a1fd3849389fb0155d82d02a91d87c1bf967410'
    (ROOT/'source/reconstructed/case008_resource_word.json').write_bytes(raw)
    meta.update(plan_sha256=sha,git_blob=blob,bytes=len(raw),verified_against='pinned manifest and directory blob metadata',reconstruction=True)
    (ROOT/'evidence/plan_reconstruction.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta)
