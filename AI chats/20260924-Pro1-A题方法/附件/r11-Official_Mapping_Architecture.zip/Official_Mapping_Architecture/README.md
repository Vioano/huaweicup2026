# 官方映射结构研究包 / Pro A

本包是研究架构、可证伪任务卡与有界证据，不是最终求解器，也没有部署服务。
术语按本轮用户提供的 Coherent Research Glossary v1；正文中的 Definition Amendment 只是建议，未被自动采用。

## 入口

- `RESEARCH_MEMO.md`：严格七部分研究报告、数学命题、D14/D15反例、局部评估器判断。
- `GOAL_CARDS.md`：七张尚未启动的 Codex /goal 候选卡，含完整边界和拟议预算。
- `EVIDENCE_INDEX.md`：本轮实验身份、证据等级、完整性与缺口。
- `READ_MANIFEST.json`：实际读取的分支、文档及阅读范围。它是读取登记，不代表每份远端文件都被复制进本包。
- `evidence/heads.json`：经已授权 GitHub 连接逐个查询的八个HEAD。不是对八个分支同一原子时刻的快照；后续读取固定这些SHA。
- `MANIFEST.json`：本包所含文件逐项SHA256（不含自身和包外ZIP）。

## 本轮新增验证

5次冻结官方CLI：case008/044固定单核、同一已发布008计划的Q1/Q2/Q3。
24次冻结官方Q2函数：四个无tensor独立操作、固定singleton映射、全部24核内排列。
零E1/E2调用，零GPU，零神经训练，未运行全100例。
这些调用已完成且全量证据已保存；任务卡预算属于未来建议，不是本轮实际调用或新授权。

峰值计划由读到的构造逻辑重建，同时匹配镜像公布的SHA256及Git blob SHA；见 `evidence/plan_reconstruction.json`。
本包附带原官方代码、config和case008/044的原字节，仅这两张正式图；不要将其称为完整100case材料包。

## 零新增评价的完整性核查

在解包目录运行：

```sh
python - <<'PY'
import json, hashlib
from pathlib import Path
root = Path('.')
m = json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
for x in m['files']:
    p = root/x['path']
    assert p.stat().st_size == x['bytes'], x['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == x['sha256'], x['path']
print('verified', len(m['files']), 'files; no evaluator calls')
PY
```

## 另批复跑（需要明确批准新预算，不覆盖现证据）

建立一个新的工作目录，仅复制 `code/` 与 `source/` 到该目录。运行以下四个脚本：

```sh
python -B code/reconstruct_plan.py
python -B code/verify_peak.py
python -B code/quotient_probe.py
python -B code/recover_plan.py
```

前两个评价脚本会拒绝覆盖现存 `evidence/new/peak` 或 `evidence/new/quotient`。每次完整复跑为5次CLI加24次函数E0；前三个正式多核评价直接用同一字节计划。无时间性能发布主张。
`source/official/code`保持原件，import路径由脚本设置；无需安装第三方Python包。当前实测Python3.13.5/Linux x86-64，不冒称用户macOS、Windows或全平台验收。

`recover_plan.py`仅重读上述结果，不新增评价；其恢复的是整数逻辑映射及core_schedules，不恢复原JSON键拼写、mapping插入次序，也不授权生产去重时丢弃这些信息。

## 重要限制

- author reports中的E1/native/E2性能与回归范围没有在此全体重跑。
- 本轮24态是封闭合成域；D15穷尽结论只适用于该域和三个相邻位置交换操作。
- 完整result恢复性在成功执行域成立；失败、超时和未评价方案不得填虚构Makespan。
- 原生内部评分、完整官方JSON、最终solver墙钟是不同口径。
- 本包没有改变任何仓库分支或生产后端。
