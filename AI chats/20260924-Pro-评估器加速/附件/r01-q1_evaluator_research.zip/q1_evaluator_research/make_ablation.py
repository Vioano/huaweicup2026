"""Create an offline, explicitly labelled Python metrics-only ablation.
The immutable downloaded reference remains untouched. No event semantics edited.
"""
from pathlib import Path
import ast,hashlib
root=Path(__file__).parent
source=(root/'reference/scene_a.py').read_bytes()
assert hashlib.sha256(source).hexdigest()=='603807adea832b6514d86f5e79107eafc8386eaacf9ee2c9e3f6fb2db705afc9'
tree=ast.parse(source)
class Quiet(ast.NodeTransformer):
    def visit_Expr(self,node):
        c=node.value
        if isinstance(c,ast.Call) and isinstance(c.func,ast.Attribute) and isinstance(c.func.value,ast.Name) and c.func.value.id=='ddr_contention_log' and c.func.attr=='append':
            return None
        return self.generic_visit(node)
    def visit_FunctionDef(self,node):
        node=self.generic_visit(node)
        if node.name=='evaluate_scene_a':
            for i,s in enumerate(node.body):
                if isinstance(s,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='per_core_timeline' for t in s.targets):
                    node.body=node.body[:i]+ast.parse("return dict(makespan=max(task_end.values(),default=0),op_start=op_start,op_end=op_end,task_start=task_start,task_end=task_end)").body
                    break
        return node
out=ast.fix_missing_locations(Quiet().visit(tree))
(root/'reference/scene_a_quiet.py').write_text('# GENERATED METRICS-ONLY ABLATION, NOT OFFICIAL SOURCE.\n'+ast.unparse(out)+'\n')
