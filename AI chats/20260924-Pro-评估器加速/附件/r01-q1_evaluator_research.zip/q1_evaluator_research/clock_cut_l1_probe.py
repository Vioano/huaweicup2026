"""A capacity-sized L1 clock-cut witness and an UNEXECUTED raw-E0 candidate.
The compiled-state comparison is actually run. The supplied raw graph/plan
have NOT passed frozen Step1--3 here and are labelled accordingly.
"""
import json
from pathlib import Path
from fixtures import make_runtime
from replay_api import pack_tasks,score
from run_tests import compare,CONFIG
from reference.scene_a import evaluate_scene_a
from clock_cut_event_probe import wrong_mutant
ROOT=Path(__file__).parent

def main():
    W=8000;cut_count=828;size=480000;tasks=[]
    for t in [1,2,3]:
        tasks.append(dict(id=t,pred_tasks=[],ops=[dict(id=1,pipe=0,duration=W,ddr=True,preds=[]),
            dict(id=2,pipe=2,duration=1000 if t==1 else 1,preds=[1])]))
    ops=[dict(id=i,pipe=2,duration=1,preds=[i-1] if i>1 else []) for i in range(1,cut_count+1)]
    ops.append(dict(id=cut_count+1,op='COPY_OUT',pipe=1,duration=W,ddr=True,preds=[cut_count]))
    tasks.append(dict(id=4,pred_tasks=[],ops=ops));spec=dict(schema='synthetic-precompiled-tasks-v1',bandwidth=60,tasks=tasks)
    orders=[[1],[2],[3],[4]];rt=make_runtime(spec)
    for task in rt.tasks.values():
        for tensor in task['tensor_by_id'].values():
            if tensor['pos']=='UB':tensor['pos']='L1'
    comp=pack_tasks(rt.tasks,rt,60);ref=evaluate_scene_a(rt,None,{'orders':orders},**CONFIG)
    native=score(comp,orders,audit=True);compare(comp,ref,native)
    coal=score(comp,orders,project_once=True);compare(comp,ref,coal)
    bad=wrong_mutant()(rt,None,{'orders':orders},**CONFIG)
    assert ref['makespan']==32725 and bad['makespan']==32724
    row=dict(scope='ACTUALLY RUN compiled-state witness; raw graph candidate UNEXECUTED',
        ddr_duration=W,tensor_bytes=size,position='L1',official_L1_capacity=CONFIG['capacity']['L1'],
        clock_cuts=cut_count,compiled_ops=len(comp.op_keys),reference_makespan=ref['makespan'],
        native_makespan=native['makespan'],coalesced_makespan=coal['makespan'],wrong_compressed_makespan=bad['makespan'])
    (ROOT/'results/clock_cut_l1.json').write_text(json.dumps(row,indent=2))
    (ROOT/'inputs/clock_cut_l1_compiled.json').write_text(json.dumps(dict(spec=spec,orders=orders,config=CONFIG,
        fixture_adjustment='change every UB tensor in make_runtime output to L1 before packing'),indent=2))
    # Supply a concrete raw candidate for independent E0 validation; do NOT assert
    # that its local prepared output has already been checked against the fixture.
    graph=dict(ops=[],tensors=[],edges=[]);mapping={}
    def edge(a,b):graph['edges'].append(dict(source=a,target=b))
    for t in [1,2,3]:
        copy=10*t;compute=10*t+1;ddr=100000+2*t;local=ddr+1
        graph['ops'].extend([dict(id=copy,op='COPY_IN',pipe='PIPE_MTE2',cycles=W),
            dict(id=compute,op='COMPUTE',pipe='PIPE_M',cycles=1000 if t==1 else 1)])
        graph['tensors'].extend([dict(id=ddr,pos='DDR',size=size),dict(id=local,pos='L1',size=size)])
        edge(ddr,copy);edge(copy,local);edge(local,compute);mapping[str(compute)]=t
    chain=list(range(1000,1000+cut_count))
    for i,op in enumerate(chain):
        graph['ops'].append(dict(id=op,op='COMPUTE',pipe='PIPE_M',cycles=1));mapping[str(op)]=4
        if i:edge(chain[i-1],op)
    local=200000;ddr=200001;copy=90000
    graph['ops'].append(dict(id=copy,op='COPY_OUT',pipe='PIPE_MTE3',cycles=W))
    graph['tensors'].extend([dict(id=local,pos='L1',size=size),dict(id=ddr,pos='DDR',size=size)])
    edge(chain[-1],local);edge(local,copy);edge(copy,ddr)
    (ROOT/'inputs/UNEXECUTED_clock_cut_raw_graph.json').write_text(json.dumps(graph,indent=2))
    (ROOT/'inputs/UNEXECUTED_clock_cut_raw_plan.json').write_text(json.dumps(dict(node_to_subgraph=mapping,core_schedules=orders),indent=2))
    print(json.dumps(row,indent=2))
if __name__=='__main__':main()
