"""Bounded spawn/IPC test, synthetic prepared tasks, NOT the official E1 pool.
One in-flight request per worker; all 64 input candidates are distinct.
Includes cold spawn/preparation, steady replay/IPC, and shutdown separately.
"""
from __future__ import annotations
import argparse,json,multiprocessing as mp,os,resource,time,threading
from multiprocessing.connection import wait
from pathlib import Path
import psutil
from fixtures import make_runtime,random_orders
from replay_api import pack_tasks,score
from reference.scene_a import evaluate_scene_a
from run_tests import CONFIG
ROOT=Path(__file__).parent

def worker(conn,spec,engine):
    try:
        c=time.process_time();w=time.perf_counter();rt=make_runtime(spec)
        comp=pack_tasks(rt.tasks,rt,60) if engine=='native_coalesced' else None
        def run(orders):
            if comp is None:return evaluate_scene_a(rt,None,{'orders':orders},**CONFIG)['makespan']
            return score(comp,orders,project_once=True)['makespan']
        # Distinct warmup, preparation cost charged to cold initialization.
        run(random_orders(spec,18888888,4))
        conn.send(dict(ready=True,pid=os.getpid(),init_wall=time.perf_counter()-w,
            init_cpu=time.process_time()-c,compiled_bytes=comp.static_bytes if comp else None))
        while True:
            req=conn.recv()
            if req is None:break
            idx,orders=req;c=time.process_time();w=time.perf_counter();m=run(orders)
            conn.send(dict(index=idx,makespan=m,eval_wall=time.perf_counter()-w,
                eval_cpu=time.process_time()-c,peak_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024))
    finally:conn.close()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--engine',choices=['reference_global_full','native_coalesced'],required=True)
    ap.add_argument('--workers',type=int,choices=[1,2],required=True);a=ap.parse_args()
    cpus=sorted(os.sched_getaffinity(0))[:a.workers];os.sched_setaffinity(0,set(cpus))
    data=json.loads((ROOT/'inputs/mixed.json').read_text());plans=data['plans'];ctx=mp.get_context('spawn')
    peak=dict(parent=0,children_sum=0,tree_sum=0);stop=threading.Event();proc=psutil.Process()
    def sample():
        while not stop.is_set():
            try:
                parent=proc.memory_info().rss;children=0
                for child in proc.children(recursive=True):
                    try:children+=child.memory_info().rss
                    except psutil.Error:pass
                peak['parent']=max(peak['parent'],parent);peak['children_sum']=max(peak['children_sum'],children)
                peak['tree_sum']=max(peak['tree_sum'],parent+children)
            except psutil.Error:pass
            stop.wait(.002)
    sampler=threading.Thread(target=sample,daemon=True);sampler.start()
    slots=[];init=[];rows=[];start=time.perf_counter();parent_cpu=time.process_time()
    try:
        for i in range(a.workers):
            parent,child=ctx.Pipe();p=ctx.Process(target=worker,args=(child,data['spec'],a.engine));p.start();child.close();slots.append((p,parent))
        for p,conn in slots:
            if not conn.poll(30):raise TimeoutError('startup')
            init.append(conn.recv())
        init_elapsed=time.perf_counter()-start;batch_start=time.perf_counter();next_index=0;active={};worker_peaks={i:0 for i in range(a.workers)}
        for i,(_,conn) in enumerate(slots):
            conn.send((next_index,plans[next_index]['orders']));active[conn]=(i,next_index);next_index+=1
        while active:
            ready=wait(list(active),timeout=30)
            if not ready:raise TimeoutError('candidate deadline')
            for conn in ready:
                i,expected=active.pop(conn);row=conn.recv();assert row['index']==expected;rows.append(dict(worker=i,**row));worker_peaks[i]=max(worker_peaks[i],row['peak_rss'])
                if next_index<len(plans):
                    conn.send((next_index,plans[next_index]['orders']));active[conn]=(i,next_index);next_index+=1
        batch_elapsed=time.perf_counter()-batch_start;shutdown=time.perf_counter()
        for p,conn in slots:conn.send(None)
        for p,conn in slots:p.join(10);conn.close();assert not p.is_alive()
        shutdown_elapsed=time.perf_counter()-shutdown
    finally:
        for p,conn in slots:
            if p.is_alive():p.terminate();p.join()
            conn.close()
        stop.set();sampler.join()
    elapsed=time.perf_counter()-start
    out=dict(scope='synthetic mixed compiled tasks, not official E1; single run, no confidence interval',
        engine=a.engine,workers=a.workers,affinity=cpus,candidates=64,
        initialization_wall=init_elapsed,batch_replay_ipc_wall=batch_elapsed,shutdown_wall=shutdown_elapsed,cold_total_wall=elapsed,
        parent_cpu=time.process_time()-parent_cpu,worker_prepare_cpu=sum(x['init_cpu'] for x in init),
        worker_eval_cpu=sum(x['eval_cpu'] for x in rows),
        reaped_children_cpu=resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime,
        worker_peak_rss=worker_peaks,sampled_rss=peak,
        memory_caveat='2ms sampled simultaneous RSS SUM incl parent/children/tracker; shared pages double-counted, not physical/PSS/cgroup peak; imports included in child CPU total',
        initialization=init,rows=sorted(rows,key=lambda x:x['index']))
    (ROOT/'results'/f'resource_{a.engine}_{a.workers}.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({k:v for k,v in out.items() if k not in ['rows','initialization']},indent=2))
if __name__=='__main__':main()
