from __future__ import annotations
import json,hashlib,traceback,sys,time
from pathlib import Path
import numpy as np
from replay_api import *
from fixtures import *
from reference.scene_a import evaluate_scene_a
from reference.scene_a_quiet import evaluate_scene_a as quiet
ROOT=Path(__file__).parent
CONFIG={'bandwidth':60,'capacity':{'L1':524288,'UB':131072},'cross_core_wait':1000,'same_core_wait':100}

def compare(comp,r,a):
    assert type(r['makespan']) is int and type(a['makespan']) is int and r['makespan']==a['makespan']
    for core in r['per_core_timeline']:
        for e in core['ops']:
            k=comp.index[e['task_id'],e['op_id']]
            assert int(a['op_start'][k])==e['start'] and int(a['op_end'][k])==e['end'],(e,k,a['op_start'][k],a['op_end'][k])
        for e in core['tasks']:
            t=comp.task_ids.index(e['task_id'])
            assert int(a['task_start'][t])==e['start'] and int(a['task_end'][t])==e['end']
    if len(a['audit']):
        log=[]
        for e in r['ddr_contention_log']:
            log.extend([e['time'],comp.index[e['issued']['task_id'],e['issued']['op_id']],e['active_count']])
            for p in e['projected_ends']:log.extend([comp.index[p['task_id'],p['op_id']],p['end']])
        assert a['audit'].tolist()==log

def one(spec,orders,same=100,cross=1000,audit=True):
    rt=make_runtime(spec); comp=pack_tasks(rt.tasks,rt,60)
    cfg=dict(CONFIG,same_core_wait=same,cross_core_wait=cross)
    r=evaluate_scene_a(rt,None,{'orders':orders},**cfg)
    a=score(comp,orders,same_wait=same,cross_wait=cross,audit=audit);compare(comp,r,a)
    b=score(comp,orders,same_wait=same,cross_wait=cross,project_once=True);compare(comp,r,b)
    q=quiet(rt,None,{'orders':orders},**cfg); assert q['makespan']==r['makespan']
    for key,idx in comp.index.items():assert q['op_start'][key]==a['op_start'][idx] and q['op_end'][key]==a['op_end'][idx]
    return dict(makespan=a['makespan'],ops=len(comp.op_keys),events=int(a['stats'][1]),
        projections=int(a['stats'][3]),coalesced_projections=int(b['stats'][3]),max_active_ddr=int(a['stats'][6]))

def micro_inputs():
    # Minimal compiled FIFO blocking: this is not asserted to be raw Step3 output.
    fifo=dict(schema='synthetic-precompiled-tasks-v1',tasks=[dict(id=7,pred_tasks=[],ops=[
        dict(id=1,pipe=2,duration=100,preds=[]),dict(id=2,pipe=3,duration=1,preds=[1]),dict(id=3,pipe=3,duration=100,preds=[])])])
    yield 'fifo_head_blocking',fifo,[[7]],0,0
    tie=dict(schema='synthetic-precompiled-tasks-v1',tasks=[dict(id=i,pred_tasks=[],ops=[dict(id=1,pipe=0,duration=1,ddr=True,preds=[])]) for i in [20,10]])
    yield 'simultaneous_ddr',tie,[[20],[10]],0,0
    overlap=dict(schema='synthetic-precompiled-tasks-v1',tasks=[dict(id=8,pred_tasks=[],ops=[
        dict(id=1,pipe=0,duration=10,ddr=True,preds=[]),dict(id=2,pipe=2,duration=100,preds=[])])])
    yield 'copy_compute_overlap',overlap,[[8]],0,0
    internal=dict(schema='synthetic-precompiled-tasks-v1',tasks=[dict(id=3,pred_tasks=[],ops=[
        dict(id=1,pipe=0,duration=7,internal_copy=True,preds=[]),dict(id=2,pipe=1,duration=7,internal_copy=True,preds=[])])])
    yield 'l1_ub_not_ddr',internal,[[3]],0,0
    zero=dict(schema='synthetic-precompiled-tasks-v1',tasks=[dict(id=9,pred_tasks=[],ops=[
        dict(id=1,pipe=0,duration=0,ddr=True,size=0,preds=[]),dict(id=2,pipe=3,duration=0,preds=[1])])])
    yield 'zero_size_min_one',zero,[[9]],0,0

def main():
    rows=[]; fixtures_path=ROOT/'inputs/micro_and_random.jsonl'
    with fixtures_path.open('w') as fp:
        for name,s,orders,sw,cw in micro_inputs():
            result=one(s,orders,sw,cw);rows.append(dict(name=name,**result))
            fp.write(json.dumps(dict(name=name,spec=s,orders=orders,same_wait=sw,cross_wait=cw))+'\n')
        for seed in range(120):
            s=random_spec(240000+seed,tasks=2+seed%7,ops=4+seed%27,ddr_rate=(seed%5)/4)
            for k in range(3):
                orders=random_orders(s,700000+seed*3+k,cores=1+(seed+k)%8)
                sw=[0,1,100][k];cw=[0,7,1000][k]
                result=one(s,orders,sw,cw)
                rows.append(dict(name=f'random-{seed}-{k}',**result))
                fp.write(json.dumps(dict(name=rows[-1]['name'],spec=s,orders=orders,same_wait=sw,cross_wait=cw))+'\n')
    # Mixed lengths: cycle added by one non-singleton core MUST be detected.
    s=dict(tasks=[dict(id=t,pred_tasks=pred,ops=[dict(id=1,pipe=2,duration=1,preds=[])]) for t,pred in [(1,[]),(2,[1]),(3,[2]),(4,[])]])
    rt=make_runtime(s);comp=pack_tasks(rt.tasks,rt,60)
    try:score(comp,[[3,1],[2],[4]])
    except CandidateError:cycle=True
    else:raise AssertionError('mixed-length union cycle not rejected')
    guards=[]
    for kwargs in [dict(same_wait=.5),dict(cross_wait=float('nan'))]:
        try:score(comp,[[1,2,3,4]],**kwargs)
        except Unsupported:guards.append(str(kwargs))
        else:raise AssertionError('numeric guard missing')
    summary=dict(scope='synthetic compiled tasks; NO official Step1--3 or formal graph run',
        fixtures=len(rows),variants=['unchanged_scene_a','quiet_python','native_full_projection','native_coalesced'],
        compared='all operation/task starts and ends; every DDR issue projection for full native; integer Makespan',
        mismatches=0,mixed_length_cycle_rejected=cycle,unsupported_guards=guards,rows=rows)
    (ROOT/'results/differential.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
    print('micro rows:',rows[:5])
if __name__=='__main__':main()
