"""Bounded benchmark against READ/BYTE-VERIFIED _scene_a, not end-to-end E1/E0.
No local Step1--3, raw-plan validation, pickle restoration, pool IPC or file I/O
is charged to either replay path. Candidate check/buffer/native-call ARE timed.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,os,platform,resource,subprocess,sys,time,statistics,math,itertools,random
from pathlib import Path
from fixtures import *
from replay_api import *
from run_tests import compare,CONFIG
from reference.scene_a import evaluate_scene_a
from reference.scene_a_quiet import evaluate_scene_a as quiet
ROOT=Path(__file__).parent
FAMILIES={'compute':(16,128,0.,.04),'mixed':(16,128,.25,.04),'ddr_heavy':(16,64,.85,.04),'burst':(16,128,1.,0.)}

def load_or_make(name):
    path=ROOT/'inputs'/f'{name}.json'
    if path.exists():return json.loads(path.read_text())
    i=list(FAMILIES).index(name); t,o,d,e=FAMILIES[name]
    spec=random_spec(20260924+i,t,o,d,e)
    if name=='burst':
        for task in spec['tasks']:
            for op in task['ops']:op['duration']=1;op['preds']=[]
    plans=[];seen=set();k=0
    while len(plans)<64:
        orders=random_orders(spec,920000+i*10000+k,4);k+=1
        ident=hashlib.sha256(json.dumps(orders,separators=(',',':')).encode()).hexdigest()
        if ident not in seen:seen.add(ident);plans.append(dict(id=ident,orders=orders))
    data=dict(scope='synthetic compiled tasks, not official graph',family=name,spec=spec,plans=plans)
    path.write_text(json.dumps(data,indent=2));return data

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--family',choices=FAMILIES,required=True);ap.add_argument('--repeats',type=int,default=3);args=ap.parse_args()
    if hasattr(os,'sched_getaffinity'):
        old=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,{old[0]})
    data=load_or_make(args.family);spec=data['spec'];plans=data['plans']
    a=time.perf_counter();rt=make_runtime(spec);fixture_prepare=time.perf_counter()-a
    a=time.perf_counter();comp=pack_tasks(rt.tasks,rt,60);pack=time.perf_counter()-a
    engines={
      'reference_global_full':lambda orders:evaluate_scene_a(rt,None,{'orders':orders},**CONFIG),
      'python_quiet':lambda orders:quiet(rt,None,{'orders':orders},**CONFIG),
      'native_exact_replay':lambda orders:score(comp,orders),
      'native_coalesced':lambda orders:score(comp,orders,project_once=True)}
    # 1 unmeasured warmup per engine on a DIFFERENT generated scheduling candidate.
    warm=random_orders(spec,18888888,4)
    for fn in engines.values():fn(warm)
    rows=[];pool_records=[];names=list(engines);truth={};validation_count=0
    permutations=list(itertools.permutations(names));random.Random(900924).shuffle(permutations)
    for rep in range(args.repeats):
        for k,plan in enumerate(plans):
            outputs={}
            rotated=permutations[(rep*len(plans)+k)%len(permutations)]
            for name in rotated:
                w=time.perf_counter_ns();c=time.process_time_ns();result=engines[name](plan['orders']);cpu=(time.process_time_ns()-c)/1e9;wall=(time.perf_counter_ns()-w)/1e9
                outputs[name]=result
                rows.append(dict(family=args.family,rep=rep,candidate=k,candidate_hash=plan['id'],engine=name,wall_s=wall,cpu_s=cpu,makespan=result['makespan']))
            ref=outputs['reference_global_full'];truth[k]=ref['makespan']
            for name in ['native_exact_replay','native_coalesced']:compare(comp,ref,outputs[name]);validation_count+=1
            q=outputs['python_quiet'];assert q['makespan']==ref['makespan']
            for key,idx in comp.index.items():assert q['op_start'][key]==outputs['native_exact_replay']['op_start'][idx] and q['op_end'][key]==outputs['native_exact_replay']['op_end'][idx]
        print(args.family,'repeat',rep,'complete',flush=True)
    for rep in range(args.repeats):
        times={name:sum(r['wall_s'] for r in rows if r['rep']==rep and r['engine']==name) for name in names}
        cpus={name:sum(r['cpu_s'] for r in rows if r['rep']==rep and r['engine']==name) for name in names}
        pool_records.append(dict(rep=rep,wall_s=times,cpu_s=cpus,speedup_vs_full={name:times[names[0]]/times[name] for name in names}))
    filename=ROOT/'results'/f'{args.family}.csv'
    with filename.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    best=min(truth.values());good={i for i,m in truth.items() if m<=best*1.01}
    selected=set(sorted(truth,key=lambda i:(truth[i],plans[i]['id']))[:8])
    summary=dict(family=args.family,scope='prepared global replay only; NOT new E1 end-to-end',
      timing_order='all 24 engine permutations repeated 8 times for three rounds',
      candidates=64,unique_candidates=len(set(p['id'] for p in plans)),repeats=args.repeats,ops=len(comp.op_keys),
      fixture_prepare_s=fixture_prepare,pack_once_s=pack,compiled_array_bytes=comp.static_bytes,full_timing_comparisons=validation_count,
      numeric_median_relative_error=0,numeric_p95_relative_error=0,shortlist_regret=0,pool_retained=True,
      good_candidates=len(good),good_outside_top8=len(good-selected),excess_missed_good=0,precision_fallbacks=0,
      official_fallback_cost_measured=False,
      pool_records=pool_records,median_pool_wall_s={name:statistics.median(p['wall_s'][name] for p in pool_records) for name in names},
      geometric_speedup={name:math.exp(statistics.mean(math.log(p['speedup_vs_full'][name]) for p in pool_records)) for name in names},
      process_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
      rss_caveat='single mixed benchmark process high-water mark, not individual engine RSS',
      environment={'python':sys.version,'platform':platform.platform(),'machine':platform.machine(),'affinity':sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None})
    (ROOT/'results'/f'{args.family}.summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ('pool_records','environment')},indent=2))
if __name__=='__main__':main()
