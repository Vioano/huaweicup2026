"""UNEXECUTED HERE: bounded integration driver for a user-supplied frozen checkout.
Only syntax-checked in this delivery: full official sources/graphs were not
mounted locally. This file does NOT claim the synthetic fixtures are official.
Run on at most three distinct schedules with the SAME ordered raw partition.
The baseline is the NEW E1 end-to-end path, not the global-only fixture adapter.
"""
from __future__ import annotations
import argparse,hashlib,json,pickle,subprocess,sys,time
from pathlib import Path
from replay_api import pack_tasks,score
from run_tests import compare

COMMIT='5bfe53a29c1ba05167239f51ea937e602f7f85b4'
CODE_HASH='de11a83db8d7c47ed328b15a7df71d613a833b16cd23ee9fe877999578a1ace0'

def fingerprint(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def strict_equal(a,b):
    assert type(a) is type(b),(type(a),type(b))
    if isinstance(a,dict):
        assert set(a)==set(b)
        for k in a:strict_equal(a[k],b[k])
    elif isinstance(a,(tuple,list)):
        assert len(a)==len(b)
        for x,y in zip(a,b):strict_equal(x,y)
    elif isinstance(a,float):
        assert a.hex()==b.hex()
    else:assert a==b

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True,type=Path)
    p.add_argument('--graph',required=True,type=Path);p.add_argument('--plans',nargs='+',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path);a=p.parse_args()
    if not 1<=len(a.plans)<=3:raise ValueError('bounded probe accepts 1..3 distinct plans only')
    if a.output.exists():raise FileExistsError(a.output)
    head=subprocess.check_output(['git','-C',str(a.repo),'rev-parse','HEAD'],text=True).strip()
    if head!=COMMIT:raise RuntimeError('use an independent worktree at the frozen NEW E1 commit')
    dirty=subprocess.check_output(['git','-C',str(a.repo),'status','--porcelain','--untracked-files=no'],text=True)
    if dirty.strip():raise RuntimeError('tracked checkout has modifications; refuse this benchmark')
    sys.path.insert(0,str(a.repo.resolve()))
    from src.eval_exact.batch import P1Evaluator,read_config
    from src.eval_exact._official import load_problem1_bundle,compute_official_code_hash
    assert compute_official_code_hash()==CODE_HASH
    graph=json.loads(a.graph.read_text());plans=[json.loads(x.read_text()) for x in a.plans]
    raw=[pickle.dumps(x['node_to_subgraph'],protocol=5) for x in plans]
    if any(x!=raw[0] for x in raw):raise ValueError('this bounded probe is fixed-partition only')
    ids=[hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest() for x in plans]
    if len(set(ids))!=len(ids):raise ValueError('plans must be distinct')
    config=read_config(a.repo/'data/raw/a/official/data/config.txt')
    start=time.perf_counter();engine=P1Evaluator(graph);e1_init=time.perf_counter()-start
    start=time.perf_counter();oracle,_=load_problem1_bundle('_q1_consultation_oracle');e0_init=time.perf_counter()-start
    rows=[];truth=[];e1_values=[]
    for i,plan in enumerate(plans):
        start=time.perf_counter();cpu=time.process_time();r0=oracle.evaluate_scene_a(graph,plan,**config)
        e0_cpu=time.process_time()-cpu;e0_wall=time.perf_counter()-start
        start=time.perf_counter();cpu=time.process_time();r1=engine.evaluate(plan,**config)
        e1_cpu=time.process_time()-cpu;e1_wall=time.perf_counter()-start
        strict_equal(r0,r1);truth.append(r0);e1_values.append(r1)
        rows.append(dict(candidate=i,plan_hash=ids[i],e0_wall=e0_wall,e0_cpu=e0_cpu,e1_wall=e1_wall,e1_cpu=e1_cpu))
    # This extraction currently calls the existing private cache builder once.
    # It intentionally does not pretend to implement a production prepare API.
    start=time.perf_counter();cpu=time.process_time()
    tasks,traffic,movement,view=engine._build_tasks(engine._graph,plans[0],config['bandwidth'],config['capacity'])
    compiled=pack_tasks(tasks,engine._runtime,config['bandwidth'])
    prepare_wall=time.perf_counter()-start;prepare_cpu=time.process_time()-cpu
    for i,plan in enumerate(plans):
        start=time.perf_counter();cpu=time.process_time()
        value=score(compiled,plan['core_schedules'],same_wait=config['same_core_wait'],cross_wait=config['cross_core_wait'],project_once=True)
        rows[i].update(native_wall=time.perf_counter()-start,native_cpu=time.process_time()-cpu)
        compare(compiled,truth[i],value)
        debug=score(compiled,plan['core_schedules'],same_wait=config['same_core_wait'],cross_wait=config['cross_core_wait'],audit=True)
        compare(compiled,truth[i],debug)
    # Sunk preparation above is charged explicitly, not silently dropped.
    # A real cold-native path must separately measure official local compilation.
    report=dict(scope='LIMITED fixed-partition integration, not release or independent quality test',
        commit=head,official_code_hash=CODE_HASH,graph_sha256=fingerprint(a.graph),
        graph=str(a.graph),plans=[str(x) for x in a.plans],config=config,
        e1_init_wall=e1_init,e0_init_wall=e0_init,
        extraction_and_pack_wall=prepare_wall,extraction_and_pack_cpu=prepare_cpu,
        cold_native_compilation_measured=False,
        caveat='Existing E1 was evaluated before extracting its prepared tasks. Native timing is hot prepared replay; the extraction+pack cost is separate and does not include cold local compilation.',
        compiled_array_bytes=compiled.static_bytes,rows=rows)
    a.output.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
