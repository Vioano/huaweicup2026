"""Explicitly synthetic COMPILED-TASK fixtures, not official input graphs.

The original Step1--3 compiler is NOT executed here. Dataflow, memory-reuse and
FIFO arcs are supplied as already-compiled input. Helpers below follow the read
schedule_step3.py definitions. This does not test the original spill compiler.
"""
from __future__ import annotations
from types import SimpleNamespace
import math, random
from collections import defaultdict
from replay_api import PIPES

class SceneAEvaluationError(RuntimeError):pass

def op_pipe(op):return op['pipe']
def _op_duration(op, in_tids, out_tids, tensor_by_id, bandwidth):
    op_type = op['op']
    if op_type in ('COPY_IN', 'COPY_OUT'):
        tids = out_tids[op['id']] if op_type == 'COPY_IN' else in_tids[op['id']]
        sizes = [tensor_by_id[tid]['size'] for tid in tids if tid in tensor_by_id]
        if sizes:
            return max(1, math.ceil(sum(sizes) / bandwidth))
    return max(1, op.get('cycles', 1))

def _uses_ddr_bandwidth(op, in_tids, out_tids, tensor_by_id):
    if op['op'] not in ('COPY_IN', 'COPY_OUT'):
        return False
    tids = in_tids[op['id']] + out_tids[op['id']]
    return any(tid in tensor_by_id and tensor_by_id[tid].get('pos') == 'DDR' for tid in tids)

def make_runtime(spec):
    tasks={}; bw=spec.get('bandwidth',60)
    for rec in spec['tasks']:
        t=rec['id']; seq=[o['id'] for o in rec['ops']]; ops={};inputs={};outputs={};tensors={}
        preds={o['id']:set(o.get('preds',[])) for o in rec['ops']}; succs={o:set() for o in seq}
        for o in seq:
            for p in preds[o]:succs[p].add(o)
        pipes={p:[] for p in PIPES}
        for k,o in enumerate(rec['ops']):
            oid=o['id'];p=PIPES[o['pipe']];pipes[p].append(oid)
            copy=o.get('ddr',False) or o.get('internal_copy',False)
            opname=o.get('op','COPY_IN' if copy else 'COMPUTE')
            ops[oid]={'id':oid,'op':opname,'pipe':p,'cycles':o['duration']}
            inputs[oid]=[];outputs[oid]=[]
            if copy:
                it=10**12+2*k;ot=it+1;size=o.get('size',o['duration']*bw)
                tensors[it]={'id':it,'size':size,'pos':'DDR' if o.get('ddr') and opname=='COPY_IN' else 'L1'}
                tensors[ot]={'id':ot,'size':size,'pos':'DDR' if o.get('ddr') and opname=='COPY_OUT' else 'UB'}
                inputs[oid]=[it];outputs[oid]=[ot]
        if 'pipe_orders' in rec:
            pipes={p:list(rec['pipe_orders'].get(p,pipes[p])) for p in PIPES}
        tasks[t]={'task_id':t,'core_id':0,'pred_tasks':list(rec.get('pred_tasks',[])),
            'seq':seq,'op_by_id':ops,'seq_pos':{o:i for i,o in enumerate(seq)},'pipe_ops':pipes,
            'op_preds':preds,'op_succs':succs,'in_tids':inputs,'out_tids':outputs,'tensor_by_id':tensors,
            # Synthetic metadata is deliberately NOT claimed to be Step3 results.
            'step3':{'makespan':-1,'memory_peak':{'L1':0,'UB':0},'memory_dependencies':[]}}
    pairs=[(p,t) for t,task in tasks.items() for p in task['pred_tasks']]
    def build(graph,plan,bandwidth,capacity):
        orders=plan['orders']
        for c,row in enumerate(orders):
            for t in row:tasks[t]['core_id']=c
        return tasks,0,{},dict(num_cores=len(orders),core_orders=dict(enumerate(orders)),dependency_pairs=pairs)
    def validate(bandwidth,capacity,max_iter,**waits):
        if bandwidth<=0 or max_iter<1 or any(v<0 for v in waits.values()):raise ValueError('fixture parameters')
    return SimpleNamespace(_build_scene_a_tasks=build,validate_parameters=validate,PIPES=PIPES,PIPE_SLOTS=1,
        op_pipe=op_pipe,_op_duration=_op_duration,_uses_ddr_bandwidth=_uses_ddr_bandwidth,
        SceneAEvaluationError=SceneAEvaluationError,tasks=tasks)

def random_spec(seed,tasks=12,ops=64,ddr_rate=.2,task_edge_rate=.15):
    r=random.Random(seed); records=[]
    tids=r.sample(range(10,100000),tasks)
    for i,t in enumerate(tids):
        ids=r.sample(range(1,100000),ops); rows=[]
        for j,oid in enumerate(ids):
            ps=r.sample(ids[max(0,j-8):j],min(j,r.randrange(3))) if j else []
            rows.append(dict(id=oid,pipe=r.randrange(4),duration=r.randrange(1,80),
                ddr=r.random()<ddr_rate,preds=ps))
        records.append(dict(id=t,pred_tasks=[p for p in tids[:i] if r.random()<task_edge_rate],ops=rows))
    return dict(schema='synthetic-precompiled-tasks-v1',seed=seed,bandwidth=60,tasks=records)

def random_orders(spec,seed,cores=4):
    r=random.Random(seed); pred={t['id']:set(t.get('pred_tasks',[])) for t in spec['tasks']}; done=set();orders=[[] for _ in range(cores)]
    while pred:
        ready=[t for t,ps in pred.items() if ps<=done]
        if not ready:raise ValueError('fixture task DAG')
        t=r.choice(ready); orders[r.randrange(cores)].append(t);done.add(t);del pred[t]
    return orders
