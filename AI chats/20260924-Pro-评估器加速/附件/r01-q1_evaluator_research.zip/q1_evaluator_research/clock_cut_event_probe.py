"""Actual compiled-state counterexample to deleting non-DDR event clock cuts.
Runs the byte-verified new-E1 global simulator, native replay, and an explicitly
WRONG research mutant. Official raw graph/Step1--3 are still not executed.
"""
import ast,json
from pathlib import Path
from fixtures import make_runtime
from replay_api import pack_tasks,score
from run_tests import compare,CONFIG
from reference.scene_a import evaluate_scene_a
ROOT=Path(__file__).parent

def wrong_mutant():
    tree=ast.parse((ROOT/'reference/scene_a.py').read_text())
    class Change(ast.NodeTransformer):
        def visit_FunctionDef(self,node):
            self.generic_visit(node)
            if node.name=='retire':
                replacement=ast.parse('''if any(item in ddr_remaining_work and end <= now for running in executors.values() for item,end in running):
    advance_ddr_work(now)
''').body[0]
                for i,stmt in enumerate(node.body):
                    if isinstance(stmt,ast.Expr) and isinstance(stmt.value,ast.Call) and isinstance(stmt.value.func,ast.Name) and stmt.value.func.id=='advance_ddr_work':
                        node.body[i]=replacement;break
                else:raise AssertionError('clock cut call not found')
            return node
    tree=ast.fix_missing_locations(Change().visit(tree));text=ast.unparse(tree)+'\n'
    (ROOT/'reference/wrong_skip_clock_cuts.py').write_text(text)
    env={};exec(compile(tree,'wrong_skip_clock_cuts.py','exec'),env);return env['evaluate_scene_a']

def main():
    W=2**23;tasks=[]
    for t in [1,2,3]:
        ops=[dict(id=1,pipe=0,duration=W,ddr=True,preds=[])]
        if t==1:ops.append(dict(id=2,pipe=2,duration=100,preds=[1]))
        tasks.append(dict(id=t,pred_tasks=[],ops=ops))
    tasks.append(dict(id=4,pred_tasks=[],ops=[
        dict(id=1,pipe=2,duration=1,preds=[]),dict(id=2,pipe=2,duration=1,preds=[1]),
        dict(id=3,pipe=2,duration=1,preds=[2]),dict(id=4,pipe=0,duration=W,ddr=True,preds=[3])]))
    spec=dict(schema='synthetic-precompiled-tasks-v1',bandwidth=60,tasks=tasks);orders=[[1],[2],[3],[4]]
    rt=make_runtime(spec);comp=pack_tasks(rt.tasks,rt,60)
    ref=evaluate_scene_a(rt,None,{'orders':orders},**CONFIG)
    nat=score(comp,orders,audit=True);compare(comp,ref,nat)
    coal=score(comp,orders,project_once=True);compare(comp,ref,coal)
    bad=wrong_mutant()(rt,None,{'orders':orders},**CONFIG)
    def ends(r):return {str((e['task_id'],e['op_id'])):e['end'] for c in r['per_core_timeline'] for e in c['ops']}
    row=dict(scope='synthetic COMPILED-state execution, not raw E0 graph',
        reference_makespan=ref['makespan'],native_makespan=nat['makespan'],coalesced_makespan=coal['makespan'],
        wrong_compressed_makespan=bad['makespan'],reference_op_ends=ends(ref),wrong_op_ends=ends(bad),
        reference_ddr_log=ref['ddr_contention_log'],wrong_ddr_log=bad['ddr_contention_log'])
    assert row['reference_makespan']==33554532 and row['wrong_compressed_makespan']==33554531
    (ROOT/'inputs/clock_cut_event.json').write_text(json.dumps(dict(spec=spec,orders=orders,config=CONFIG),indent=2))
    (ROOT/'results/clock_cut_event.json').write_text(json.dumps(row,indent=2))
    print(json.dumps({k:v for k,v in row.items() if 'ddr_log' not in k},indent=2))
if __name__=='__main__':main()
