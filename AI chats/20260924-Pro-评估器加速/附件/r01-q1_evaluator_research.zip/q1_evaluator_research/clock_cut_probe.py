"""Binary64 DDR clock-cut counterexample; NOT a raw official-graph test."""
import json, math
from pathlib import Path

def main():
    work=float(2**23)
    split=work
    intermediates=[]
    for _ in range(3):
        split=max(0.,split-1/3)
        intermediates.append(split.hex())
    batched=max(0.,work-3/3)
    # At now=3 a fourth, longer transfer enters. It is sorted AFTER these
    # three transfers, so their earliest projected end has active_count=4.
    project=lambda remaining: int(math.ceil(3.+remaining*4-1e-9))
    row=dict(scope='helper arithmetic, not E0 input graph',initial_work=int(work),
        initially_active=3,clock_cuts=[1,2,3],fourth_transfer_arrival=3,
        split_remaining_hex=split.hex(),batched_remaining_hex=batched.hex(),
        split_intermediates_hex=intermediates,
        projected_first_group_end_split=project(split),projected_first_group_end_batched=project(batched))
    assert row['projected_first_group_end_split']==33554432
    assert row['projected_first_group_end_batched']==33554431
    p=Path(__file__).parent/'results/clock_cut.json';p.write_text(json.dumps(row,indent=2))
    print(json.dumps(row,indent=2))
if __name__=='__main__':main()
