"""Exact graph-longest-path reference for the strictly NO-DDR compiled domain.
Not a native accelerator, and not a model for graphs with any shared-DDR COPY.
"""
from collections import deque
import json
from pathlib import Path
from replay_api import Unsupported,validate_orders,pack_tasks,score
from fixtures import random_spec,random_orders,make_runtime

def evaluate(comp,orders,same_wait=100,cross_wait=1000):
    if any(comp.arrays['ddr']):raise Unsupported('nonempty DDR interface: use exact event replay')
    if any(type(x) is not int or x<0 for x in (same_wait,cross_wait)):raise Unsupported('integer waits required')
    core,_,_=validate_orders(comp,orders);a=comp.arrays;n=len(comp.op_keys);t=len(comp.task_ids)
    if comp.total_duration+(same_wait+cross_wait+1)*t>=2**50:raise Unsupported('bounded integer domain required')
    adjacency=[{} for _ in range(n+2*t)]
    def edge(u,v,lag):adjacency[u][v]=max(adjacency[u].get(v,0),int(lag))
    for op in range(n):
        task=int(a['task_of'][op]);edge(n+2*task,op,a['duration'][op]);edge(op,n+2*task+1,0)
        for k in range(a['succ_off'][op],a['succ_off'][op+1]):
            s=int(a['succ'][k]);edge(op,s,a['duration'][s])
        s=int(a['next_pipe'][op])
        if s>=0:edge(op,s,a['duration'][s])
    for task in range(t):
        for k in range(a['tp_off'][task],a['tp_off'][task+1]):
            p=int(a['tp'][k]);edge(n+2*p+1,n+2*task,cross_wait if core[p]!=core[task] else 0)
    tidx={x:i for i,x in enumerate(comp.task_ids)}
    for order in orders:
        for p,tgt in zip(order,order[1:]):edge(n+2*tidx[p]+1,n+2*tidx[tgt],same_wait)
    indeg=[0]*len(adjacency)
    for row in adjacency:
        for v in row:indeg[v]+=1
    ready=deque(i for i,d in enumerate(indeg) if not d);value=[0]*len(adjacency);count=0
    while ready:
        u=ready.popleft();count+=1
        for v,w in adjacency[u].items():
            value[v]=max(value[v],value[u]+w);indeg[v]-=1
            if not indeg[v]:ready.append(v)
    if count!=len(adjacency):raise Unsupported('compiled graph/FIFO/task union cycle')
    return dict(makespan=max(value,default=0),op_end=value[:n],
        op_start=[value[i]-int(a['duration'][i]) for i in range(n)],
        task_start=[value[n+2*i] for i in range(t)],task_end=[value[n+2*i+1] for i in range(t)])

def main():
    rows=[];inputs=[]
    for seed in range(24):
        spec=random_spec(661000+seed,tasks=2+seed%7,ops=5+seed%19,ddr_rate=0)
        rt=make_runtime(spec);comp=pack_tasks(rt.tasks,rt,60)
        for variant in range(3):
            orders=random_orders(spec,51100+seed*3+variant,1+(seed+variant)%4)
            got=evaluate(comp,orders);ref=score(comp,orders)
            assert got['makespan']==ref['makespan']
            for key in ['op_start','op_end','task_start','task_end']:assert got[key]==ref[key].tolist()
            rows.append(dict(seed=seed,variant=variant,makespan=got['makespan']))
            inputs.append(dict(spec=spec,orders=orders))
    root=Path(__file__).parent
    (root/'inputs/maxplus_no_ddr.json').write_text(json.dumps(inputs))
    (root/'results/maxplus_no_ddr.json').write_text(json.dumps(dict(scope='no-DDR compiled synthetic domain only; unbenchmarked Python graph DP',
        fixtures=len(rows),comparisons='all op/task integer start/end vs native replay',mismatches=0,rows=rows),indent=2))
    print('72 no-DDR compiled tests: all operation/task timestamps match. No performance claim.')
if __name__=='__main__':main()
